package com.blokgun.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

interface HudListener {
    fun onPauseClick()
    fun onDead()
}

/** Lapisan kontrol sentuh + tampilan HP, amunisi, hotbar. */
class Hud(ctx: Context, private val g: Game, private val l: HudListener) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    private val role = IntArray(20)
    private val lx = FloatArray(20)
    private val ly = FloatArray(20)
    private var joyId = -1
    private var joyCx = 0f
    private var joyCy = 0f
    private var joyX = 0f
    private var joyY = 0f
    private var notified = false

    private val JOY = 1
    private val LOOK = 2
    private val FIRE = 3
    private val BRK = 4
    private val JUMP = 5
    private val RLD = 6
    private val HOT = 7
    private val PAUSE = 8

    init {
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }

    // ---- geometri tombol ----
    private fun fireX() = width - 100f * d
    private fun fireY() = height - 90f * d
    private fun fireR() = 48f * d
    private fun jumpX() = width - 195f * d
    private fun jumpY() = height - 55f * d
    private fun jumpR() = 32f * d
    private fun brkX() = width - 60f * d
    private fun brkY() = height - 175f * d
    private fun brkR() = 34f * d
    private fun rldX() = width - 190f * d
    private fun rldY() = height - 130f * d
    private fun rldR() = 28f * d
    private fun pauseX() = width - 30f * d
    private fun pauseY() = 30f * d
    private fun pauseR() = 22f * d
    private fun slot() = 42f * d
    private fun gap() = 4f * d
    private fun hotLeft() = (width - (8 * (slot() + gap()) - gap())) / 2f
    private fun hotTop() = height - slot() - 8f * d
    private val joyR get() = 55f * d

    private fun inCircle(x: Float, y: Float, cx: Float, cy: Float, r: Float): Boolean {
        val dx = x - cx
        val dy = y - cy
        val rr = r * 1.15f
        return dx * dx + dy * dy <= rr * rr
    }

    private fun hotIndex(x: Float, y: Float): Int {
        if (y < hotTop() || y > hotTop() + slot()) return -1
        val rel = x - hotLeft()
        if (rel < 0f) return -1
        val i = (rel / (slot() + gap())).toInt()
        if (i < 0 || i > 7) return -1
        val inSlot = rel - i * (slot() + gap())
        return if (inSlot <= slot()) i else -1
    }

    fun reset() {
        for (i in role.indices) role[i] = 0
        joyId = -1
        g.input.clear()
        notified = false
    }

    // ---- sentuhan ----
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                up(e.getPointerId(e.actionIndex))
            }
            MotionEvent.ACTION_CANCEL -> reset()
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (id >= role.size) return
        val inp = g.input
        val hi = hotIndex(x, y)
        when {
            inCircle(x, y, pauseX(), pauseY(), pauseR()) -> { role[id] = PAUSE; l.onPauseClick() }
            inCircle(x, y, fireX(), fireY(), fireR()) -> { role[id] = FIRE; inp.fire = true; inp.fireEdge = true }
            inCircle(x, y, brkX(), brkY(), brkR()) -> { role[id] = BRK; inp.brk = true }
            inCircle(x, y, jumpX(), jumpY(), jumpR()) -> { role[id] = JUMP; inp.jump = true }
            inCircle(x, y, rldX(), rldY(), rldR()) -> { role[id] = RLD; inp.reload = true }
            hi >= 0 -> { role[id] = HOT; g.selected = hi }
            x < width * 0.4f -> {
                role[id] = JOY
                joyId = id
                joyCx = x; joyCy = y; joyX = x; joyY = y
            }
            else -> {
                role[id] = LOOK
                lx[id] = x; ly[id] = y
            }
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        if (id >= role.size) return
        when (role[id]) {
            JOY -> {
                var dx = x - joyCx
                var dy = y - joyCy
                val len = hypot(dx, dy)
                val r = joyR
                if (len > r) { dx = dx / len * r; dy = dy / len * r }
                joyX = joyCx + dx
                joyY = joyCy + dy
                if (len < 8f * d) {
                    g.input.moveX = 0f; g.input.moveY = 0f
                } else {
                    g.input.moveX = dx / r
                    g.input.moveY = -dy / r
                }
            }
            LOOK -> {
                g.input.addLook(x - lx[id], y - ly[id])
                lx[id] = x; ly[id] = y
            }
        }
    }

    private fun up(id: Int) {
        if (id >= role.size) return
        when (role[id]) {
            JOY -> { joyId = -1; g.input.moveX = 0f; g.input.moveY = 0f }
            FIRE -> g.input.fire = false
            BRK -> g.input.brk = false
            JUMP -> g.input.jump = false
        }
        role[id] = 0
    }

    // ---- gambar ----
    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, align: Paint.Align, color: Int) {
        tp.textSize = size * d
        tp.textAlign = align
        tp.color = color
        c.drawText(s, x, y, tp)
    }

    private fun circleBtn(c: Canvas, cx: Float, cy: Float, r: Float, label: String, size: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.argb(90, 255, 255, 255)
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.color = Color.argb(180, 255, 255, 255)
        c.drawCircle(cx, cy, r, p)
        text(c, label, cx, cy + size * d * 0.35f, size, Paint.Align.CENTER, Color.WHITE)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f

        if (g.hurtFlash > 0f) {
            c.drawColor(Color.argb((g.hurtFlash / 0.35f * 120f).toInt().coerceIn(0, 255), 255, 0, 0))
        }

        // crosshair
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.color = if (g.hitMarker > 0f) Color.RED else Color.WHITE
        c.drawLine(cx - 12 * d, cy, cx - 4 * d, cy, p)
        c.drawLine(cx + 4 * d, cy, cx + 12 * d, cy, p)
        c.drawLine(cx, cy - 12 * d, cx, cy - 4 * d, p)
        c.drawLine(cx, cy + 4 * d, cx, cy + 12 * d, p)

        // HP
        p.style = Paint.Style.FILL
        p.color = Color.argb(150, 0, 0, 0)
        c.drawRect(12 * d, 12 * d, 152 * d, 28 * d, p)
        val frac = (g.hp / 100f).coerceIn(0f, 1f)
        p.color = Color.rgb((255 * (1f - frac)).toInt(), (200 * frac).toInt() + 30, 40)
        c.drawRect(14 * d, 14 * d, 14 * d + 136 * d * frac, 26 * d, p)
        text(c, "HP ${g.hp.toInt()}", 160 * d, 26 * d, 13f, Paint.Align.LEFT, Color.WHITE)

        // amunisi
        val sel = g.selected
        if (sel < 3) {
            val wp = Game.WEAPONS[sel]
            val s = when {
                g.reloadT > 0f -> "${wp.name}  ISI ULANG..."
                g.creative -> "${wp.name}  \u221E"
                else -> "${wp.name}  ${g.ammo[sel]} / ${g.reserve[sel]}"
            }
            text(c, s, 14 * d, 50 * d, 14f, Paint.Align.LEFT, Color.WHITE)
        }

        // info level
        val info = if (g.creative) "MODE KREATIF" else "LEVEL ${g.level}  \u2022  MUSUH: ${g.left}"
        text(c, info, cx, 24 * d, 14f, Paint.Align.CENTER, Color.WHITE)

        // banner
        if (g.bannerT > 0f && g.banner.isNotEmpty()) {
            text(c, g.banner, cx, h * 0.32f, 30f, Paint.Align.CENTER, Color.rgb(255, 220, 80))
        }

        // hotbar
        val names = arrayOf("PIS", "RIF", "SHO")
        for (i in 0 until 8) {
            val x0 = hotLeft() + i * (slot() + gap())
            val y0 = hotTop()
            p.style = Paint.Style.FILL
            p.color = Color.argb(140, 0, 0, 0)
            c.drawRect(x0, y0, x0 + slot(), y0 + slot(), p)
            if (i < 3) {
                text(c, names[i], x0 + slot() / 2f, y0 + slot() / 2f + 5 * d, 12f, Paint.Align.CENTER, Color.WHITE)
            } else {
                p.color = Game.BLOCK_COLOR[i - 3]
                c.drawRect(x0 + 9 * d, y0 + 9 * d, x0 + slot() - 9 * d, y0 + slot() - 9 * d, p)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = if (i == sel) 3f * d else 1f * d
            p.color = if (i == sel) Color.WHITE else Color.argb(120, 255, 255, 255)
            c.drawRect(x0, y0, x0 + slot(), y0 + slot(), p)
        }

        // tombol
        circleBtn(c, fireX(), fireY(), fireR(), if (sel < 3) "TEMBAK" else "PASANG", 13f)
        circleBtn(c, jumpX(), jumpY(), jumpR(), "LOMPAT", 11f)
        circleBtn(c, brkX(), brkY(), brkR(), "PECAH", 11f)
        if (sel < 3) circleBtn(c, rldX(), rldY(), rldR(), "ISI", 11f)
        circleBtn(c, pauseX(), pauseY(), pauseR(), "II", 13f)

        // joystick
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        if (joyId >= 0) {
            p.color = Color.argb(150, 255, 255, 255)
            c.drawCircle(joyCx, joyCy, joyR, p)
            p.style = Paint.Style.FILL
            p.color = Color.argb(150, 255, 255, 255)
            c.drawCircle(joyX, joyY, 24 * d, p)
        } else {
            p.color = Color.argb(60, 255, 255, 255)
            c.drawCircle(110 * d, h - 110 * d, joyR, p)
        }

        if (g.dead && !notified) {
            notified = true
            post { l.onDead() }
        }
        postInvalidateOnAnimation()
    }
}
