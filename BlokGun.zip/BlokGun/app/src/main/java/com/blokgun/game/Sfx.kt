package com.blokgun.game
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random
/** Semua suara dibuat lewat kode (tanpa file audio) supaya ukuran APK sangat kecil. */
object Sfx {
    const val PISTOL = 0
    const val RIFLE = 1
    const val SHOTGUN = 2
    const val HIT = 3
    const val BREAK = 4
    const val PLACE = 5
    const val HURT = 6
    const val KILL = 7
    const val RELOAD = 8
    const val LEVEL = 9
    const val CLICK = 10
    const val ZGROAN = 11   // deru zombie saat berjalan / idle
    const val ZDEATH = 12   // teriakan kematian zombie
    const val VOICE_A = 13  // "hoho"
    const val VOICE_B = 14  // "hoiii"
    const val VOICE_C = 15  // "hayaaa"
    private const val SR = 22050
    private val tracks = ArrayList<List<AudioTrack>>()
    private val next = IntArray(18)
    @Volatile var enabled = true
    private fun nz(): Float = Random.nextFloat() * 2f - 1f
    private fun tau(f: Float, t: Float): Float = sin((2.0 * PI * f * t).toFloat())
    private fun make(sec: Float, f: (Float) -> Float): ShortArray {
        val n = (SR * sec).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val v = f(i.toFloat() / SR).coerceIn(-1f, 1f)
            out[i] = (v * 30000f).toInt().toShort()
        }
        return out
    }
    private fun track(data: ShortArray): AudioTrack {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(data, 0, data.size)
        return t
    }
    fun setup() {
        if (tracks.isNotEmpty()) return
        try {
            val notes = floatArrayOf(523f, 659f, 784f, 1046f)
            // Amplop dua/ tiga suku kata untuk suara teriak.
            fun burst(t: Float, starts: FloatArray, dur: Float): Float {
                var e = 0f
                for (s0 in starts) {
                    val u = t - s0
                    if (u > 0f && u < dur) {
                        val env = if (u < 0.03f) u / 0.03f else 1f - (u - 0.03f) / (dur - 0.03f)
                        e = maxOf(e, env.coerceIn(0f, 1f))
                    }
                }
                return e
            }
            val defs = listOf<Pair<Int, ShortArray>>(
                Pair(2, make(0.15f) { t -> (nz() * 0.7f + tau(150f, t) * 0.5f) * exp(-t * 28f) }),
                Pair(2, make(0.10f) { t -> (nz() * 0.8f + tau(200f, t) * 0.4f) * exp(-t * 38f) }),
                Pair(2, make(0.35f) { t -> (nz() * 0.9f + tau(90f, t) * 0.6f) * exp(-t * 11f) }),
                Pair(1, make(0.06f) { t -> tau(900f, t) * exp(-t * 45f) * 0.6f }),
                Pair(1, make(0.10f) { t -> nz() * exp(-t * 30f) * 0.6f }),
                Pair(1, make(0.08f) { t -> tau(110f, t) * exp(-t * 35f) * 0.9f }),
                Pair(1, make(0.22f) { t -> sin((2.0 * PI * (300f * t - 500f * t * t)).toFloat()) * exp(-t * 8f) * 0.7f }),
                Pair(1, make(0.15f) { t -> sin((2.0 * PI * (500f * t - 1200f * t * t)).toFloat()) * exp(-t * 12f) * 0.6f }),
                Pair(1, make(0.30f) { t ->
                    val a = if (t > 0.05f) 0f else nz() * exp(-t * 80f) * 0.7f
                    val s = t - 0.16f
                    val b = if (s < 0f || s > 0.05f) 0f else nz() * exp(-s * 80f) * 0.7f
                    a + b
                }),
                Pair(1, make(0.60f) { t ->
                    val i = (t / 0.15f).toInt().coerceAtMost(3)
                    val lt = t - i * 0.15f
                    tau(notes[i], lt) * exp(-lt * 6f) * 0.5f
                }),
                Pair(1, make(0.04f) { t -> nz() * exp(-t * 90f) * 0.4f }),
                // 11 ZGROAN: deru zombie rendah & dalam, minim noise (bukan kresek-kresek)
                Pair(2, make(0.90f) { t ->
                    val vib = 1f + 0.08f * sin(t * 5.5f)
                    val f1 = 72f * vib
                    val f2 = 144f * vib
                    val am = 0.75f + 0.25f * sin(t * 2.1f)
                    val attack = if (t < 0.12f) t / 0.12f else 1f
                    (sin((2.0 * PI * f1 * t).toFloat()) * 0.55f +
                        sin((2.0 * PI * f2 * t).toFloat()) * 0.22f +
                        nz() * 0.05f) * exp(-t * 1.1f) * attack * am * 0.75f
                }),
                // 12 ZDEATH: geraman kematian jatuh nada, dalam
                Pair(2, make(0.90f) { t ->
                    val f = 125f - 75f * (t / 0.9f).coerceAtMost(1f)
                    val am = if (t < 0.08f) t / 0.08f else exp(-(t - 0.08f) * 2.2f)
                    (sin((2.0 * PI * f * t).toFloat()) * 0.55f +
                        sin((2.0 * PI * f * 0.5f * t).toFloat()) * 0.3f +
                        nz() * 0.06f) * am * 0.75f
                }),
                // 13 VOICE_A "hoho": dua suku kata rendah
                Pair(1, make(0.55f) { t ->
                    val e = burst(t, floatArrayOf(0f, 0.24f), 0.18f)
                    sin((2.0 * PI * 165f * t).toFloat()) * e * 0.55f + nz() * 0.06f * e
                }),
                // 14 VOICE_B "hoiii": satu teriakan panjang naik nada
                Pair(1, make(0.60f) { t ->
                    val f = 150f + 230f * (t / 0.6f)
                    val e = if (t < 0.06f) t / 0.06f else exp(-(t - 0.06f) * 2.6f)
                    sin((2.0 * PI * f * t).toFloat()) * e * 0.55f + nz() * 0.05f * e
                }),
                // 15 VOICE_C "hayaaa": tiga suku kata cepat nada tinggi
                Pair(1, make(0.55f) { t ->
                    val e = burst(t, floatArrayOf(0f, 0.16f, 0.32f), 0.13f)
                    val f = 320f + 60f * sin(t * 9f)
                    sin((2.0 * PI * f * t).toFloat()) * e * 0.5f + nz() * 0.06f * e
                }),
                // 16 FOOT_GRASS: langkah di rumput/tanah (pelan, rendah)
                Pair(2, make(0.12f) { t ->
                    (sin((2.0 * PI * 90f * t).toFloat()) * 0.5f + nz() * 0.3f) * exp(-t * 22f) * 0.5f
                }),
                // 17 FOOT_STONE: langkah di batu/beton (keras, pendek)
                Pair(2, make(0.10f) { t ->
                    (nz() * 0.8f + sin((2.0 * PI * 180f * t).toFloat()) * 0.3f) * exp(-t * 28f) * 0.45f
                })
            )
            for ((voices, data) in defs) {
                val list = ArrayList<AudioTrack>()
                for (v in 0 until voices) list.add(track(data))
                tracks.add(list)
            }
        } catch (e: Exception) {
            // Jika audio gagal dibuat, game tetap jalan tanpa suara.
        }
    }
    fun play(id: Int) {
        if (!enabled || id < 0 || id >= tracks.size) return
        try {
            val list = tracks[id]
            val i = next[id]
            next[id] = (i + 1) % list.size
            val t = list[i]
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) {
        }
    }
    /** Suara teriak acak untuk musuh bersenjata. */
    fun playRandomVoice() {
        play(VOICE_A + Random.nextInt(3))
    }
    private var ambient: AudioTrack? = null
    fun startAmbient() {
        if (!enabled || ambient != null) return
        try {
            val n = SR * 2
            val buf = ShortArray(n)
            var lp = 0f
            for (i in 0 until n) {
                lp = lp * 0.97f + nz() * 0.03f
                val gust = 0.6f + 0.4f * sin((i.toFloat() / SR) * 2f * Math.PI.toFloat() * 0.25f)
                buf[i] = (lp * 9000f * gust).toInt().toShort()
            }
            val t = track(buf)
            t.setLoopPoints(0, n, -1)
            t.play()
            ambient = t
        } catch (e: Exception) { }
    }
    fun stopAmbient() {
        try {
            ambient?.pause(); ambient?.flush(); ambient?.stop(); ambient?.release()
        } catch (e: Exception) { }
        ambient = null
    }
    fun release() {
        for (l in tracks) for (t in l) {
            try { t.release() } catch (e: Exception) { }
        }
        tracks.clear()
    }
}
