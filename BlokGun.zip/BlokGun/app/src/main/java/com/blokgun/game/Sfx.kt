package com.blokgun.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Semua suara dibuat lewat kode (tanpa file audio) supaya ukuran APK sangat kecil. */
object Sfx {
    const val PISTOL = 0
    const val RIFLE = 1
    const val SHOTGUN = 2
    const val HIT = 3
    const val BREAK = 4
    const val PLACE = 5
    const val HURT = 6
    const val KILL = 7
    const val RELOAD = 8
    const val LEVEL = 9
    const val CLICK = 10

    private const val SR = 22050
    private val tracks = ArrayList<List<AudioTrack>>()
    private val next = IntArray(11)
    @Volatile var enabled = true

    private fun nz(): Float = Random.nextFloat() * 2f - 1f
    private fun tau(f: Float, t: Float): Float = sin((2.0 * PI * f * t).toFloat())

    private fun make(sec: Float, f: (Float) -> Float): ShortArray {
        val n = (SR * sec).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val v = f(i.toFloat() / SR).coerceIn(-1f, 1f)
            out[i] = (v * 30000f).toInt().toShort()
        }
        return out
    }

    private fun track(data: ShortArray): AudioTrack {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(data, 0, data.size)
        return t
    }

    fun setup() {
        if (tracks.isNotEmpty()) return
        try {
            val notes = floatArrayOf(523f, 659f, 784f, 1046f)
            val defs = listOf(
                Pair(2, make(0.15f) { t -> (nz() * 0.7f + tau(150f, t) * 0.5f) * exp(-t * 28f) }),
                Pair(2, make(0.10f) { t -> (nz() * 0.8f + tau(200f, t) * 0.4f) * exp(-t * 38f) }),
                Pair(2, make(0.35f) { t -> (nz() * 0.9f + tau(90f, t) * 0.6f) * exp(-t * 11f) }),
                Pair(1, make(0.06f) { t -> tau(900f, t) * exp(-t * 45f) * 0.6f }),
                Pair(1, make(0.10f) { t -> nz() * exp(-t * 30f) * 0.6f }),
                Pair(1, make(0.08f) { t -> tau(110f, t) * exp(-t * 35f) * 0.9f }),
                Pair(1, make(0.22f) { t -> sin((2.0 * PI * (300f * t - 500f * t * t)).toFloat()) * exp(-t * 8f) * 0.7f }),
                Pair(1, make(0.15f) { t -> sin((2.0 * PI * (500f * t - 1200f * t * t)).toFloat()) * exp(-t * 12f) * 0.6f }),
                Pair(1, make(0.30f) { t ->
                    val a = if (t > 0.05f) 0f else nz() * exp(-t * 80f) * 0.7f
                    val s = t - 0.16f
                    val b = if (s < 0f || s > 0.05f) 0f else nz() * exp(-s * 80f) * 0.7f
                    a + b
                }),
                Pair(1, make(0.60f) { t ->
                    val i = (t / 0.15f).toInt().coerceAtMost(3)
                    val lt = t - i * 0.15f
                    tau(notes[i], lt) * exp(-lt * 6f) * 0.5f
                }),
                Pair(1, make(0.04f) { t -> nz() * exp(-t * 90f) * 0.4f })
            )
            for ((voices, data) in defs) {
                val list = ArrayList<AudioTrack>()
                for (v in 0 until voices) list.add(track(data))
                tracks.add(list)
            }
        } catch (e: Exception) {
            // Jika audio gagal dibuat, game tetap jalan tanpa suara.
        }
    }

    fun play(id: Int) {
        if (!enabled || id < 0 || id >= tracks.size) return
        try {
            val list = tracks[id]
            val i = next[id]
            next[id] = (i + 1) % list.size
            val t = list[i]
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) {
        }
    }

    fun release() {
        for (l in tracks) for (t in l) {
            try { t.release() } catch (e: Exception) { }
        }
        tracks.clear()
    }
}
