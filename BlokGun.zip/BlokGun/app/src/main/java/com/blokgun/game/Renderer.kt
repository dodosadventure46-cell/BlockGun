package com.blokgun.game
import android.graphics.Bitmap
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
/** Penampung vertex: x, y, z, u, v, shade per titik. */
class FB {
    var a = FloatArray(1 shl 15)
    var n = 0
    private fun v(x: Float, y: Float, z: Float, u: Float, w: Float, s: Float) {
        if (n + 6 > a.size) a = a.copyOf(a.size * 2)
        a[n++] = x; a[n++] = y; a[n++] = z; a[n++] = u; a[n++] = w; a[n++] = s
    }
    fun quad(
        x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float, x3: Float, y3: Float, z3: Float,
        tile: Int, s: Float
    ) {
        val tx = tile % 4
        val ty = tile / 4
        val u0 = tx * 0.25f + 0.002f
        val u1 = (tx + 1) * 0.25f - 0.002f
        val v0 = ty * 0.25f + 0.002f
        val v1 = (ty + 1) * 0.25f - 0.002f
        v(x0, y0, z0, u0, v1, s); v(x1, y1, z1, u1, v1, s); v(x2, y2, z2, u1, v0, s)
        v(x0, y0, z0, u0, v1, s); v(x2, y2, z2, u1, v0, s); v(x3, y3, z3, u0, v0, s)
    }
    fun toBuffer(): FloatBuffer {
        val bb = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder())
        val fb = bb.asFloatBuffer()
        fb.put(a, 0, n)
        fb.position(0)
        return fb
    }
}
class ChunkMesh(val buf: FloatBuffer, val count: Int)
object Mesher {
    private val SHADE = floatArrayOf(1f, 0.5f, 0.8f, 0.8f, 0.65f, 0.65f)
    fun face(fb: FB, f: Int, x: Float, y: Float, z: Float, tile: Int) {
        val x1 = x + 1f
        val y1 = y + 1f
        val z1 = z + 1f
        val s = SHADE[f]
        when (f) {
            0 -> fb.quad(x, y1, z1, x1, y1, z1, x1, y1, z, x, y1, z, tile, s)
            1 -> fb.quad(x, y, z, x1, y, z, x1, y, z1, x, y, z1, tile, s)
            2 -> fb.quad(x1, y, z1, x1, y, z, x1, y1, z, x1, y1, z1, tile, s)
            3 -> fb.quad(x, y, z, x, y, z1, x, y1, z1, x, y1, z, tile, s)
            4 -> fb.quad(x, y, z1, x1, y, z1, x1, y1, z1, x, y1, z1, tile, s)
            else -> fb.quad(x1, y, z, x, y, z, x, y1, z, x1, y1, z, tile, s)
        }
    }
    // atlas 4x4: 0 rumput atas, 1 rumput samping, 2 tanah, 3 batu, 4 kayu samping,
    // 5 kayu atas, 6 daun, 7 pasir, 8 papan, 15 putih
    fun tile(b: Int, f: Int): Int = when (b) {
        1 -> if (f == 0) 0 else if (f == 1) 2 else 1
        2 -> 2
        3 -> 3
        4 -> if (f <= 1) 5 else 4
        5 -> 6
        6 -> 7
        7 -> 8
        else -> 15
    }
    fun build(w: World, cx: Int, cz: Int, fb: FB): ChunkMesh {
        fb.n = 0
        val cs = World.CS
        for (y in 0 until World.SY) for (z in cz * cs until (cz + 1) * cs) for (x in cx * cs until (cx + 1) * cs) {
            val b = w.get(x, y, z)
            if (b == 0) continue
            val fx = x.toFloat()
            val fy = y.toFloat()
            val fz = z.toFloat()
            if (w.get(x, y + 1, z) == 0) face(fb, 0, fx, fy, fz, tile(b, 0))
            if (y > 0 && w.get(x, y - 1, z) == 0) face(fb, 1, fx, fy, fz, tile(b, 1))
            if (w.get(x + 1, y, z) == 0) face(fb, 2, fx, fy, fz, tile(b, 2))
            if (w.get(x - 1, y, z) == 0) face(fb, 3, fx, fy, fz, tile(b, 3))
            if (w.get(x, y, z + 1) == 0) face(fb, 4, fx, fy, fz, tile(b, 4))
            if (w.get(x, y, z - 1) == 0) face(fb, 5, fx, fy, fz, tile(b, 5))
        }
        return ChunkMesh(fb.toBuffer(), fb.n / 6)
    }
}
class Renderer(private val g: Game) : GLSurfaceView.Renderer {
    private val VS = """
        attribute vec3 aPos;
        attribute vec2 aUV;
        attribute float aShade;
        uniform mat4 uMVP;
        uniform float uFogS;
        uniform float uFogL;
        varying vec2 vUV;
        varying float vShade;
        varying float vFog;
        void main() {
            gl_Position = uMVP * vec4(aPos, 1.0);
            vUV = aUV;
            vShade = aShade;
            vFog = clamp((gl_Position.w - uFogS) / uFogL, 0.0, 1.0);
        }
    """.trimIndent()
    private val FS = """
        precision mediump float;
        uniform sampler2D uTex;
        uniform vec3 uTint;
        uniform vec3 uFog;
        varying vec2 vUV;
        varying float vShade;
        varying float vFog;
        void main() {
            vec3 col = texture2D(uTex, vUV).rgb * uTint * vShade;
            gl_FragColor = vec4(mix(col, uFog, vFog), 1.0);
        }
    """.trimIndent()
    // Shader sederhana untuk bayangan datar (warna + alpha).
    private val SVS = "attribute vec3 aPos; uniform mat4 uMVP; void main(){ gl_Position = uMVP * vec4(aPos,1.0); }"
    private val SFS = "precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor = uColor; }"
    private var prog = 0
    private var tex = 0
    private var uMVP = 0
    private var uTint = 0
    private var uTex = 0
    private var uFog = 0
    private var uFogS = 0
    private var uFogL = 0
    private var aPos = 0
    private var aUV = 0
    private var aShade = 0
    private var sProg = 0
    private var sUMVP = 0
    private var sUColor = 0
    private var sAPos = 0
    private lateinit var shadowQuad: FloatBuffer
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val meshes = arrayOfNulls<ChunkMesh>(World.NCX * World.NCZ)
    private val fb = FB()
    private var cube: FloatBuffer = FB().toBuffer()
    private var last = 0L
    private var scrW = 1
    private var scrH = 1
    private var meshCursor = 0
    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val st = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(s))
        return s
    }
    private fun makeAtlas(): Bitmap {
        val bm = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val r = java.util.Random(42)
        fun px(t: Int, x: Int, y: Int, cr: Int, cg: Int, cb: Int, v: Int) {
            val n = if (v > 0) r.nextInt(v * 2 + 1) - v else 0
            bm.setPixel(
                (t % 4) * 16 + x, (t / 4) * 16 + y,
                Color.rgb((cr + n).coerceIn(0, 255), (cg + n).coerceIn(0, 255), (cb + n).coerceIn(0, 255))
            )
        }
        for (y in 0 until 16) for (x in 0 until 16) {
            px(0, x, y, 95, 160, 60, 14)
            if (y < 4 || (y == 4 && x % 3 == 0)) px(1, x, y, 95, 160, 60, 14) else px(1, x, y, 125, 85, 50, 12)
            px(2, x, y, 125, 85, 50, 12)
            px(3, x, y, 125, 125, 125, 16)
            if (x % 4 == 0) px(4, x, y, 70, 50, 30, 6) else px(4, x, y, 105, 78, 45, 8)
            val dd = hypot(x - 7.5f, y - 7.5f)
            if (dd.toInt() % 3 == 0) px(5, x, y, 95, 70, 40, 6) else px(5, x, y, 150, 115, 70, 8)
            px(6, x, y, 45, 120, 35, 25)
            px(7, x, y, 225, 210, 150, 8)
            if (y % 4 == 3) px(8, x, y, 120, 85, 45, 5) else px(8, x, y, 185, 145, 85, 8)
            px(15, x, y, 255, 255, 255, 0)
        }
        return bm
    }
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.53f, 0.81f, 0.92f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs = compile(GLES20.GL_VERTEX_SHADER, VS)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FS)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        uMVP = GLES20.glGetUniformLocation(prog, "uMVP")
        uTint = GLES20.glGetUniformLocation(prog, "uTint")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
        uFog = GLES20.glGetUniformLocation(prog, "uFog")
        uFogS = GLES20.glGetUniformLocation(prog, "uFogS")
        uFogL = GLES20.glGetUniformLocation(prog, "uFogL")
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aUV = GLES20.glGetAttribLocation(prog, "aUV")
        aShade = GLES20.glGetAttribLocation(prog, "aShade")
        // program bayangan
        val svs = compile(GLES20.GL_VERTEX_SHADER, SVS)
        val sfs = compile(GLES20.GL_FRAGMENT_SHADER, SFS)
        sProg = GLES20.glCreateProgram()
        GLES20.glAttachShader(sProg, svs)
        GLES20.glAttachShader(sProg, sfs)
        GLES20.glLinkProgram(sProg)
        sUMVP = GLES20.glGetUniformLocation(sProg, "uMVP")
        sUColor = GLES20.glGetUniformLocation(sProg, "uColor")
        sAPos = GLES20.glGetAttribLocation(sProg, "aPos")
        val sq = floatArrayOf(
            -0.5f, 0f, -0.5f, 0.5f, 0f, -0.5f, 0.5f, 0f, 0.5f,
            -0.5f, 0f, -0.5f, 0.5f, 0f, 0.5f, -0.5f, 0f, 0.5f
        )
        val sbb = ByteBuffer.allocateDirect(sq.size * 4).order(ByteOrder.nativeOrder())
        shadowQuad = sbb.asFloatBuffer()
        shadowQuad.put(sq)
        shadowQuad.position(0)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        tex = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val bm = makeAtlas()
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bm, 0)
        bm.recycle()
        val cf = FB()
        for (f in 0..5) Mesher.face(cf, f, -0.5f, -0.5f, -0.5f, 15)
        cube = cf.toBuffer()
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glEnableVertexAttribArray(aShade)
        last = 0L
    }
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        scrW = width
        scrH = height
    }
    private fun bind(buf: FloatBuffer) {
        buf.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, buf)
        buf.position(3)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 24, buf)
        buf.position(5)
        GLES20.glVertexAttribPointer(aShade, 1, GLES20.GL_FLOAT, false, 24, buf)
        buf.position(0)
    }
    private fun part(
        ex: Float, ey: Float, ez: Float, yawRad: Float,
        lx: Float, ly: Float, lz: Float, sx: Float, sy: Float, sz: Float,
        cr: Float, cg: Float, cb: Float
    ) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, ex, ey, ez)
        Matrix.rotateM(model, 0, -Math.toDegrees(yawRad.toDouble()).toFloat(), 0f, 1f, 0f)
        Matrix.translateM(model, 0, lx, ly, lz)
        Matrix.scaleM(model, 0, sx, sy, sz)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glUniform3f(uTint, cr, cg, cb)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }
    /** Kubus di ruang dunia tanpa rotasi (untuk mayat/ragdoll). */
    private fun wpart(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, cr: Float, cg: Float, cb: Float) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.scaleM(model, 0, sx, sy, sz)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glUniform3f(uTint, cr, cg, cb)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }
    private fun drawEnemy(e: Enemy) {
        val h = e.hit > 0f
        val x = e.x
        val y = e.y
        val z = e.z
        val yw = e.yaw
        val moving = e.onGround && (abs(e.vx) + abs(e.vz)) > 0.5f
        val ws = sin(e.walk)
        val by = if (moving) abs(ws) * 0.05f else 0f
        val legSwing = ws * 0.16f
        val liftL = max(0f, ws) * 0.09f
        val liftR = max(0f, -ws) * 0.09f
        val armSwing = -ws * 0.12f
        if (e.type == 0) {
            val bodyR = if (h) 1f else 0.15f; val bodyG = if (h) 0.3f else 0.25f; val bodyB = if (h) 0.3f else 0.5f
            val limbR = if (h) 1f else 0.4f; val limbG = if (h) 0.3f else 0.7f; val limbB = if (h) 0.3f else 0.35f
            // kaki (ayun saat berjalan)
            part(x, y, z, yw, -0.16f, 0.45f + liftL, legSwing, 0.16f, 0.9f, 0.16f, 0.15f, 0.25f, 0.5f)
            part(x, y, z, yw, 0.16f, 0.45f + liftR, -legSwing, 0.16f, 0.9f, 0.16f, 0.15f, 0.25f, 0.5f)
            part(x, y, z, yw, 0f, 1.1f + by, 0f, 0.45f, 0.8f, 0.25f, bodyR, bodyG, bodyB)
            part(x, y, z, yw, 0f, 1.1f + by, 0f, 0.55f, 0.7f, 0.3f, if (h) 1f else 0.2f, if (h) 0.3f else 0.5f, if (h) 0.3f else 0.55f)
            part(x, y, z, yw, 0f, 1.62f + by, 0f, 0.42f, 0.42f, 0.42f, limbR, limbG, limbB)
            // lengan teracung ke depan, sedikit ayun
            part(x, y, z, yw, -0.38f, 1.25f + by, -0.35f + armSwing, 0.18f, 0.18f, 0.6f, limbR, limbG, limbB)
            part(x, y, z, yw, 0.38f, 1.25f + by, -0.35f - armSwing, 0.18f, 0.18f, 0.6f, limbR, limbG, limbB)
        } else {
            // kaki
            part(x, y, z, yw, -0.16f, 0.45f + liftL, legSwing, 0.16f, 0.9f, 0.16f, 0.2f, 0.2f, 0.25f)
            part(x, y, z, yw, 0.16f, 0.45f + liftR, -legSwing, 0.16f, 0.9f, 0.16f, 0.2f, 0.2f, 0.25f)
            part(x, y, z, yw, 0f, 1.1f + by, 0f, 0.45f, 0.8f, 0.25f, if (h) 1f else 0.2f, if (h) 0.3f else 0.2f, if (h) 0.3f else 0.25f)
            part(x, y, z, yw, 0f, 1.1f + by, 0f, 0.55f, 0.7f, 0.3f, if (h) 1f else 0.55f, if (h) 0.3f else 0.18f, if (h) 0.3f else 0.18f)
            part(x, y, z, yw, 0f, 1.62f + by, 0f, 0.42f, 0.42f, 0.42f, if (h) 1f else 0.9f, if (h) 0.3f else 0.72f, if (h) 0.3f else 0.55f)
            // lengan memegang senjata ke depan
            part(x, y, z, yw, -0.3f, 1.2f + by, -0.4f, 0.16f, 0.16f, 0.5f, 0.9f, 0.72f, 0.55f)
            part(x, y, z, yw, 0.3f, 1.2f + by, -0.4f, 0.16f, 0.16f, 0.5f, 0.9f, 0.72f, 0.55f)
            part(x, y, z, yw, 0f, 1.2f + by, -0.55f, 0.1f, 0.12f, 0.55f, 0.08f, 0.08f, 0.08f)
        }
    }
    private fun vpart(
        x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float,
        cr: Float, cg: Float, cb: Float
    ) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.scaleM(model, 0, sx, sy, sz)
        Matrix.multiplyMM(mvp, 0, proj, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glUniform3f(uTint, cr, cg, cb)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }
    private fun drawViewModel() {
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
        val item = g.selected
        if (item >= 3) {
            val c = Game.BLOCK_COLOR[item - 3]
            vpart(0.3f, -0.28f, -0.5f, 0.15f, 0.15f, 0.15f, Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f)
            return
        }
        val k = g.kick
        val sc = g.scope
        val rl = if (g.reloadT > 0f) 1f - g.reloadT / 1.1f else -1f
        val dip = if (rl >= 0f) sin(rl * PI.toFloat()) * 0.18f else 0f
        val bobX = sin(g.bob) * 0.006f
        val bobY = abs(cos(g.bob)) * 0.005f
        // posisi dasar: kanan-bawah, tidak menutupi layar; saat scope ke tengah
        val bx = if (sc) 0f else 0.24f + bobX
        val by = if (sc) -0.22f else -0.28f + bobY - dip
        val bz = if (sc) -0.34f else -0.55f + k * 0.07f
        val skinR = 0.85f; val skinG = 0.66f; val skinB = 0.5f
        fun vw(dx: Float, dy: Float, dz: Float, sx: Float, sy: Float, sz: Float, r: Float, gg: Float, b: Float) =
            vpart(bx + dx, by + dy, bz + dz, sx, sy, sz, r, gg, b)
        var flashX = 0f; var flashY = 0f; var flashZ = -0.6f
        if (item == 0) { // PISTOL
            vw(0f, 0.02f, -0.03f, 0.07f, 0.11f, 0.24f, 0.22f, 0.22f, 0.24f) // slide
            vw(0f, 0.03f, -0.17f, 0.05f, 0.06f, 0.08f, 0.08f, 0.08f, 0.09f) // ujung laras
            vw(0f, -0.09f, 0.05f, 0.06f, 0.14f, 0.07f, 0.35f, 0.25f, 0.15f) // grip
            if (!sc) {
                vw(0.015f, -0.10f, 0.07f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB) // tangan
                vw(0.05f, -0.18f, 0.14f, 0.08f, 0.16f, 0.08f, 0.2f, 0.2f, 0.26f) // lengan baju
            }
            flashX = 0f; flashY = 0.03f; flashZ = -0.22f
        } else if (item == 1) { // RIFLE (berscope)
            vw(0f, 0f, -0.02f, 0.08f, 0.11f, 0.42f, 0.15f, 0.15f, 0.17f) // receiver
            vw(0f, 0.025f, -0.34f, 0.045f, 0.045f, 0.32f, 0.08f, 0.08f, 0.09f) // laras
            vw(0f, 0.025f, -0.52f, 0.06f, 0.06f, 0.06f, 0.05f, 0.05f, 0.06f) // moncong
            vw(0f, -0.10f, 0.02f, 0.06f, 0.17f, 0.08f, 0.12f, 0.12f, 0.14f) // magazin
            vw(0f, 0.09f, -0.06f, 0.05f, 0.06f, 0.18f, 0.05f, 0.05f, 0.06f) // teropong scope
            vw(0f, 0.09f, -0.13f, 0.07f, 0.08f, 0.03f, 0.02f, 0.02f, 0.03f) // ring scope
            vw(0f, 0.09f, 0.01f, 0.07f, 0.08f, 0.03f, 0.02f, 0.02f, 0.03f)
            if (!sc) {
                vw(0f, -0.11f, 0.14f, 0.06f, 0.14f, 0.07f, 0.3f, 0.2f, 0.12f) // grip
                vw(0f, -0.01f, 0.24f, 0.07f, 0.12f, 0.2f, 0.25f, 0.18f, 0.12f) // popor
                vw(0.015f, -0.12f, 0.14f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB) // tangan kanan
                vw(0.015f, -0.05f, -0.20f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB) // tangan kiri (foregrip)
                vw(0.05f, -0.18f, 0.2f, 0.08f, 0.16f, 0.08f, 0.2f, 0.2f, 0.26f)
                vw(0.05f, -0.14f, -0.14f, 0.08f, 0.14f, 0.08f, 0.2f, 0.2f, 0.26f)
            }
            flashX = 0f; flashY = 0.025f; flashZ = -0.57f
        } else { // SHOTGUN
            vw(0f, 0f, -0.05f, 0.09f, 0.11f, 0.4f, 0.18f, 0.18f, 0.2f) // body
            vw(0f, 0.04f, -0.36f, 0.07f, 0.07f, 0.42f, 0.08f, 0.08f, 0.09f) // laras panjang
            vw(0f, -0.03f, -0.20f, 0.09f, 0.09f, 0.14f, 0.35f, 0.25f, 0.15f) // pompa
            if (!sc) {
                vw(0f, -0.11f, 0.14f, 0.06f, 0.14f, 0.07f, 0.3f, 0.2f, 0.12f)
                vw(0f, -0.01f, 0.22f, 0.08f, 0.13f, 0.22f, 0.3f, 0.2f, 0.12f) // popor kayu
                vw(0.015f, -0.12f, 0.14f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB)
                vw(0.015f, -0.07f, -0.18f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB)
                vw(0.05f, -0.18f, 0.2f, 0.08f, 0.16f, 0.08f, 0.2f, 0.2f, 0.26f)
                vw(0.05f, -0.15f, -0.12f, 0.08f, 0.14f, 0.08f, 0.2f, 0.2f, 0.26f)
            }
            flashX = 0f; flashY = 0.04f; flashZ = -0.62f
        }
        if (g.flashT > 0f) {
            vpart(bx + flashX, by + flashY, bz + flashZ, 0.11f, 0.11f, 0.09f, 1f, 0.85f, 0.3f)
        }
    }
    private fun drawShadows() {
        val mode = g.graphicsMode
        if (mode <= 0) return
        GLES20.glUseProgram(sProg)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        shadowQuad.position(0)
        GLES20.glEnableVertexAttribArray(sAPos)
        GLES20.glVertexAttribPointer(sAPos, 3, GLES20.GL_FLOAT, false, 12, shadowQuad)
        val size = if (mode == 1) 0.85f else 1.15f
        val alpha = if (mode == 1) 0.26f else 0.36f
        for (e in g.enemies) {
            val gy = g.world.topY(e.x.toInt(), e.z.toInt())
            if (gy < 0) continue
            val surf = gy + 1.02f
            if (e.y - surf > 5f) continue // melompat tinggi, bayangan mengecil/skip
            val sc = if (e.y - surf > 1f) (size * (1f - (e.y - surf) * 0.08f)).coerceAtLeast(0.4f) else size
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, e.x, surf, e.z)
            Matrix.scaleM(model, 0, sc, 1f, sc)
            Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
            GLES20.glUniformMatrix4fv(sUMVP, 1, false, mvp, 0)
            GLES20.glUniform4f(sUColor, 0f, 0f, 0f, alpha)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
            if (mode == 2) {
                // bayangan luar lebih lembut -> kesan realistis
                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, e.x, surf - 0.005f, e.z)
                Matrix.scaleM(model, 0, sc * 1.7f, 1f, sc * 1.7f)
                Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
                GLES20.glUniformMatrix4fv(sUMVP, 1, false, mvp, 0)
                GLES20.glUniform4f(sUColor, 0f, 0f, 0f, alpha * 0.45f)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
            }
        }
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
        // (sengaja tidak disable sAPos: jika index-nya sama dengan attrib utama,
        //  bind() di bawah akan menimpa pointer-nya; jika beda, tidak terpakai.)
    }
    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0f else min((now - last) / 1e9f, 0.05f)
        last = now
        g.tick(dt)
        val w = g.world
        // bangun ulang chunk kotor maksimal 6 per frame agar tidak nge-lag
        val total = World.NCX * World.NCZ
        var rebuilt = 0
        var n = 0
        while (n < total && rebuilt < 6) {
            val i = (meshCursor + n) % total
            if (w.dirty[i] || meshes[i] == null) {
                w.dirty[i] = false
                meshes[i] = Mesher.build(w, i % World.NCX, i / World.NCX, fb)
                rebuilt++
            }
            n++
        }
        meshCursor = (meshCursor + 1) % total
        // FOV menyempit saat scope / ADS
        val fov = when {
            !g.scope || g.selected >= 3 -> 72f
            Game.WEAPONS[g.selected].scope -> 35f
            else -> 52f
        }
        val aspect = scrW.toFloat() / scrH.toFloat()
        Matrix.perspectiveM(proj, 0, fov, aspect, 0.08f, 180f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val ex = g.p.x
        val ey = g.p.y + 1.62f
        val ez = g.p.z
        val cp = cos(g.pitch)
        Matrix.setLookAtM(
            view, 0, ex, ey, ez,
            ex + sin(g.yaw) * cp, ey + sin(g.pitch), ez - cos(g.yaw) * cp,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        // fog sesuai kualitas grafis
        val (fogS, fogL) = when (g.graphicsMode) {
            0 -> Pair(26f, 24f)
            2 -> Pair(42f, 42f)
            else -> Pair(32f, 30f)
        }
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniform3f(uFog, 0.53f, 0.81f, 0.92f)
        GLES20.glUniform1f(uFogS, fogS)
        GLES20.glUniform1f(uFogL, fogL)
        GLES20.glUniform3f(uTint, 1f, 1f, 1f)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, vp, 0)
        for (m in meshes) {
            if (m != null && m.count > 0) {
                bind(m.buf)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, m.count)
            }
        }
        drawShadows()
        // kembali ke program utama untuk entitas
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniform3f(uFog, 0.53f, 0.81f, 0.92f)
        GLES20.glUniform1f(uFogS, fogS)
        GLES20.glUniform1f(uFogL, fogL)
        bind(cube)
        for (e in g.enemies) drawEnemy(e)
        for (c in g.corpses) for (pt in c.parts) wpart(pt.x, pt.y, pt.z, pt.sx, pt.sy, pt.sz, pt.r, pt.g, pt.b)
        if (!g.spin) drawViewModel()
    }
}
