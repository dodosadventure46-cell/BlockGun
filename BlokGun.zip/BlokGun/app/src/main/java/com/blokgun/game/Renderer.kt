package com.blokgun.game
import android.graphics.Bitmap
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
class Renderer(val g: Game) : GLSurfaceView.Renderer {
    companion object {
        private const val VERT = """
            uniform mat4 uProj; uniform mat4 uView; uniform mat4 uModel;
            attribute vec4 aPos; attribute vec2 aUV; attribute float aShade;
            varying vec2 vUV; varying float vShade;
            void main(){ vUV=aUV; vShade=aShade; gl_Position=uProj*uView*uModel*aPos; }"""
        private const val FRAG = """
            precision mediump float; uniform sampler2D uTex; uniform vec3 uTint;
            varying vec2 vUV; varying float vShade;
            void main(){ vec4 c=texture2D(uTex,vUV); gl_FragColor=vec4(c.rgb*uTint*vShade, c.a); }"""
        private const val SVERT = """
            uniform mat4 uProj; uniform mat4 uView; attribute vec4 aPos;
            void main(){ gl_Position=uProj*uView*aPos; }"""
        private const val SFRAG = """
            precision mediump float; uniform vec4 uCol; void main(){ gl_FragColor=uCol; }"""
        private fun fb(a: FloatArray): FloatBuffer {
            val b = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            b.put(a).position(0); return b
        }
        private fun cube(): FloatBuffer {
            // pos(3) uv(2) shade(1) = 6 floats/vertex, 36 vertices, tile putih (15)
            // urutan sisi: +Z, -Z, +Y (atas), -Y (bawah), +X, -X; tiap sisi 2 segitiga (6 vertex)
            val p = arrayOf(
                floatArrayOf(-.5f,-.5f,.5f, .5f,-.5f,.5f, .5f,.5f,.5f, -.5f,-.5f,.5f, .5f,.5f,.5f, -.5f,.5f,.5f),
                floatArrayOf(.5f,-.5f,-.5f, -.5f,-.5f,-.5f, -.5f,.5f,-.5f, .5f,-.5f,-.5f, -.5f,.5f,-.5f, .5f,.5f,-.5f),
                floatArrayOf(-.5f,.5f,.5f, .5f,.5f,.5f, .5f,.5f,-.5f, -.5f,.5f,.5f, .5f,.5f,-.5f, -.5f,.5f,-.5f),
                floatArrayOf(-.5f,-.5f,-.5f, .5f,-.5f,-.5f, .5f,-.5f,.5f, -.5f,-.5f,-.5f, .5f,-.5f,.5f, -.5f,-.5f,.5f),
                floatArrayOf(.5f,-.5f,.5f, .5f,-.5f,-.5f, .5f,.5f,-.5f, .5f,-.5f,.5f, .5f,.5f,-.5f, .5f,.5f,.5f),
                floatArrayOf(-.5f,-.5f,-.5f, -.5f,-.5f,.5f, -.5f,.5f,.5f, -.5f,-.5f,-.5f, -.5f,.5f,.5f, -.5f,.5f,-.5f)
            )
            val sh = floatArrayOf(0.65f, 0.65f, 0.65f, 0.65f, 0.65f, 0.65f, 0.8f, 0.8f, 0.8f, 0.8f, 0.8f, 0.8f, 1f, 1f, 1f, 1f, 1f, 1f, 0.55f, 0.55f, 0.55f, 0.55f, 0.55f, 0.55f, 0.9f, 0.9f, 0.9f, 0.9f, 0.9f, 0.9f, 0.7f, 0.7f, 0.7f, 0.7f, 0.7f, 0.7f)
            val a = FloatArray(36 * 6)
            var k = 0
            for (f in 0..5) for (v in 0..5) {
                val x = p[f][v * 3]; val y = p[f][v * 3 + 1]; val z = p[f][v * 3 + 2]
                a[k++] = x; a[k++] = y; a[k++] = z
                a[k++] = (15 % 4 + 0.5f) / 4f; a[k++] = (15 / 4 + 0.5f) / 4f
                a[k++] = sh[f * 6 + v / 2]
            }
            return fb(a)
        }
    }
    private var prog = 0; private var sProg = 0
    private var aPos = 0; private var aUV = 0; private var aShade = 0
    private var uProj = 0; private var uView = 0; private var uModel = 0; private var uTex = 0; private var uTint = 0
    private var sAPos = 0; private var sUProj = 0; private var sUView = 0; private var sUCol = 0
    private val proj = FloatArray(16); private val view = FloatArray(16); private val model = FloatArray(16); private val tmp = FloatArray(16)
    private var cube: FloatBuffer? = null
    private var terrain: FloatBuffer? = null; private var terrainCount = 0
    private var trunkMesh: FloatBuffer? = null; private var trunkCount = 0
    private var foliageMesh: FloatBuffer? = null; private var foliageCount = 0
    private var rockMesh: FloatBuffer? = null; private var rockCount = 0
    private var roofMesh: FloatBuffer? = null; private var roofCount = 0
    private var shadowQuad: FloatBuffer? = null
    private var tex = 0
    private var scrW = 1; private var scrH = 1
    private var timeAcc = 0f
    private var bobAmp = 0f
    private var last = 0L
    private val sunX = 0.45f; private val sunY = 0.85f; private val sunZ = 0.3f
    private fun buildMesh(tris: FloatArray): FloatBuffer {
        // tris: per triangle 3 vertex, tiap vertex x,y,z (uv=putih, shade=1)
        val n = tris.size / 3
        val a = FloatArray(n * 6)
        var k = 0
        for (i in 0 until n) {
            a[k++] = tris[i * 3]; a[k++] = tris[i * 3 + 1]; a[k++] = tris[i * 3 + 2]
            a[k++] = (15 % 4 + 0.5f) / 4f; a[k++] = (15 / 4 + 0.5f) / 4f; a[k++] = 1f
        }
        return fb(a)
    }
    private fun cylinderMesh(sides: Int, r: Float, h: Float): FloatArray {
        val list = ArrayList<Float>()
        for (i in 0 until sides) {
            val a0 = (i * 2.0 * Math.PI / sides).toFloat()
            val a1 = ((i + 1) * 2.0 * Math.PI / sides).toFloat()
            val x0 = kotlin.math.cos(a0) * r; val z0 = kotlin.math.sin(a0) * r
            val x1 = kotlin.math.cos(a1) * r; val z1 = kotlin.math.sin(a1) * r
            // sisi
            list.add(x0); list.add(0f); list.add(z0); list.add(x1); list.add(0f); list.add(z1); list.add(x1); list.add(h); list.add(z1)
            list.add(x0); list.add(0f); list.add(z0); list.add(x1); list.add(h); list.add(z1); list.add(x0); list.add(h); list.add(z0)
        }
        // tutup atas & bawah (kipas)
        for (i in 0 until sides) {
            val a0 = (i * 2.0 * Math.PI / sides).toFloat()
            val a1 = ((i + 1) * 2.0 * Math.PI / sides).toFloat()
            list.add(0f); list.add(h); list.add(0f); list.add(kotlin.math.cos(a0)*r); list.add(h); list.add(kotlin.math.sin(a0)*r); list.add(kotlin.math.cos(a1)*r); list.add(h); list.add(kotlin.math.sin(a1)*r)
            list.add(0f); list.add(0f); list.add(0f); list.add(kotlin.math.cos(a1)*r); list.add(0f); list.add(kotlin.math.sin(a1)*r); list.add(kotlin.math.cos(a0)*r); list.add(0f); list.add(kotlin.math.sin(a0)*r)
        }
        return list.toFloatArray()
    }
    private fun icoMesh(sub: Int, irregular: Float, seed: Int): FloatArray {
        // oktahedron lalu subdivide
        val verts = ArrayList<FloatArray>()
        val tris = ArrayList<IntArray>()
        val base = arrayOf(floatArrayOf(0f,1f,0f), floatArrayOf(0f,-1f,0f), floatArrayOf(1f,0f,0f), floatArrayOf(-1f,0f,0f), floatArrayOf(0f,0f,1f), floatArrayOf(0f,0f,-1f))
        base.forEach { verts.add(it) }
        val ft = arrayOf(intArrayOf(0,2,4), intArrayOf(0,4,3), intArrayOf(0,3,5), intArrayOf(0,5,2), intArrayOf(1,4,2), intArrayOf(1,3,4), intArrayOf(1,5,3), intArrayOf(1,2,5))
        ft.forEach { tris.add(it) }
        val rnd = java.util.Random(seed.toLong())
        repeat(sub) {
            val nt = ArrayList<IntArray>()
            for (t in tris) {
                val a = verts[t[0]]; val b = verts[t[1]]; val c = verts[t[2]]
                val m01 = floatArrayOf((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2)
                val m12 = floatArrayOf((b[0]+c[0])/2,(b[1]+c[1])/2,(b[2]+c[2])/2)
                val m20 = floatArrayOf((c[0]+a[0])/2,(c[1]+a[1])/2,(c[2]+a[2])/2)
                val i01 = verts.size; verts.add(m01); val i12 = verts.size; verts.add(m12); val i20 = verts.size; verts.add(m20)
                nt.add(intArrayOf(t[0], i01, i20)); nt.add(intArrayOf(t[1], i12, i01)); nt.add(intArrayOf(t[2], i20, i12)); nt.add(intArrayOf(i01, i12, i20))
            }
            tris.clear(); tris.addAll(nt)
        }
        // normalisasi ke bola + irregular
        for (v in verts) {
            val l = kotlin.math.sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]).coerceAtLeast(0.001f)
            v[0]/=l; v[1]/=l; v[2]/=l
            if (irregular > 0f) {
                val f = 1f + (rnd.nextFloat()-0.5f)*2f*irregular
                v[0]*=f; v[1]*=f; v[2]*=f
            }
        }
        val out = ArrayList<Float>()
        for (t in tris) for (i in 0..2) { out.add(verts[t[i]][0]); out.add(verts[t[i]][1]); out.add(verts[t[i]][2]) }
        return out.toFloatArray()
    }
    private fun roofMesh(): FloatArray {
        // prisma segitiga (atap pelana), lebar 1, dalam 1, tinggi 0.4
        val y0 = 0f; val y1 = 0.4f
        val v = arrayOf(floatArrayOf(-.55f,y0,-.55f), floatArrayOf(.55f,y0,-.55f), floatArrayOf(0f,y1,-.55f),
            floatArrayOf(-.55f,y0,.55f), floatArrayOf(.55f,y0,.55f), floatArrayOf(0f,y1,.55f))
        val t = arrayOf(intArrayOf(0,1,2), intArrayOf(3,5,4), intArrayOf(0,3,4), intArrayOf(0,4,1), intArrayOf(1,4,5), intArrayOf(1,5,2), intArrayOf(2,5,3), intArrayOf(2,3,0))
        val out = ArrayList<Float>()
        for (tri in t) for (i in 0..2) { out.add(v[tri[i]][0]); out.add(v[tri[i]][1]); out.add(v[tri[i]][2]) }
        return out.toFloatArray()
    }
    private fun tileUV(tile: Int): Pair<Float,Float> = Pair((tile % 4 + 0.5f) / 4f, (tile / 4 + 0.5f) / 4f)
    private fun buildTerrain() {
        val w = World.SX; val d = World.SZ; val step = 2
        val cells = (w / step) * (d / step)
        val a = FloatArray(cells * 6 * 6) // 6 verts/cell, 6 floats/vert
        var k = 0
        val h = Array(w + 1) { x -> FloatArray(d + 1) { z -> g.world.heightAt(x.coerceAtMost(w - 1), z.coerceAtMost(d - 1)) } }
        for (z in 0 until d step step) for (x in 0 until w step step) {
            val x2 = x + step; val z2 = z + step
            val y00 = h[x][z]; val y10 = h[x2][z]; val y01 = h[x][z2]; val y11 = h[x2][z2]
            // normal per-vertex dari ketinggian tetangga
            fun norm(px: Int, pz: Int): Float {
                val hl = h[(px - 1).coerceAtLeast(0)][pz]; val hr = h[(px + 1).coerceAtMost(w)][pz]
                val hd = h[px][(pz - 1).coerceAtLeast(0)]; val hu = h[px][(pz + 1).coerceAtMost(d)]
                var nx = hl - hr; var ny = 2f * step; var nz = hd - hu
                val l = kotlin.math.sqrt(nx*nx+ny*ny+nz*nz).coerceAtLeast(0.001f)
                nx/=l; ny/=l; nz/=l
                val diff = 0.35f + 0.7f * (nx*sunX + ny*sunY + nz*sunZ).coerceAtLeast(0f)
                return diff.coerceIn(0.35f, 1.05f)
            }
            fun tileOf(px: Int, pz: Int, yy: Float): Int {
                val top = g.world.topY(px.coerceAtMost(w-1), pz.coerceAtMost(d-1))
                val b = if (top < 0) 0 else g.world.get(px.coerceAtMost(w-1), top, pz.coerceAtMost(d-1))
                return when (b) {
                    1 -> 0; 2 -> 1; 3 -> 2; 6 -> 3; 4 -> 4; 7 -> 3; 8 -> 5; else -> 2
                }
            }
            val corners = arrayOf(floatArrayOf(x.toFloat(), y00, z.toFloat()), floatArrayOf(x2.toFloat(), y10, z.toFloat()),
                floatArrayOf(x.toFloat(), y01, z2.toFloat()), floatArrayOf(x2.toFloat(), y11, z2.toFloat()))
            val ci = arrayOf(intArrayOf(x,z), intArrayOf(x2,z), intArrayOf(x,z2), intArrayOf(x2,z2))
            val sh = FloatArray(4) { norm(ci[it][0], ci[it][1]) }
            val tl = IntArray(4) { tileOf(ci[it][0], ci[it][1], corners[it][1]) }
            val uv = Array(4) { tileUV(tl[it]) }
            // dua segitiga: (0,1,2) dan (1,3,2)
            val order = intArrayOf(0,1,2, 1,3,2)
            for (o in order) {
                a[k++] = corners[o][0]; a[k++] = corners[o][1]; a[k++] = corners[o][2]
                a[k++] = uv[o].first; a[k++] = uv[o].second
                a[k++] = sh[o]
            }
        }
        terrain = fb(a); terrainCount = a.size / 6
        g.world.terrainDirty = false
    }
    private fun genTexture(): Int {
        val s = 128; val t = 32 // 4x4 tile, tiap tile 32px
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val rnd = java.util.Random(42)
        fun tile(idx: Int, base: Int, vararg vary: Int) {
            val tx = idx % 4 * t; val ty = idx / 4 * t
            val cr = Color.red(base); val cg = Color.green(base); val cb = Color.blue(base)
            for (y in 0 until t) for (x in 0 until t) {
                val n = (rnd.nextInt(21) - 10)
                val r2 = (cr + n + vary[0]*((x*7+y*13)%5-2)).coerceIn(0,255)
                val g2 = (cg + n + vary.getOrElse(1){0}*((x*5+y*11)%5-2)).coerceIn(0,255)
                val b2 = (cb + n + vary.getOrElse(2){0}*((x*3+y*17)%5-2)).coerceIn(0,255)
                bmp.setPixel(tx+x, ty+y, Color.rgb(r2,g2,b2))
            }
        }
        tile(0, Color.rgb(70,120,40), 18, 22, 10) // rumput
        tile(1, Color.rgb(120,85,50), 14, 12, 8) // tanah
        tile(2, Color.rgb(110,110,115), 16, 16, 18) // batu
        tile(3, Color.rgb(200,185,130), 12, 12, 8) // pasir
        tile(4, Color.rgb(110,75,40), 10, 8, 6) // kayu
        tile(5, Color.rgb(150,150,155), 14, 14, 15) // beton
        tile(6, Color.rgb(90,95,100), 10, 10, 12) // logam
        tile(7, Color.rgb(45,90,35), 16, 20, 10) // daun
        tile(8, Color.rgb(150,60,45), 12, 8, 6) // atap
        tile(9, Color.rgb(130,95,50), 14, 10, 6) // krat
        for (i in 10..14) tile(i, Color.rgb(120,120,120), 10,10,10)
        tile(15, Color.rgb(255,255,255), 0,0,0) // putih (untuk model berwarna)
        val arr = IntArray(1); GLES20.glGenTextures(1, arr, 0); val id = arr[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        bmp.recycle()
        return id
    }
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = build(VERT, FRAG)
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aUV = GLES20.glGetAttribLocation(prog, "aUV")
        aShade = GLES20.glGetAttribLocation(prog, "aShade")
        uProj = GLES20.glGetUniformLocation(prog, "uProj")
        uView = GLES20.glGetUniformLocation(prog, "uView")
        uModel = GLES20.glGetUniformLocation(prog, "uModel")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
        uTint = GLES20.glGetUniformLocation(prog, "uTint")
        sProg = build(SVERT, SFRAG)
        sAPos = GLES20.glGetAttribLocation(sProg, "aPos")
        sUProj = GLES20.glGetUniformLocation(sProg, "uProj")
        sUView = GLES20.glGetUniformLocation(sProg, "uView")
        sUCol = GLES20.glGetUniformLocation(sProg, "uCol")
        cube = cube()
        shadowQuad = fb(floatArrayOf(-.5f,0f,-.5f, .5f,0f,-.5f, .5f,0f,.5f, -.5f,0f,-.5f, .5f,0f,.5f, -.5f,0f,.5f))
        trunkMesh = buildMesh(cylinderMesh(7, 0.12f, 1f)); trunkCount = cylinderMesh(7,0.12f,1f).size/3
        foliageMesh = buildMesh(icoMesh(2, 0.15f, 7)); foliageCount = icoMesh(2,0.15f,7).size/3
        rockMesh = buildMesh(icoMesh(2, 0.35f, 13)); rockCount = icoMesh(2,0.35f,13).size/3
        roofMesh = buildMesh(roofMesh()); roofCount = roofMesh().size/3
        tex = genTexture()
        GLES20.glClearColor(0.55f, 0.7f, 0.9f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glEnableVertexAttribArray(aShade)
    }
    private fun build(v: String, f: String): Int {
        fun sh(t: Int, src: String): Int {
            val id = GLES20.glCreateShader(t)
            GLES20.glShaderSource(id, src); GLES20.glCompileShader(id)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(id, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(id)
                GLES20.glDeleteShader(id)
                throw RuntimeException("Shader gagal compile: " + log)
            }
            return id
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, sh(GLES20.GL_VERTEX_SHADER, v))
        GLES20.glAttachShader(p, sh(GLES20.GL_FRAGMENT_SHADER, f))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Program shader gagal link: " + GLES20.glGetProgramInfoLog(p))
        return p
    }
    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        scrW = w; scrH = h
        GLES20.glViewport(0, 0, w, h)
    }
    private fun bind(buf: FloatBuffer) {
        buf.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, buf)
        buf.position(3)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 24, buf)
        buf.position(5)
        GLES20.glVertexAttribPointer(aShade, 1, GLES20.GL_FLOAT, false, 24, buf)
    }
    private fun drawMesh(buf: FloatBuffer, count: Int, x: Float, y: Float, z: Float, yawDeg: Float, sx: Float, sy: Float, sz: Float, r: Float, g2: Float, b: Float) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.rotateM(model, 0, yawDeg, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, sx, sy, sz)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform3f(uTint, r, g2, b)
        bind(buf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
    }
    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1e9).toFloat().coerceAtMost(0.05f)
        last = now
        g.tick(dt)
        timeAcc += dt
        val moving = !g.paused && g.p.onGround && kotlin.math.hypot(g.p.vx, g.p.vz) > 0.5f
        bobAmp += ((if (moving) 1f else 0f) - bobAmp) * (dt * 10f).coerceAtMost(1f)
        val aspect = scrW.toFloat() / scrH.toFloat()
        val fov = if (g.scope && g.selected < 3 && Game.WEAPONS[g.selected].scope) 35f else if (g.scope) 52f else 70f
        Matrix.perspectiveM(proj, 0, fov, aspect, 0.08f, 180f)
        Matrix.setLookAtM(view, 0, g.p.x, g.p.y + 1.55f, g.p.z,
            g.p.x + Math.cos(g.pitch.toDouble()).toFloat() * Math.sin(g.yaw.toDouble()).toFloat(),
            g.p.y + 1.55f + Math.sin(g.pitch.toDouble()).toFloat(),
            g.p.z - Math.cos(g.pitch.toDouble()).toFloat() * Math.cos(g.yaw.toDouble()).toFloat(),
            0f, 1f, 0f)
        // fog sesuai preset grafis
        val mode = g.graphicsMode
        val fogFar = if (mode <= 0) 26f else if (mode == 1) 34f else 48f
        GLES20.glClearColor(0.55f, 0.7f, 0.9f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uProj, 1, false, proj, 0)
        GLES20.glUniformMatrix4fv(uView, 1, false, view, 0)
        Matrix.setIdentityM(model, 0); GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        if (g.world.terrainDirty || terrain == null) buildTerrain()
        GLES20.glUniform3f(uTint, 1f, 1f, 1f)
        bind(terrain!!)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, terrainCount)
        // objek statis low-poly
        for (o in g.world.objects) {
            when (o.type) {
                Obj.TREE -> {
                    drawMesh(trunkMesh!!, trunkCount, o.x, o.y, o.z, o.rot, o.s, 2.2f*o.s, o.s, 0.42f, 0.28f, 0.15f)
                    drawMesh(foliageMesh!!, foliageCount, o.x, o.y + 2.4f*o.s, o.z, o.rot, 1.1f*o.s, 1.0f*o.s, 1.1f*o.s, 0.28f, 0.55f, 0.2f)
                    drawMesh(foliageMesh!!, foliageCount, o.x + 0.4f*o.s, o.y + 2.0f*o.s, o.z + 0.2f*o.s, o.rot, 0.7f*o.s, 0.7f*o.s, 0.7f*o.s, 0.25f, 0.5f, 0.18f)
                }
                Obj.ROCK -> drawMesh(rockMesh!!, rockCount, o.x, o.y + 0.2f*o.s, o.z, o.rot, o.s, 0.7f*o.s, o.s, 0.45f, 0.45f, 0.48f)
                Obj.BUILDING -> {
                    drawMesh(cube!!, 36, o.x, o.y + 2f, o.z, o.rot, 5f, 4f, 5f, 0.62f, 0.62f, 0.64f) // beton
                    drawMesh(roofMesh!!, roofCount, o.x, o.y + 4f, o.z, o.rot, 5.6f, 1f, 5.6f, 0.6f, 0.22f, 0.18f) // atap
                    drawMesh(cube!!, 36, o.x, o.y + 2f, o.z + 2.52f, o.rot, 3f, 2.2f, 0.1f, 0.1f, 0.15f, 0.25f) // jendela
                }
                Obj.CRATE -> drawMesh(cube!!, 36, o.x, o.y + 0.5f*o.s, o.z, o.rot, o.s, o.s, o.s, 0.55f, 0.4f, 0.22f)
                Obj.BARREL -> drawMesh(trunkMesh!!, trunkCount, o.x, o.y, o.z, 0f, o.s*1.6f, 1.4f, o.s*1.6f, 0.35f, 0.38f, 0.42f)
            }
        }
        drawShadows()
        // musuh & mayat
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uProj, 1, false, proj, 0)
        GLES20.glUniformMatrix4fv(uView, 1, false, view, 0)
        for (e in g.enemies) drawEnemy(e)
        for (c in g.corpses) drawCorpse(c)
        // partikel
        val maxP = if (mode <= 0) 30 else if (mode == 1) 70 else 140
        var drawn = 0
        for (p in g.particles) {
            if (drawn >= maxP) break
            val a = (p.life / p.maxLife).coerceIn(0f, 1f)
            drawMesh(cube!!, 36, p.x, p.y, p.z, 0f, p.size, p.size, p.size, p.r*a, p.g*a, p.b*a)
            drawn++
        }
        // tracer peluru
        for (t in g.tracers) {
            val a = (t.life / 0.08f).coerceIn(0f, 1f)
            val mx = (t.x1 + t.x2) / 2; val my = (t.y1 + t.y2) / 2; val mz = (t.z1 + t.z2) / 2
            val dx = t.x2 - t.x1; val dy = t.y2 - t.y1; val dz = t.z2 - t.z1
            val len = kotlin.math.sqrt(dx*dx+dy*dy+dz*dz).coerceAtLeast(0.001f)
            val yaw = Math.toDegrees(kotlin.math.atan2(dx.toDouble(), dz.toDouble())).toFloat()
            drawMesh(cube!!, 36, mx, my, mz, yaw, 0.04f, 0.04f, len, 1f*a, 0.9f*a, 0.5f*a)
        }
        drawViewModel()
    }
    private fun part(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, r: Float, g2: Float, b: Float, yaw: Float) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.rotateM(model, 0, yaw, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, sx, sy, sz)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform3f(uTint, r, g2, b)
        bind(cube!!)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }
    private fun wpart(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, r: Float, g2: Float, b: Float) = part(x, y, z, sx, sy, sz, r, g2, b, 0f)
    private fun drawEnemy(e: Enemy) {
        val yawDeg = Math.toDegrees(e.yaw.toDouble()).toFloat()
        val walk = e.walk
        val bob = Math.abs(Math.sin(walk.toDouble())).toFloat() * 0.06f
        val legSwing = Math.sin(walk.toDouble()).toFloat() * 0.25f
        val armSwing = Math.sin(walk.toDouble()).toFloat() * 0.3f
        val isZombie = e.type == 0
        val shirt = if (isZombie) floatArrayOf(0.35f, 0.5f, 0.3f) else floatArrayOf(0.25f, 0.25f, 0.3f)
        val skin = if (isZombie) floatArrayOf(0.45f, 0.55f, 0.35f) else floatArrayOf(0.75f, 0.55f, 0.4f)
        // kaki
        part(e.x, e.y + 0.35f + legSwing * 0.3f, e.z, 0.18f, 0.7f, 0.18f, 0.15f, 0.15f, 0.18f, yawDeg)
        part(e.x, e.y + 0.35f - legSwing * 0.3f, e.z, 0.18f, 0.7f, 0.18f, 0.15f, 0.15f, 0.18f, yawDeg)
        // badan
        part(e.x, e.y + 1.05f + bob, e.z, 0.5f, 0.7f, 0.3f, shirt[0], shirt[1], shirt[2], yawDeg)
        // kepala
        part(e.x, e.y + 1.62f + bob, e.z, 0.36f, 0.36f, 0.36f, skin[0], skin[1], skin[2], yawDeg)
        // lengan
        if (isZombie) {
            part(e.x - 0.32f, e.y + 1.1f + bob, e.z + 0.05f, 0.14f, 0.6f, 0.14f, skin[0], skin[1], skin[2], yawDeg)
            part(e.x + 0.32f, e.y + 1.1f + bob, e.z + 0.05f, 0.14f, 0.6f, 0.14f, skin[0], skin[1], skin[2], yawDeg)
        } else {
            part(e.x - 0.32f, e.y + 1.05f + bob - armSwing * 0.2f, e.z, 0.14f, 0.55f, 0.14f, shirt[0], shirt[1], shirt[2], yawDeg)
            part(e.x + 0.32f, e.y + 1.05f + bob + armSwing * 0.2f, e.z, 0.14f, 0.55f, 0.14f, shirt[0], shirt[1], shirt[2], yawDeg)
            // senjata di tangan
            part(e.x, e.y + 1.05f + bob, e.z + 0.35f, 0.08f, 0.08f, 0.5f, 0.1f, 0.1f, 0.12f, yawDeg)
        }
    }
    private fun drawCorpse(c: Corpse) {
        for (p in c.parts) wpart(p.x, p.y, p.z, p.sx, p.sy, p.sz, p.r, p.g, p.b)
    }
    private fun drawShadows() {
        val mode = g.graphicsMode
        if (mode <= 0) return
        GLES20.glUseProgram(sProg)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        shadowQuad!!.position(0)
        GLES20.glEnableVertexAttribArray(sAPos)
        GLES20.glVertexAttribPointer(sAPos, 3, GLES20.GL_FLOAT, false, 12, shadowQuad)
        GLES20.glUniformMatrix4fv(sUProj, 1, false, proj, 0)
        val alpha = if (mode == 1) 0.22f else 0.34f
        val size = if (mode == 1) 0.85f else 1.15f
        for (e in g.enemies) {
            val ty = g.world.heightAt(e.x.toInt(), e.z.toInt()) + 0.02f
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, e.x, ty, e.z)
            Matrix.scaleM(model, 0, size, 1f, size)
            Matrix.multiplyMM(tmp, 0, view, 0, model, 0)
            GLES20.glUniformMatrix4fv(sUView, 1, false, tmp, 0)
            GLES20.glUniform4f(sUCol, 0f, 0f, 0f, alpha)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
        }
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }
    private fun drawViewModel() {
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
        Matrix.setIdentityM(view, 0)
        GLES20.glUniformMatrix4fv(uView, 1, false, view, 0)
        val item = g.selected
        if (item >= 3) {
            val c = Game.BLOCK_COLOR[item - 3]
            drawMesh(cube!!, 36, 0.3f, -0.28f, -0.5f, 0f, 0.15f, 0.15f, 0.15f, Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f)
            return
        }
        if (g.scope && Game.WEAPONS[item].scope) return
        val k = g.kick
        val rl = g.reloadT
        val dip = if (rl > 0) Math.sin((rl / 1.1) * Math.PI).toFloat() * 0.18f else 0f
        val sc = g.scope
        val bobX = Math.sin(g.bob.toDouble()).toFloat() * 0.010f * bobAmp
        val bobY = Math.sin(g.bob.toDouble() * 2.0).toFloat() * 0.012f * bobAmp
        val bx = if (sc) 0f else 0.24f + k * 0.02f + bobX
        val by = if (sc) -0.22f else -0.28f + bobY - dip
        val bz = if (sc) -0.34f else -0.55f + k * 0.06f
        val skinR = 0.75f; val skinG = 0.55f; val skinB = 0.4f
        fun vpart(dx: Float, dy: Float, dz: Float, sx: Float, sy: Float, sz: Float, r: Float, gg: Float, b: Float) {
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, bx + dx, by + dy, bz + dz)
            Matrix.scaleM(model, 0, sx, sy, sz)
            GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
            GLES20.glUniform3f(uTint, r, gg, b)
            bind(cube!!)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
        }
        val sk = g.skin
        val glow = 0.85f + 0.35f * Math.sin(timeAcc * 5.0).toFloat()
        val ar = 1.3f * glow; val ag = 0.24f * glow; val ab = 0.14f * glow
        fun skinTint(r: Float, gg: Float, b: Float): Triple<Float, Float, Float> {
            if (!sk) return Triple(r, gg, b)
            val lum = 0.299f * r + 0.587f * gg + 0.114f * b
            return when {
                lum < 0.12f -> Triple(0.04f, 0.04f, 0.06f)
                r > gg + 0.04f && r > b + 0.04f -> Triple(0.22f, 0.08f, 0.08f)
                else -> { val m = 0.55f + 0.45f * lum; Triple(0.72f * m, 0.10f * m, 0.13f * m) }
            }
        }
        fun vw(dx: Float, dy: Float, dz: Float, sx: Float, sy: Float, sz: Float, r: Float, gg: Float, b: Float) {
            val (tr, tg, tb) = skinTint(r, gg, b)
            vpart(dx, dy, dz, sx, sy, sz, tr, tg, tb)
        }
        var flashX = 0f; var flashY = 0f; var flashZ = -0.6f
        if (item == 0) {
            vw(0f, 0.03f, -0.02f, 0.075f, 0.09f, 0.26f, 0.25f, 0.26f, 0.28f)
            vw(0.039f, 0.03f, -0.07f, 0.005f, 0.08f, 0.012f, 0.1f, 0.1f, 0.12f)
            vw(0.039f, 0.03f, -0.04f, 0.005f, 0.08f, 0.012f, 0.1f, 0.1f, 0.12f)
            vw(0.039f, 0.03f, -0.01f, 0.005f, 0.08f, 0.012f, 0.1f, 0.1f, 0.12f)
            vw(0f, 0.035f, -0.18f, 0.05f, 0.05f, 0.06f, 0.12f, 0.12f, 0.14f)
            vw(0f, -0.01f, 0.02f, 0.07f, 0.05f, 0.18f, 0.18f, 0.18f, 0.2f)
            vw(0.02f, -0.045f, 0.04f, 0.04f, 0.03f, 0.05f, 0.1f, 0.1f, 0.12f)
            vw(0.005f, -0.09f, 0.07f, 0.06f, 0.14f, 0.07f, 0.3f, 0.22f, 0.14f)
            vw(0.005f, -0.165f, 0.07f, 0.065f, 0.02f, 0.075f, 0.15f, 0.15f, 0.17f)
            vw(0f, 0.085f, 0.08f, 0.04f, 0.02f, 0.03f, 0.08f, 0.08f, 0.1f)
            vw(0f, 0.08f, -0.14f, 0.02f, 0.025f, 0.02f, 0.08f, 0.08f, 0.1f)
            if (sk) {
                vpart(0.04f, 0.055f, -0.02f, 0.006f, 0.012f, 0.16f, ar, ag, ab)
                vpart(0.036f, -0.09f, 0.07f, 0.006f, 0.05f, 0.04f, ar, ag, ab)
            }
            if (!sc) {
                vpart(0.015f, -0.10f, 0.07f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB)
                vpart(0.05f, -0.18f, 0.14f, 0.08f, 0.16f, 0.08f, 0.2f, 0.2f, 0.26f)
            }
            flashX = 0f; flashY = 0.035f; flashZ = -0.23f
        } else if (item == 1) {
            vw(0f, 0.01f, -0.02f, 0.08f, 0.07f, 0.3f, 0.16f, 0.16f, 0.18f)
            vw(0f, -0.04f, 0.0f, 0.075f, 0.06f, 0.24f, 0.14f, 0.14f, 0.16f)
            vw(0f, 0.015f, -0.26f, 0.075f, 0.075f, 0.22f, 0.12f, 0.12f, 0.14f)
            vw(0.04f, 0.015f, -0.32f, 0.004f, 0.07f, 0.01f, 0.22f, 0.22f, 0.24f)
            vw(0.04f, 0.015f, -0.26f, 0.004f, 0.07f, 0.01f, 0.22f, 0.22f, 0.24f)
            vw(0.04f, 0.015f, -0.20f, 0.004f, 0.07f, 0.01f, 0.22f, 0.22f, 0.24f)
            vw(0f, 0.02f, -0.46f, 0.04f, 0.04f, 0.22f, 0.08f, 0.08f, 0.1f)
            vw(0f, 0.06f, -0.42f, 0.025f, 0.05f, 0.025f, 0.1f, 0.1f, 0.12f)
            vw(0f, 0.02f, -0.58f, 0.055f, 0.055f, 0.07f, 0.05f, 0.05f, 0.07f)
            vw(0f, -0.10f, -0.02f, 0.06f, 0.13f, 0.07f, 0.12f, 0.12f, 0.14f)
            vw(0f, -0.17f, -0.05f, 0.055f, 0.06f, 0.06f, 0.12f, 0.12f, 0.14f)
            vw(0.005f, -0.11f, 0.12f, 0.06f, 0.14f, 0.07f, 0.15f, 0.1f, 0.08f)
            vw(0f, -0.01f, 0.20f, 0.065f, 0.09f, 0.16f, 0.18f, 0.18f, 0.2f)
            vw(0f, -0.01f, 0.30f, 0.07f, 0.11f, 0.04f, 0.08f, 0.08f, 0.1f)
            vw(0f, 0.06f, -0.04f, 0.055f, 0.02f, 0.24f, 0.08f, 0.08f, 0.1f)
            vw(0f, 0.095f, -0.06f, 0.05f, 0.055f, 0.16f, 0.04f, 0.04f, 0.05f)
            vw(0f, 0.095f, -0.14f, 0.065f, 0.07f, 0.03f, 0.02f, 0.02f, 0.03f)
            vw(0f, 0.095f, 0.02f, 0.065f, 0.07f, 0.03f, 0.02f, 0.02f, 0.03f)
            vw(0f, 0.095f, 0.045f, 0.04f, 0.04f, 0.015f, 0.1f, 0.2f, 0.3f)
            if (sk) {
                vpart(0.04f, 0.03f, -0.26f, 0.006f, 0.014f, 0.16f, ar, ag, ab)
                vpart(0.036f, -0.12f, -0.03f, 0.006f, 0.06f, 0.04f, ar, ag, ab)
                vpart(0.036f, -0.01f, 0.24f, 0.006f, 0.05f, 0.1f, ar, ag, ab)
            }
            if (!sc) {
                vpart(0.015f, -0.12f, 0.12f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB)
                vpart(0.015f, -0.06f, -0.22f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB)
                vpart(0.05f, -0.18f, 0.18f, 0.08f, 0.16f, 0.08f, 0.2f, 0.2f, 0.26f)
                vpart(0.05f, -0.14f, -0.16f, 0.08f, 0.14f, 0.08f, 0.2f, 0.2f, 0.26f)
            }
            flashX = 0f; flashY = 0.02f; flashZ = -0.63f
        } else {
            vw(0f, 0.0f, -0.04f, 0.09f, 0.11f, 0.22f, 0.2f, 0.2f, 0.22f)
            vw(0f, 0.045f, -0.38f, 0.06f, 0.06f, 0.5f, 0.1f, 0.1f, 0.12f)
            vw(0f, 0.005f, -0.36f, 0.04f, 0.04f, 0.42f, 0.15f, 0.15f, 0.17f)
            vw(0f, -0.02f, -0.22f, 0.09f, 0.09f, 0.16f, 0.4f, 0.28f, 0.16f)
            vw(0f, 0.085f, -0.55f, 0.02f, 0.02f, 0.02f, 0.9f, 0.6f, 0.2f)
            vw(0f, -0.02f, 0.12f, 0.08f, 0.12f, 0.12f, 0.38f, 0.26f, 0.15f)
            vw(0f, -0.01f, 0.26f, 0.09f, 0.14f, 0.2f, 0.42f, 0.3f, 0.18f)
            vw(0f, -0.01f, 0.37f, 0.095f, 0.15f, 0.03f, 0.1f, 0.1f, 0.12f)
            vw(0.02f, -0.06f, 0.06f, 0.04f, 0.03f, 0.05f, 0.1f, 0.1f, 0.12f)
            if (sk) {
                vpart(0.045f, 0.025f, -0.04f, 0.006f, 0.014f, 0.14f, ar, ag, ab)
                vpart(0.045f, -0.02f, -0.22f, 0.006f, 0.05f, 0.08f, ar, ag, ab)
            }
            if (!sc) {
                vpart(0.015f, -0.12f, 0.10f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB)
                vpart(0.015f, -0.07f, -0.20f, 0.09f, 0.09f, 0.09f, skinR, skinG, skinB)
                vpart(0.05f, -0.18f, 0.16f, 0.08f, 0.16f, 0.08f, 0.2f, 0.2f, 0.26f)
                vpart(0.05f, -0.15f, -0.14f, 0.08f, 0.14f, 0.08f, 0.2f, 0.2f, 0.26f)
            }
            flashX = 0f; flashY = 0.045f; flashZ = -0.66f
        }
        if (g.flashT > 0f) {
            vpart(flashX, flashY, flashZ, 0.11f, 0.11f, 0.09f, 1f, 0.85f, 0.3f)
        }
    }
}
