package com.blokgun.game

import android.graphics.Bitmap
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Penampung vertex: x, y, z, u, v, shade per titik. */
class FB {
    var a = FloatArray(1 shl 15)
    var n = 0

    private fun v(x: Float, y: Float, z: Float, u: Float, w: Float, s: Float) {
        if (n + 6 > a.size) a = a.copyOf(a.size * 2)
        a[n++] = x; a[n++] = y; a[n++] = z; a[n++] = u; a[n++] = w; a[n++] = s
    }

    fun quad(
        x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float, x3: Float, y3: Float, z3: Float,
        tile: Int, s: Float
    ) {
        val tx = tile % 4
        val ty = tile / 4
        val u0 = tx * 0.25f + 0.002f
        val u1 = (tx + 1) * 0.25f - 0.002f
        val v0 = ty * 0.25f + 0.002f
        val v1 = (ty + 1) * 0.25f - 0.002f
        v(x0, y0, z0, u0, v1, s); v(x1, y1, z1, u1, v1, s); v(x2, y2, z2, u1, v0, s)
        v(x0, y0, z0, u0, v1, s); v(x2, y2, z2, u1, v0, s); v(x3, y3, z3, u0, v0, s)
    }

    fun toBuffer(): FloatBuffer {
        val bb = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder())
        val fb = bb.asFloatBuffer()
        fb.put(a, 0, n)
        fb.position(0)
        return fb
    }
}

class ChunkMesh(val buf: FloatBuffer, val count: Int)

object Mesher {
    private val SHADE = floatArrayOf(1f, 0.5f, 0.8f, 0.8f, 0.65f, 0.65f)

    fun face(fb: FB, f: Int, x: Float, y: Float, z: Float, tile: Int) {
        val x1 = x + 1f
        val y1 = y + 1f
        val z1 = z + 1f
        val s = SHADE[f]
        when (f) {
            0 -> fb.quad(x, y1, z1, x1, y1, z1, x1, y1, z, x, y1, z, tile, s)
            1 -> fb.quad(x, y, z, x1, y, z, x1, y, z1, x, y, z1, tile, s)
            2 -> fb.quad(x1, y, z1, x1, y, z, x1, y1, z, x1, y1, z1, tile, s)
            3 -> fb.quad(x, y, z, x, y, z1, x, y1, z1, x, y1, z, tile, s)
            4 -> fb.quad(x, y, z1, x1, y, z1, x1, y1, z1, x, y1, z1, tile, s)
            else -> fb.quad(x1, y, z, x, y, z, x, y1, z, x1, y1, z, tile, s)
        }
    }

    // atlas 4x4: 0 rumput atas, 1 rumput samping, 2 tanah, 3 batu, 4 kayu samping,
    // 5 kayu atas, 6 daun, 7 pasir, 8 papan, 15 putih
    fun tile(b: Int, f: Int): Int = when (b) {
        1 -> if (f == 0) 0 else if (f == 1) 2 else 1
        2 -> 2
        3 -> 3
        4 -> if (f <= 1) 5 else 4
        5 -> 6
        6 -> 7
        7 -> 8
        else -> 15
    }

    fun build(w: World, cx: Int, cz: Int, fb: FB): ChunkMesh {
        fb.n = 0
        val cs = World.CS
        for (y in 0 until World.SY) for (z in cz * cs until (cz + 1) * cs) for (x in cx * cs until (cx + 1) * cs) {
            val b = w.get(x, y, z)
            if (b == 0) continue
            val fx = x.toFloat()
            val fy = y.toFloat()
            val fz = z.toFloat()
            if (w.get(x, y + 1, z) == 0) face(fb, 0, fx, fy, fz, tile(b, 0))
            if (y > 0 && w.get(x, y - 1, z) == 0) face(fb, 1, fx, fy, fz, tile(b, 1))
            if (w.get(x + 1, y, z) == 0) face(fb, 2, fx, fy, fz, tile(b, 2))
            if (w.get(x - 1, y, z) == 0) face(fb, 3, fx, fy, fz, tile(b, 3))
            if (w.get(x, y, z + 1) == 0) face(fb, 4, fx, fy, fz, tile(b, 4))
            if (w.get(x, y, z - 1) == 0) face(fb, 5, fx, fy, fz, tile(b, 5))
        }
        return ChunkMesh(fb.toBuffer(), fb.n / 6)
    }
}

class Renderer(private val g: Game) : GLSurfaceView.Renderer {
    private val VS = """
        attribute vec3 aPos;
        attribute vec2 aUV;
        attribute float aShade;
        uniform mat4 uMVP;
        varying vec2 vUV;
        varying float vShade;
        varying float vFog;
        void main() {
            gl_Position = uMVP * vec4(aPos, 1.0);
            vUV = aUV;
            vShade = aShade;
            vFog = clamp((gl_Position.w - 30.0) / 28.0, 0.0, 1.0);
        }
    """.trimIndent()

    private val FS = """
        precision mediump float;
        uniform sampler2D uTex;
        uniform vec3 uTint;
        uniform vec3 uFog;
        varying vec2 vUV;
        varying float vShade;
        varying float vFog;
        void main() {
            vec3 col = texture2D(uTex, vUV).rgb * uTint * vShade;
            gl_FragColor = vec4(mix(col, uFog, vFog), 1.0);
        }
    """.trimIndent()

    private var prog = 0
    private var tex = 0
    private var uMVP = 0
    private var uTint = 0
    private var uTex = 0
    private var uFog = 0
    private var aPos = 0
    private var aUV = 0
    private var aShade = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    private val meshes = arrayOfNulls<ChunkMesh>(World.NCX * World.NCZ)
    private val fb = FB()
    private var cube: FloatBuffer = FB().toBuffer()
    private var last = 0L

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val st = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun makeAtlas(): Bitmap {
        val bm = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val r = java.util.Random(42)
        fun px(t: Int, x: Int, y: Int, cr: Int, cg: Int, cb: Int, v: Int) {
            val n = if (v > 0) r.nextInt(v * 2 + 1) - v else 0
            bm.setPixel(
                (t % 4) * 16 + x, (t / 4) * 16 + y,
                Color.rgb((cr + n).coerceIn(0, 255), (cg + n).coerceIn(0, 255), (cb + n).coerceIn(0, 255))
            )
        }
        for (y in 0 until 16) for (x in 0 until 16) {
            px(0, x, y, 95, 160, 60, 14)
            if (y < 4 || (y == 4 && x % 3 == 0)) px(1, x, y, 95, 160, 60, 14) else px(1, x, y, 125, 85, 50, 12)
            px(2, x, y, 125, 85, 50, 12)
            px(3, x, y, 125, 125, 125, 16)
            if (x % 4 == 0) px(4, x, y, 70, 50, 30, 6) else px(4, x, y, 105, 78, 45, 8)
            val dd = hypot(x - 7.5f, y - 7.5f)
            if (dd.toInt() % 3 == 0) px(5, x, y, 95, 70, 40, 6) else px(5, x, y, 150, 115, 70, 8)
            px(6, x, y, 45, 120, 35, 25)
            px(7, x, y, 225, 210, 150, 8)
            if (y % 4 == 3) px(8, x, y, 120, 85, 45, 5) else px(8, x, y, 185, 145, 85, 8)
            px(15, x, y, 255, 255, 255, 0)
        }
        return bm
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.53f, 0.81f, 0.92f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs = compile(GLES20.GL_VERTEX_SHADER, VS)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FS)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        uMVP = GLES20.glGetUniformLocation(prog, "uMVP")
        uTint = GLES20.glGetUniformLocation(prog, "uTint")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
        uFog = GLES20.glGetUniformLocation(prog, "uFog")
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aUV = GLES20.glGetAttribLocation(prog, "aUV")
        aShade = GLES20.glGetAttribLocation(prog, "aShade")

        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        tex = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val bm = makeAtlas()
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bm, 0)
        bm.recycle()

        val cf = FB()
        for (f in 0..5) Mesher.face(cf, f, -0.5f, -0.5f, -0.5f, 15)
        cube = cf.toBuffer()

        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glEnableVertexAttribArray(aShade)
        last = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        Matrix.perspectiveM(proj, 0, 72f, width.toFloat() / height.toFloat(), 0.08f, 120f)
    }

    private fun bind(buf: FloatBuffer) {
        buf.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, buf)
        buf.position(3)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 24, buf)
        buf.position(5)
        GLES20.glVertexAttribPointer(aShade, 1, GLES20.GL_FLOAT, false, 24, buf)
        buf.position(0)
    }

    private fun part(
        ex: Float, ey: Float, ez: Float, yawRad: Float,
        lx: Float, ly: Float, lz: Float, sx: Float, sy: Float, sz: Float,
        cr: Float, cg: Float, cb: Float
    ) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, ex, ey, ez)
        Matrix.rotateM(model, 0, -Math.toDegrees(yawRad.toDouble()).toFloat(), 0f, 1f, 0f)
        Matrix.translateM(model, 0, lx, ly, lz)
        Matrix.scaleM(model, 0, sx, sy, sz)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glUniform3f(uTint, cr, cg, cb)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    private fun drawEnemy(e: Enemy) {
        val h = e.hit > 0f
        val x = e.x
        val y = e.y
        val z = e.z
        val yw = e.yaw
        if (e.type == 0) {
            part(x, y, z, yw, 0f, 0.4f, 0f, 0.45f, 0.8f, 0.25f, if (h) 1f else 0.15f, if (h) 0.3f else 0.25f, if (h) 0.3f else 0.5f)
            part(x, y, z, yw, 0f, 1.1f, 0f, 0.55f, 0.7f, 0.3f, if (h) 1f else 0.2f, if (h) 0.3f else 0.5f, if (h) 0.3f else 0.55f)
            part(x, y, z, yw, 0f, 1.62f, 0f, 0.42f, 0.42f, 0.42f, if (h) 1f else 0.4f, if (h) 0.3f else 0.7f, if (h) 0.3f else 0.35f)
            part(x, y, z, yw, -0.38f, 1.25f, -0.35f, 0.18f, 0.18f, 0.6f, if (h) 1f else 0.4f, if (h) 0.3f else 0.7f, if (h) 0.3f else 0.35f)
            part(x, y, z, yw, 0.38f, 1.25f, -0.35f, 0.18f, 0.18f, 0.6f, if (h) 1f else 0.4f, if (h) 0.3f else 0.7f, if (h) 0.3f else 0.35f)
        } else {
            part(x, y, z, yw, 0f, 0.4f, 0f, 0.45f, 0.8f, 0.25f, if (h) 1f else 0.2f, if (h) 0.3f else 0.2f, if (h) 0.3f else 0.25f)
            part(x, y, z, yw, 0f, 1.1f, 0f, 0.55f, 0.7f, 0.3f, if (h) 1f else 0.55f, if (h) 0.3f else 0.18f, if (h) 0.3f else 0.18f)
            part(x, y, z, yw, 0f, 1.62f, 0f, 0.42f, 0.42f, 0.42f, if (h) 1f else 0.9f, if (h) 0.3f else 0.72f, if (h) 0.3f else 0.55f)
            part(x, y, z, yw, 0.3f, 1.2f, -0.4f, 0.1f, 0.12f, 0.55f, 0.08f, 0.08f, 0.08f)
        }
    }

    private fun vpart(
        x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float,
        cr: Float, cg: Float, cb: Float
    ) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.scaleM(model, 0, sx, sy, sz)
        Matrix.multiplyMM(mvp, 0, proj, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glUniform3f(uTint, cr, cg, cb)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    private fun drawViewModel() {
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
        val item = g.selected
        val k = g.kick
        if (item < 3) {
            val len = if (item == 0) 0.32f else 0.55f
            val body = if (item == 2) 0.1f else 0.07f
            val zc = -0.55f + k * 0.07f
            vpart(0.26f, -0.26f + k * 0.01f, zc, body, 0.09f, len, 0.18f, 0.18f, 0.2f)
            vpart(0.26f, -0.35f, zc + len * 0.3f, 0.06f, 0.14f, 0.08f, 0.35f, 0.25f, 0.15f)
            if (g.flashT > 0f) {
                vpart(0.26f, -0.25f, zc - len / 2f - 0.07f, 0.1f, 0.1f, 0.08f, 1f, 0.85f, 0.3f)
            }
        } else {
            val c = Game.BLOCK_COLOR[item - 3]
            vpart(0.3f, -0.28f, -0.5f, 0.15f, 0.15f, 0.15f, Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f)
        }
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0f else min((now - last) / 1e9f, 0.05f)
        last = now
        g.tick(dt)

        val w = g.world
        for (i in 0 until World.NCX * World.NCZ) {
            if (w.dirty[i] || meshes[i] == null) {
                w.dirty[i] = false
                meshes[i] = Mesher.build(w, i % World.NCX, i / World.NCX, fb)
            }
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val ex = g.p.x
        val ey = g.p.y + 1.62f
        val ez = g.p.z
        val cp = cos(g.pitch)
        Matrix.setLookAtM(
            view, 0, ex, ey, ez,
            ex + sin(g.yaw) * cp, ey + sin(g.pitch), ez - cos(g.yaw) * cp,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniform3f(uFog, 0.53f, 0.81f, 0.92f)
        GLES20.glUniform3f(uTint, 1f, 1f, 1f)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, vp, 0)
        for (m in meshes) {
            if (m != null && m.count > 0) {
                bind(m.buf)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, m.count)
            }
        }

        bind(cube)
        for (e in g.enemies) drawEnemy(e)
        if (!g.spin) drawViewModel()
    }
}
