package com.blokgun.game
import kotlin.math.abs
import kotlin.math.floor
import kotlin.random.Random
class Hit {
    var found = false
    var dist = 0f
    var bx = 0
    var by = 0
    var bz = 0
    var px = 0
    var py = 0
    var pz = 0
}
/** Objek statis low-poly di dunia (bukan kubus voxel). */
class Obj(val type: Int, val x: Float, val y: Float, val z: Float, val s: Float, val rot: Float) {
    companion object {
        const val TREE = 0
        const val ROCK = 1
        const val BUILDING = 2
        const val CRATE = 3
        const val BARREL = 4
    }
}
/** AABB padat untuk tabrakan objek (bangunan, batu, krat). */
class AABB(val x0: Float, val y0: Float, val z0: Float, val x1: Float, val y1: Float, val z1: Float)
class World {
    companion object {
        const val SX = 128
        const val SY = 32
        const val SZ = 128
        const val CS = 16
        const val NCX = SX / CS
        const val NCZ = SZ / CS
    }
    val blocks = ByteArray(SX * SY * SZ)
    val dirty = BooleanArray(NCX * NCZ)
    val objects = ArrayList<Obj>()
    val solids = ArrayList<AABB>()
    @Volatile var terrainDirty = true
    private fun idx(x: Int, y: Int, z: Int) = (y * SZ + z) * SX + x
    fun get(x: Int, y: Int, z: Int): Int {
        if (x < 0 || x >= SX || z < 0 || z >= SZ || y < 0 || y >= SY) return 0
        return blocks[idx(x, y, z)].toInt()
    }
    /** Tinggi permukaan halus (float) untuk mesh terrain realistis. */
    fun heightAt(x: Int, z: Int): Float {
        val ty = topY(x, z)
        return if (ty < 0) 0f else ty + 1f
    }
    fun solid(x: Int, y: Int, z: Int): Boolean {
        if (y < 0) return true
        if (y >= SY) return false
        if (x < 0 || x >= SX || z < 0 || z >= SZ) return true
        return blocks[idx(x, y, z)].toInt() != 0
    }
    private fun mark(x: Int, z: Int) {
        if (x < 0 || x >= SX || z < 0 || z >= SZ) return
        dirty[(x / CS) + (z / CS) * NCX] = true
        terrainDirty = true
    }
    fun set(x: Int, y: Int, z: Int, id: Int): Boolean {
        if (x < 0 || x >= SX || z < 0 || z >= SZ || y < 0 || y >= SY) return false
        blocks[idx(x, y, z)] = id.toByte()
        mark(x, z)
        if (x % CS == 0) mark(x - 1, z)
        if (x % CS == CS - 1) mark(x + 1, z)
        if (z % CS == 0) mark(x, z - 1)
        if (z % CS == CS - 1) mark(x, z + 1)
        return true
    }
    fun topY(x: Int, z: Int): Int {
        if (x < 0 || x >= SX || z < 0 || z >= SZ) return -1
        for (y in SY - 1 downTo 0) if (blocks[idx(x, y, z)].toInt() != 0) return y
        return -1
    }
    private fun hash(x: Int, z: Int, seed: Int): Float {
        var h = x * 374761393 + z * 668265263 + seed * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }
    private fun noise(x: Float, z: Float, seed: Int): Float {
        val xi = floor(x).toInt()
        val zi = floor(z).toInt()
        val fx = x - xi
        val fz = z - zi
        val sx = fx * fx * (3f - 2f * fx)
        val sz = fz * fz * (3f - 2f * fz)
        val a = hash(xi, zi, seed)
        val b = hash(xi + 1, zi, seed)
        val c = hash(xi, zi + 1, seed)
        val d = hash(xi + 1, zi + 1, seed)
        val top = a + (b - a) * sx
        val bot = c + (d - c) * sx
        return top + (bot - top) * sz
    }
    private fun addSolid(x: Float, y0: Float, z: Float, w: Float, h: Float, d: Float) {
        solids.add(AABB(x - w / 2, y0, z - d / 2, x + w / 2, y0 + h, z + d / 2))
    }
    fun generate(seed: Int) {
        java.util.Arrays.fill(blocks, 0.toByte())
        objects.clear()
        solids.clear()
        val rnd = Random(seed)
        val hm = IntArray(SX * SZ)
        for (z in 0 until SZ) for (x in 0 until SX) {
            val hf = 10f + noise(x / 22f, z / 22f, seed) * 11f + noise(x / 7f, z / 7f, seed + 7) * 3f
            val hi = hf.toInt().coerceIn(3, 23)
            hm[z * SX + x] = hi
            for (y in 0..hi) {
                val b = when {
                    y == hi -> if (hi <= 11) 6 else 1
                    y >= hi - 3 -> if (hi <= 11) 6 else 2
                    else -> 3
                }
                blocks[idx(x, y, z)] = b.toByte()
            }
        }
        val cx = SX / 2; val cz = SZ / 2
        for (i in 0 until 90) {
            val x = rnd.nextInt(4, SX - 4)
            val z = rnd.nextInt(4, SZ - 4)
            if (abs(x - cx) < 6 && abs(z - cz) < 6) continue
            val h = hm[z * SX + x]
            if (h <= 11) continue
            if (rnd.nextFloat() < 0.15f) continue
            val s = 0.8f + rnd.nextFloat() * 0.7f
            objects.add(Obj(Obj.TREE, x + 0.5f, h + 1f, z + 0.5f, s, rnd.nextFloat() * 360f))
        }
        for (i in 0 until 28) {
            val x = rnd.nextInt(4, SX - 4)
            val z = rnd.nextInt(4, SZ - 4)
            if (abs(x - cx) < 5 && abs(z - cz) < 5) continue
            val h = hm[z * SX + x]
            val s = 0.6f + rnd.nextFloat() * 1.4f
            objects.add(Obj(Obj.ROCK, x + 0.5f, h + 1f, z + 0.5f, s, rnd.nextFloat() * 360f))
            addSolid(x + 0.5f, h + 1f, z + 0.5f, s * 0.9f, s * 0.7f, s * 0.9f)
        }
        val bx = cx + 22; val bz = cz + 18
        for (i in 0 until 8) {
            val ox = bx + rnd.nextInt(-12, 12)
            val oz = bz + rnd.nextInt(-12, 12)
            if (ox < 4 || ox >= SX - 4 || oz < 4 || oz >= SZ - 4) continue
            val h = hm[oz * SX + ox]
            val w = 4f + rnd.nextFloat() * 4f
            val d = 4f + rnd.nextFloat() * 4f
            val ht = 3.5f + rnd.nextFloat() * 3f
            objects.add(Obj(Obj.BUILDING, ox + 0.5f, h + 1f, oz + 0.5f, 1f, rnd.nextFloat() * 360f))
            addSolid(ox + 0.5f, h + 1f, oz + 0.5f, w, ht, d)
            for (j in 0 until 4) {
                val cxx = ox + rnd.nextFloat() * 6f - 3f
                val czz = oz + rnd.nextFloat() * 6f - 3f
                val ch = topY(cxx.toInt(), czz.toInt()) + 1f
                if (rnd.nextBoolean()) {
                    objects.add(Obj(Obj.CRATE, cxx, ch, czz, 0.8f + rnd.nextFloat() * 0.5f, rnd.nextFloat() * 360f))
                    addSolid(cxx, ch, czz, 1f, 1f, 1f)
                } else {
                    objects.add(Obj(Obj.BARREL, cxx, ch, czz, 0.7f, 0f))
                    addSolid(cxx, ch, czz, 0.8f, 1.2f, 0.8f)
                }
            }
        }
        java.util.Arrays.fill(dirty, true)
        terrainDirty = true
    }
    fun hits(x: Float, y: Float, z: Float, bw: Float, bh: Float): Boolean {
        val hw = bw / 2f
        for (b in solids) {
            if (x + hw > b.x0 && x - hw < b.x1 &&
                y + bh > b.y0 && y < b.y1 &&
                z + hw > b.z0 && z - hw < b.z1) return true
        }
        val x0 = floor(x - hw).toInt()
        val x1 = floor(x + hw - 0.0001f).toInt()
        val y0 = floor(y).toInt()
        val y1 = floor(y + bh - 0.0001f).toInt()
        val z0 = floor(z - hw).toInt()
        val z1 = floor(z + hw - 0.0001f).toInt()
        for (yy in y0..y1) for (zz in z0..z1) for (xx in x0..x1) {
            if (solid(xx, yy, zz)) return true
        }
        return false
    }
    fun raycast(ox: Float, oy: Float, oz: Float, dx: Float, dy: Float, dz: Float, maxD: Float, out: Hit) {
        out.found = false
        var lx = floor(ox).toInt()
        var ly = floor(oy).toInt()
        var lz = floor(oz).toInt()
        var t = 0f
        while (t < maxD) {
            t += 0.05f
            val cx = floor(ox + dx * t).toInt()
            val cy = floor(oy + dy * t).toInt()
            val cz = floor(oz + dz * t).toInt()
            if (cx != lx || cy != ly || cz != lz) {
                if (get(cx, cy, cz) != 0) {
                    out.found = true
                    out.dist = t
                    out.bx = cx; out.by = cy; out.bz = cz
                    out.px = lx; out.py = ly; out.pz = lz
                    return
                }
                lx = cx; ly = cy; lz = cz
            }
        }
    }
}
