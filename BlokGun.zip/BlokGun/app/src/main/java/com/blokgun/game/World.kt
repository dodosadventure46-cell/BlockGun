package com.blokgun.game

import kotlin.math.abs
import kotlin.math.floor
import kotlin.random.Random

class Hit {
    var found = false
    var dist = 0f
    var bx = 0
    var by = 0
    var bz = 0
    var px = 0
    var py = 0
    var pz = 0
}

class World {
    companion object {
        const val SX = 128
        const val SY = 32
        const val SZ = 128
        const val CS = 16
        const val NCX = SX / CS
        const val NCZ = SZ / CS
    }

    val blocks = ByteArray(SX * SY * SZ)
    val dirty = BooleanArray(NCX * NCZ)

    private fun idx(x: Int, y: Int, z: Int) = (y * SZ + z) * SX + x

    /** Id blok (0 = udara). Di luar dunia dianggap udara. */
    fun get(x: Int, y: Int, z: Int): Int {
        if (x < 0 || x >= SX || z < 0 || z >= SZ || y < 0 || y >= SY) return 0
        return blocks[idx(x, y, z)].toInt()
    }

    /** Untuk tabrakan: sisi dan dasar dunia dianggap tembok. */
    fun solid(x: Int, y: Int, z: Int): Boolean {
        if (y < 0) return true
        if (y >= SY) return false
        if (x < 0 || x >= SX || z < 0 || z >= SZ) return true
        return blocks[idx(x, y, z)].toInt() != 0
    }

    private fun mark(x: Int, z: Int) {
        if (x < 0 || x >= SX || z < 0 || z >= SZ) return
        dirty[(x / CS) + (z / CS) * NCX] = true
    }

    fun set(x: Int, y: Int, z: Int, id: Int): Boolean {
        if (x < 0 || x >= SX || z < 0 || z >= SZ || y < 0 || y >= SY) return false
        blocks[idx(x, y, z)] = id.toByte()
        mark(x, z)
        if (x % CS == 0) mark(x - 1, z)
        if (x % CS == CS - 1) mark(x + 1, z)
        if (z % CS == 0) mark(x, z - 1)
        if (z % CS == CS - 1) mark(x, z + 1)
        return true
    }

    fun topY(x: Int, z: Int): Int {
        if (x < 0 || x >= SX || z < 0 || z >= SZ) return -1
        for (y in SY - 1 downTo 0) if (blocks[idx(x, y, z)].toInt() != 0) return y
        return -1
    }

    private fun hash(x: Int, z: Int, seed: Int): Float {
        var h = x * 374761393 + z * 668265263 + seed * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }

    private fun noise(x: Float, z: Float, seed: Int): Float {
        val xi = floor(x).toInt()
        val zi = floor(z).toInt()
        val fx = x - xi
        val fz = z - zi
        val sx = fx * fx * (3f - 2f * fx)
        val sz = fz * fz * (3f - 2f * fz)
        val a = hash(xi, zi, seed)
        val b = hash(xi + 1, zi, seed)
        val c = hash(xi, zi + 1, seed)
        val d = hash(xi + 1, zi + 1, seed)
        val top = a + (b - a) * sx
        val bot = c + (d - c) * sx
        return top + (bot - top) * sz
    }

    fun generate(seed: Int) {
        java.util.Arrays.fill(blocks, 0.toByte())
        val rnd = Random(seed)
        val hm = IntArray(SX * SZ)
        for (z in 0 until SZ) for (x in 0 until SX) {
            val hf = 10f + noise(x / 22f, z / 22f, seed) * 11f + noise(x / 7f, z / 7f, seed + 7) * 3f
            val hi = hf.toInt().coerceIn(3, 23)
            hm[z * SX + x] = hi
            for (y in 0..hi) {
                val b = when {
                    y == hi -> if (hi <= 11) 6 else 1
                    y >= hi - 3 -> if (hi <= 11) 6 else 2
                    else -> 3
                }
                blocks[idx(x, y, z)] = b.toByte()
            }
        }
        // pohon
        for (z in 3 until SZ - 3) for (x in 3 until SX - 3) {
            if (abs(x - SX / 2) < 4 && abs(z - SZ / 2) < 4) continue
            if (rnd.nextFloat() >= 0.012f) continue
            val h = hm[z * SX + x]
            if (blocks[idx(x, h, z)].toInt() != 1) continue
            val th = 4 + rnd.nextInt(2)
            for (i in 1..th) blocks[idx(x, h + i, z)] = 4
            val top = h + th
            for (dy in -1..2) {
                val r = if (dy >= 2) 1 else 2
                for (dz in -r..r) for (dx in -r..r) {
                    val xx = x + dx
                    val yy = top + dy
                    val zz = z + dz
                    if (yy < SY && blocks[idx(xx, yy, zz)].toInt() == 0) blocks[idx(xx, yy, zz)] = 5
                }
            }
        }
        java.util.Arrays.fill(dirty, true)
    }

    fun hits(x: Float, y: Float, z: Float, bw: Float, bh: Float): Boolean {
        val hw = bw / 2f
        val x0 = floor(x - hw).toInt()
        val x1 = floor(x + hw - 0.0001f).toInt()
        val y0 = floor(y).toInt()
        val y1 = floor(y + bh - 0.0001f).toInt()
        val z0 = floor(z - hw).toInt()
        val z1 = floor(z + hw - 0.0001f).toInt()
        for (yy in y0..y1) for (zz in z0..z1) for (xx in x0..x1) {
            if (solid(xx, yy, zz)) return true
        }
        return false
    }

    fun raycast(ox: Float, oy: Float, oz: Float, dx: Float, dy: Float, dz: Float, maxD: Float, out: Hit) {
        out.found = false
        var lx = floor(ox).toInt()
        var ly = floor(oy).toInt()
        var lz = floor(oz).toInt()
        var t = 0f
        while (t < maxD) {
            t += 0.05f
            val cx = floor(ox + dx * t).toInt()
            val cy = floor(oy + dy * t).toInt()
            val cz = floor(oz + dz * t).toInt()
            if (cx != lx || cy != ly || cz != lz) {
                if (get(cx, cy, cz) != 0) {
                    out.found = true
                    out.dist = t
                    out.bx = cx; out.by = cy; out.bz = cz
                    out.px = lx; out.py = ly; out.pz = lz
                    return
                }
                lx = cx; ly = cy; lz = cz
            }
        }
    }
}
