package com.blokgun.game

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity(), HudListener {
    private lateinit var glView: GLSurfaceView
    private lateinit var hud: Hud
    private lateinit var overlay: FrameLayout
    private val game = Game()
    private var inGame = false
    private val sensVals = floatArrayOf(0.0045f, 0.007f, 0.011f)
    private val sensNames = arrayOf("RENDAH", "SEDANG", "TINGGI")
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT

    private val prefs by lazy { getSharedPreferences("blokgun", MODE_PRIVATE) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        Sfx.setup()
        Sfx.enabled = prefs.getBoolean("sound", true)
        game.sens = sensVals[prefs.getInt("sens", 1).coerceIn(0, 2)]
        game.graphicsMode = prefs.getInt("graphics", 1).coerceIn(0, 2)
        game.autoJump = prefs.getBoolean("auto_jump", true)
        game.onLevel = { lvl ->
            if (lvl > prefs.getInt("best", 1)) prefs.edit().putInt("best", lvl).apply()
        }

        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        glView.setEGLConfigChooser(8, 8, 8, 0, 16, 0)
        glView.setRenderer(Renderer(game))
        glView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        hud = Hud(this, game, this)
        overlay = FrameLayout(this)

        val root = FrameLayout(this)
        root.addView(glView, FrameLayout.LayoutParams(MP, MP))
        root.addView(hud, FrameLayout.LayoutParams(MP, MP))
        root.addView(overlay, FrameLayout.LayoutParams(MP, MP))
        setContentView(root)

        showMain()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }

    override fun onPause() {
        super.onPause()
        glView.onPause()
        if (inGame && !game.paused && !game.dead) showPause()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
    }

    override fun onDestroy() {
        super.onDestroy()
        Sfx.release()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (inGame && !game.paused && !game.dead) showPause() else super.onBackPressed()
    }

    // ---------- UI menu ----------
    private fun panel(title: String, sub: String?, items: List<Pair<String, () -> Unit>>) {
        overlay.removeAllViews()
        overlay.setBackgroundColor(Color.argb(150, 0, 0, 0))
        overlay.isClickable = true

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(24), dp(12), dp(24), dp(12))

        val t = TextView(this)
        t.text = title
        t.textSize = 34f
        t.setTextColor(Color.rgb(255, 220, 80))
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        col.addView(t)

        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.textSize = 14f
            s.setTextColor(Color.WHITE)
            s.gravity = Gravity.CENTER
            s.setPadding(0, 0, 0, dp(6))
            col.addView(s)
        }

        for ((label, action) in items) {
            val b = Button(this)
            b.text = label
            b.setTextColor(Color.WHITE)
            b.textSize = 15f
            b.setBackgroundColor(Color.rgb(60, 130, 60))
            b.setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(dp(290), dp(46))
            lp.topMargin = dp(8)
            col.addView(b, lp)
        }

        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(col, ViewGroup.LayoutParams(MP, MP))
        overlay.addView(sv, FrameLayout.LayoutParams(MP, MP))
    }

    private fun clearOverlay() {
        overlay.removeAllViews()
        overlay.setBackgroundColor(Color.TRANSPARENT)
        overlay.isClickable = false
    }

    private fun showMain() {
        inGame = false
        game.paused = true
        game.spin = true
        hud.reset()
        hud.visibility = View.INVISIBLE
        val best = prefs.getInt("best", 1)
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("MAIN SURVIVAL (LEVEL $best)" to { startGame(false, best) })
        if (best > 1) items.add("ULANG DARI LEVEL 1" to { startGame(false, 1) })
        items.add("MODE KREATIF" to { startGame(true, 1) })
        items.add("PENGATURAN" to { showSettings() })
        items.add("KELUAR" to { finish() })
        panel("BLOKGUN", "Bangun \u2022 Tembak \u2022 Bertahan", items)
    }

    private fun showSettings() {
        val snd = prefs.getBoolean("sound", true)
        val sens = prefs.getInt("sens", 1).coerceIn(0, 2)
        val graphics = prefs.getInt("graphics", 1).coerceIn(0, 2)
        val autoJump = prefs.getBoolean("auto_jump", true)
        val graphicsNames = arrayOf("SMOOTH (TANPA BAYANGAN)", "SEDANG (BAYANGAN RINGAN)", "MAKSIMUM (BAYANGAN LEBIH KUAT)")
        game.graphicsMode = graphics
        game.autoJump = autoJump
        val items = listOf<Pair<String, () -> Unit>>(
            "SUARA: ${if (snd) "NYALA" else "MATI"}" to {
                prefs.edit().putBoolean("sound", !snd).apply()
                Sfx.enabled = !snd
                showSettings()
            },
            "SENSITIVITAS LIHAT: ${sensNames[sens]}" to {
                val n = (sens + 1) % 3
                prefs.edit().putInt("sens", n).apply()
                game.sens = sensVals[n]
                showSettings()
            },
            "GRAFIS: ${graphicsNames[graphics]}" to {
                val n = (graphics + 1) % 3
                prefs.edit().putInt("graphics", n).apply()
                game.graphicsMode = n
                showSettings()
            },
            "LOMPAT OTOMATIS: ${if (autoJump) "NYALA" else "MATI"}" to {
                prefs.edit().putBoolean("auto_jump", !autoJump).apply()
                game.autoJump = !autoJump
                showSettings()
            },
            "KEMBALI" to { showMain() }
        )
        panel("PENGATURAN", null, items)
    }

    private fun startGame(creative: Boolean, level: Int) {
        clearOverlay()
        inGame = true
        hud.reset()
        hud.visibility = View.VISIBLE
        glView.queueEvent { game.start(creative, level) }
    }

    private fun showPause() {
        if (!inGame || game.dead) return
        game.paused = true
        hud.reset()
        panel(
            "JEDA", null,
            listOf<Pair<String, () -> Unit>>(
                "LANJUT" to { resumeGame() },
                "MENU UTAMA" to { showMain() }
            )
        )
    }

    private fun resumeGame() {
        clearOverlay()
        hud.reset()
        game.paused = false
    }

    // ---------- HudListener ----------
    override fun onPauseClick() {
        showPause()
    }

    override fun onDead() {
        if (!inGame) return
        panel(
            "GAME OVER", "Level ${game.level}  \u2022  Musuh dikalahkan: ${game.kills}",
            listOf<Pair<String, () -> Unit>>(
                "COBA LAGI" to { startGame(false, game.level) },
                "MENU UTAMA" to { showMain() }
            )
        )
    }
}
