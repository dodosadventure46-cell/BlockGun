package com.blokgun.game
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random
class Weapon(
    val name: String, val dmg: Float, val rate: Float, val mag: Int, val maxRes: Int,
    val pellets: Int, val spread: Float, val auto: Boolean, val reward: Int,
    val scope: Boolean
)
class Input {
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f
    @Volatile var jump = false
    @Volatile var fire = false
    @Volatile var fireEdge = false
    @Volatile var brk = false
    @Volatile var reload = false
    private var lx = 0f
    private var ly = 0f
    @Synchronized fun addLook(dx: Float, dy: Float) { lx += dx; ly += dy }
    @Synchronized fun takeLook(out: FloatArray) { out[0] = lx; out[1] = ly; lx = 0f; ly = 0f }
    fun clear() {
        moveX = 0f; moveY = 0f; jump = false; fire = false; fireEdge = false; brk = false; reload = false
        synchronized(this) { lx = 0f; ly = 0f }
    }
}
open class Body(var x: Float, var y: Float, var z: Float) {
    var vx = 0f
    var vy = 0f
    var vz = 0f
    var onGround = false
    var blocked = false
    val bw = 0.6f
    val bh = 1.8f
    fun move(w: World, dt: Float) {
        vy -= 25f * dt
        if (vy < -40f) vy = -40f
        blocked = false
        var nx = x + vx * dt
        if (w.hits(nx, y, z, bw, bh)) { nx = x; blocked = true }
        x = nx
        var nz = z + vz * dt
        if (w.hits(x, y, nz, bw, bh)) { nz = z; blocked = true }
        z = nz
        var ny = y + vy * dt
        onGround = false
        if (w.hits(x, ny, z, bw, bh)) {
            if (vy < 0f) {
                ny = floor(ny) + 1.001f
                onGround = true
            } else {
                ny = floor(ny + bh) - bh - 0.001f
            }
            vy = 0f
        }
        y = ny
    }
}
class Enemy(x: Float, y: Float, z: Float, val type: Int, var hp: Float) : Body(x, y, z) {
    var yaw = 0f
    var hit = 0f
    var atk = 1f
    val strafe = if (Random.nextBoolean()) 1f else -1f
    /** Fase siklus jalan untuk animasi kaki/tangan. */
    var walk = 0f
    /** Timer suara periodik (deru zombie / teriak penembak). */
    var sndT = 1.5f + Random.nextFloat() * 3f
}
/** Satu bagian tubuh untuk ragdoll mayat. */
class Part(
    var x: Float, var y: Float, var z: Float,
    var vx: Float, var vy: Float, var vz: Float,
    val sx: Float, val sy: Float, val sz: Float,
    val r: Float, val g: Float, val b: Float
) {
    var settled = false
}
/** Mayat musuh: berragdoll lalu tenggelam ke tanah setelah 2 detik. */
class Corpse(x: Float, y: Float, z: Float, yaw: Float, type: Int) {
    val parts = ArrayList<Part>()
    var t = 0f
    init {
        val s = sin(yaw)
        val c = cos(yaw)
        fun rot(lx: Float, lz: Float): Pair<Float, Float> = Pair(lx * c + lz * s, -lx * s + lz * c)
        fun spawn(px: Float, py: Float, pz: Float, sx: Float, sy: Float, sz: Float, r: Float, g: Float, b: Float) {
            val (wx, wz) = rot(px, pz)
            val a = Random.nextFloat() * 6.2832f
            val sp = 0.6f + Random.nextFloat() * 1.6f
            parts.add(Part(
                x + wx, y + py, z + wz,
                cos(a) * sp, 2.5f + Random.nextFloat() * 3f, sin(a) * sp,
                sx, sy, sz, r, g, b
            ))
        }
        if (type == 0) {
            // zombie: hijau keabu-abuan
            spawn(0f, 1.1f, 0f, 0.55f, 0.7f, 0.3f, 0.20f, 0.50f, 0.55f) // badan
            spawn(0f, 1.62f, 0f, 0.42f, 0.42f, 0.42f, 0.40f, 0.70f, 0.35f) // kepala
            spawn(-0.38f, 1.25f, -0.35f, 0.18f, 0.18f, 0.6f, 0.40f, 0.70f, 0.35f) // lengan
            spawn(0.38f, 1.25f, -0.35f, 0.18f, 0.18f, 0.6f, 0.40f, 0.70f, 0.35f)
            spawn(-0.16f, 0.4f, 0f, 0.18f, 0.8f, 0.18f, 0.15f, 0.25f, 0.50f) // kaki
            spawn(0.16f, 0.4f, 0f, 0.18f, 0.8f, 0.18f, 0.15f, 0.25f, 0.50f)
        } else {
            // penembak: baju gelap + kulit
            spawn(0f, 1.1f, 0f, 0.55f, 0.7f, 0.3f, 0.55f, 0.18f, 0.18f)
            spawn(0f, 1.62f, 0f, 0.42f, 0.42f, 0.42f, 0.90f, 0.72f, 0.55f)
            spawn(-0.38f, 1.25f, -0.35f, 0.18f, 0.18f, 0.6f, 0.90f, 0.72f, 0.55f)
            spawn(0.38f, 1.25f, -0.35f, 0.18f, 0.18f, 0.6f, 0.90f, 0.72f, 0.55f)
            spawn(-0.16f, 0.4f, 0f, 0.18f, 0.8f, 0.18f, 0.20f, 0.20f, 0.25f)
            spawn(0.16f, 0.4f, 0f, 0.18f, 0.8f, 0.18f, 0.20f, 0.20f, 0.25f)
        }
    }
}
class Particle(var x: Float, var y: Float, var z: Float, var vx: Float, var vy: Float, var vz: Float, var life: Float, val maxLife: Float, val r: Float, val g: Float, val b: Float, val size: Float)
class Tracer(val x1: Float, val y1: Float, val z1: Float, val x2: Float, val y2: Float, val z2: Float, var life: Float)
class Game {
    companion object {
        val BLOCKS = intArrayOf(3, 2, 7, 4, 6) // batu, tanah, papan, kayu, pasir
        val BLOCK_COLOR = intArrayOf(
            Color.rgb(128, 128, 128), Color.rgb(125, 85, 50), Color.rgb(186, 146, 85),
            Color.rgb(105, 79, 46), Color.rgb(225, 210, 150)
        )
        val WEAPONS = arrayOf(
            Weapon("PISTOL", 34f, 0.35f, 12, 96, 1, 0.01f, false, 6, false),
            Weapon("RIFLE", 20f, 0.10f, 30, 180, 1, 0.03f, true, 10, true),
            Weapon("SHOTGUN", 14f, 0.90f, 6, 36, 8, 0.12f, false, 2, false)
        )
    }
    val world = World()
    val input = Input()
    val p = Body(32.5f, 20f, 32.5f)
    val enemies = ArrayList<Enemy>()
    val corpses = ArrayList<Corpse>()
    val particles = ArrayList<Particle>()
    val tracers = ArrayList<Tracer>()
    private var walkDist = 0f
    var yaw = 0f
    var pitch = -0.12f
    var sens = 0.007f
    @Volatile var paused = true
    @Volatile var spin = true
    @Volatile var dead = false
    @Volatile var hp = 100f
    @Volatile var level = 1
    @Volatile var kills = 0
    @Volatile var left = 0
    @Volatile var selected = 0
    @Volatile var creative = false
    @Volatile var autoJump = true
    /** 0=smooth, 1=medium, 2=maximum; consumed by renderer. */
    @Volatile var graphicsMode = 1
    /** Aim-down-sights / scope (dijeda dari HUD). */
    @Volatile var scope = false
    /** Skin senjata: false=default, true=Scorpion Merah. */
    @Volatile var skin = false
    /** Fase langkah pemain untuk bob senjata. */
    @Volatile var bob = 0f
    private var mineProgress = 0f
    private var mineX = Int.MIN_VALUE
    private var mineY = Int.MIN_VALUE
    private var mineZ = Int.MIN_VALUE
    @Volatile var reloadT = 0f
    @Volatile var hurtFlash = 0f
    @Volatile var hitMarker = 0f
    @Volatile var banner = ""
    @Volatile var bannerT = 0f
    @Volatile var flashT = 0f
    @Volatile var kick = 0f
    val ammo = IntArray(3)
    val reserve = IntArray(3)
    var onLevel: ((Int) -> Unit)? = null
    private var toSpawn = 0
    private var spawnT = 0f
    private var levelDone = false
    private var levelT = 0f
    private var cd = 0f
    private var breakCd = 0f
    private var lastSel = 0
    private val look = FloatArray(2)
    private val hit = Hit()
    private val hit2 = Hit()
    private val rng = FloatArray(2)
    init {
        world.generate(2024)
        placeAtSpawn()
    }
    private fun placeAtSpawn() {
        val sx = World.SX / 2
        val sz = World.SZ / 2
        p.x = sx + 0.5f
        p.z = sz + 0.5f
        p.y = world.topY(sx, sz) + 1.01f
        p.vx = 0f; p.vy = 0f; p.vz = 0f
    }
    /** Dipanggil dari thread GL. */
    fun start(creativeMode: Boolean, lvl: Int) {
        creative = creativeMode
        world.generate(Random.nextInt())
        placeAtSpawn()
        yaw = 0f
        pitch = -0.12f
        hp = 100f
        dead = false
        kills = 0
        selected = 0
        lastSel = 0
        scope = false
        bob = 0f
        for (i in 0..2) {
            ammo[i] = WEAPONS[i].mag
            reserve[i] = WEAPONS[i].maxRes / 2
        }
        enemies.clear()
        corpses.clear()
        reloadT = 0f
        cd = 0f
        breakCd = 0f
        hurtFlash = 0f
        input.clear()
        levelDone = false
        toSpawn = 0
        if (creative) {
            level = 1
            left = 0
            setBanner("MODE KREATIF", 3f)
        } else {
            startLevel(lvl)
        }
        spin = false
        paused = false
    }
    private fun startLevel(l: Int) {
        level = l
        toSpawn = 4 + 3 * l
        spawnT = 2f
        levelDone = false
        setBanner("LEVEL $l", 2.5f)
        onLevel?.invoke(l)
    }
    private fun setBanner(t: String, sec: Float) {
        banner = t
        bannerT = sec
    }
    fun tick(dt: Float) {
        if (hurtFlash > 0f) hurtFlash -= dt
        if (hitMarker > 0f) hitMarker -= dt
        if (paused) {
            if (spin) yaw += dt * 0.12f
            return
        }
        update(dt)
        // update partikel & tracer
        var i = 0
        while (i < particles.size) {
            val p = particles[i]; p.life -= dt
            p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.vy -= 14f * dt
            if (p.life <= 0f) particles.removeAt(i) else i++
        }
        if (particles.size > 200) particles.subList(0, particles.size - 200).clear()
        i = 0
        while (i < tracers.size) { val t = tracers[i]; t.life -= dt; if (t.life <= 0f) tracers.removeAt(i) else i++ }
        // suara langkah kaki berdasarkan material
        val spd = hypot(vx, vz)
        if (onGround && spd > 0.5f) {
            walkDist += spd * dt
            if (walkDist > 1.6f) {
                walkDist = 0f
                val b = world.get(px.toInt(), (y - 0.2f).toInt(), pz.toInt())
                Sfx.play(if (b == 1 || b == 2 || b == 6) 16 else 17)
            }
        }
    }
    private fun update(dt: Float) {
        input.takeLook(look)
        val sm = if (scope) 0.42f else 1f
        yaw += look[0] * sens * sm
        pitch = (pitch - look[1] * sens * sm).coerceIn(-1.5f, 1.5f)
        // gerak
        val mx = input.moveX
        val my = input.moveY
        val sp = if (scope) 3.2f else 5.2f
        val s = sin(yaw)
        val c = cos(yaw)
        p.vx = (s * my + c * mx) * sp
        p.vz = (-c * my + s * mx) * sp
        if (input.jump && p.onGround) p.vy = 8.6f
        p.move(world, dt)
        // Auto-step: if horizontal movement hits a one-block ledge, jump only while grounded.
        if (autoJump && p.blocked && p.onGround && (abs(mx) + abs(my) > 0.15f)) {
            p.vy = 7.6f
        }
        // bob senjata saat berjalan
        val spd = hypot(p.vx, p.vz)
        if (spd > 0.5f && p.onGround) bob += dt * spd * 1.8f
        // timer
        if (selected != lastSel) { reloadT = 0f; lastSel = selected; if (selected >= 3) scope = false }
        cd -= dt
        breakCd -= dt
        if (kick > 0f) kick = max(0f, kick - dt * 6f)
        if (flashT > 0f) flashT -= dt
        if (bannerT > 0f) bannerT -= dt
        // tembak / pasang blok
        val wantFire = input.fire
        val edge = input.fireEdge
        input.fireEdge = false
        val item = selected
        if (item < 3) {
            val wp = WEAPONS[item]
            if (reloadT > 0f) {
                reloadT -= dt
                if (reloadT <= 0f) finishReload(item)
            }
            if (input.reload) { input.reload = false; startReload(item) }
            val want = if (wp.auto) wantFire else edge
            if (want && cd <= 0f && reloadT <= 0f) {
                if (ammo[item] > 0 || creative) {
                    if (!creative) ammo[item]--
                    shoot(item)
                    cd = wp.rate
                } else if (reserve[item] > 0) {
                    startReload(item)
                } else {
                    Sfx.play(Sfx.CLICK)
                    cd = 0.3f
                }
            }
        } else {
            input.reload = false
            // Survival tidak menyediakan blok untuk dipasang.
            if (creative && edge) placeBlock(BLOCKS[item - 3])
        }
        // Mining bertahap seperti sandbox voxel: blok keras butuh lebih lama.
        if (input.brk) {
            val cp = cos(pitch)
            world.raycast(p.x, p.y + 1.62f, p.z, sin(yaw) * cp, sin(pitch), -cos(yaw) * cp, 5.5f, hit)
            if (hit.found && hit.by > 0) {
                if (mineX != hit.bx || mineY != hit.by || mineZ != hit.bz) {
                    mineX = hit.bx; mineY = hit.by; mineZ = hit.bz; mineProgress = 0f
                }
                val blockId = world.get(hit.bx, hit.by, hit.bz)
                val hardness = when (blockId) { 3, 7 -> 1.65f; 4 -> 1.25f; 6 -> 0.75f; else -> 0.55f }
                mineProgress += dt
                if (mineProgress >= hardness) {
                    world.set(hit.bx, hit.by, hit.bz, 0)
                    Sfx.play(Sfx.BREAK)
                    mineProgress = 0f; mineX = Int.MIN_VALUE
                    breakCd = 0.12f
                }
            } else { mineProgress = 0f; mineX = Int.MIN_VALUE }
        } else { mineProgress = 0f; mineX = Int.MIN_VALUE }
        // gelombang musuh
        if (!creative) {
            if (toSpawn > 0) {
                spawnT -= dt
                if (spawnT <= 0f && enemies.size < min(4 + level / 2, 9)) {
                    spawnEnemy()
                    spawnT = max(0.8f, 2.6f - 0.12f * level)
                }
            }
            if (toSpawn == 0 && enemies.isEmpty() && !levelDone) {
                levelDone = true
                levelT = 3.5f
                setBanner("LEVEL $level SELESAI!", 3f)
                hp = min(100f, hp + 35f)
                for (i in 0..2) reserve[i] = min(WEAPONS[i].maxRes, reserve[i] + WEAPONS[i].mag)
                Sfx.play(Sfx.LEVEL)
            }
            if (levelDone) {
                levelT -= dt
                if (levelT <= 0f) startLevel(level + 1)
            }
        }
        for (i in enemies.indices.reversed()) {
            if (i < enemies.size) updateEnemy(enemies[i], dt)
        }
        updateCorpses(dt)
        left = toSpawn + enemies.size
    }
    private fun updateCorpses(dt: Float) {
        for (i in corpses.indices.reversed()) {
            val c = corpses[i]
            c.t += dt
            val sinking = c.t > 2f
            for (pt in c.parts) {
                if (!pt.settled) {
                    pt.vy -= 25f * dt
                    pt.x += pt.vx * dt
                    pt.y += pt.vy * dt
                    pt.z += pt.vz * dt
                    val gy = world.topY(pt.x.toInt(), pt.z.toInt()) + 1f
                    if (gy > 0f && pt.y - pt.sy / 2f < gy) {
                        pt.y = gy + pt.sy / 2f
                        pt.vy = 0f
                        pt.vx = 0f
                        pt.vz = 0f
                        pt.settled = true
                    }
                }
                if (sinking) pt.y -= dt * 3.2f // tenggelam ke tanah
            }
            if (c.t > 2.7f) corpses.removeAt(i)
        }
    }
    private fun startReload(item: Int) {
        val wp = WEAPONS[item]
        if (reloadT > 0f || ammo[item] >= wp.mag) return
        if (!creative && reserve[item] <= 0) return
        reloadT = 1.1f
        Sfx.play(Sfx.RELOAD)
    }
    private fun finishReload(item: Int) {
        val wp = WEAPONS[item]
        val need = wp.mag - ammo[item]
        val take = if (creative) need else min(need, reserve[item])
        ammo[item] += take
        if (!creative) reserve[item] -= take
    }
    private fun overlapsPlayer(bx: Int, by: Int, bz: Int): Boolean {
        val hw = 0.3f
        return p.x + hw > bx && p.x - hw < bx + 1 &&
            p.y + 1.8f > by && p.y < by + 1 &&
            p.z + hw > bz && p.z - hw < bz + 1
    }
    private fun placeBlock(id: Int) {
        val cp = cos(pitch)
        world.raycast(p.x, p.y + 1.62f, p.z, sin(yaw) * cp, sin(pitch), -cos(yaw) * cp, 5.5f, hit)
        if (hit.found && world.get(hit.px, hit.py, hit.pz) == 0 && !overlapsPlayer(hit.px, hit.py, hit.pz)) {
            if (world.set(hit.px, hit.py, hit.pz, id)) Sfx.play(Sfx.PLACE)
        }
    }
    private fun slab(o: Float, d: Float, mn: Float, mx: Float): Boolean {
        if (abs(d) < 1e-6f) return o >= mn && o <= mx
        var t1 = (mn - o) / d
        var t2 = (mx - o) / d
        if (t1 > t2) { val t = t1; t1 = t2; t2 = t }
        if (t1 > rng[0]) rng[0] = t1
        if (t2 < rng[1]) rng[1] = t2
        return rng[0] <= rng[1]
    }
    private fun rayBox(
        ox: Float, oy: Float, oz: Float, dx: Float, dy: Float, dz: Float,
        x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float
    ): Float {
        rng[0] = 0f
        rng[1] = 1e9f
        if (!slab(ox, dx, x0, x1)) return -1f
        if (!slab(oy, dy, y0, y1)) return -1f
        if (!slab(oz, dz, z0, z1)) return -1f
        return rng[0]
    }
    private fun shoot(item: Int) {
        val wp = WEAPONS[item]
        Sfx.play(item)
        kick = 1f
        flashT = 0.07f
        val ex = p.x
        val ey = p.y + 1.62f
        val ez = p.z
        var hitPlayed = false
        for (k in 0 until wp.pellets) {
            val spreadMul = if (scope) 0.35f else 1f
            val yw = yaw + (Random.nextFloat() - 0.5f) * wp.spread * spreadMul
            val pt = pitch + (Random.nextFloat() - 0.5f) * wp.spread * spreadMul
            val cp = cos(pt)
            val dx = sin(yw) * cp
            val dy = sin(pt)
            val dz = -cos(yw) * cp
            world.raycast(ex, ey, ez, dx, dy, dz, 80f, hit)
            var best = if (hit.found) hit.dist else 80f
            var target: Enemy? = null
            var head = false
            for (e in enemies) {
                val t = rayBox(
                    ex, ey, ez, dx, dy, dz,
                    e.x - 0.3f, e.y, e.z - 0.3f, e.x + 0.3f, e.y + 1.8f, e.z + 0.3f
                )
                if (t >= 0f && t <= best) {
                    best = t
                    target = e
                    head = ey + dy * t > e.y + 1.4f
                }
            }
            val tg = target
            if (tg != null) {
                tg.hp -= wp.dmg * (if (head) 2f else 1f)
                tg.hit = 0.12f
                hitMarker = 0.15f
                if (!hitPlayed) { hitPlayed = true; Sfx.play(Sfx.HIT) }
                if (tg.hp <= 0f) killEnemy(tg)
            }
        }
        // efek: tracer, asap laras, selongsong, percikan
        val cpt = cos(pitch); val bdx = sin(yaw) * cpt; val bdy = sin(pitch); val bdz = -cos(yaw) * cpt
        val mx = ex + bdx * 0.6f; val my = ey + bdy * 0.6f - 0.1f; val mz = ez + bdz * 0.6f
        val td = if (hit.found) hit.dist else 80f
        tracers.add(Tracer(mx, my, mz, ex + bdx * td, ey + bdy * td, ez + bdz * td, 0.08f))
        for (q in 0..2) particles.add(Particle(mx, my, mz, bdx * 1.5f + (Random.nextFloat() - 0.5f), bdy * 1.5f + 0.5f, bdz * 1.5f + (Random.nextFloat() - 0.5f), 0.4f, 0.4f, 0.5f, 0.5f, 0.55f, 0.08f))
        particles.add(Particle(ex, ey - 0.1f, ez, cos(yaw) * 1.5f, 2.5f, -sin(yaw) * 1.5f, 0.8f, 0.8f, 0.9f, 0.7f, 0.3f, 0.05f))
        if (hit.found) {
            val ix = ex + bdx * td; val iy = ey + bdy * td; val iz = ez + bdz * td
            for (q in 0..4) particles.add(Particle(ix, iy, iz, (Random.nextFloat() - 0.5f) * 4f, Random.nextFloat() * 3f, (Random.nextFloat() - 0.5f) * 4f, 0.3f, 0.3f, 1f, 0.8f, 0.3f, 0.06f))
        }
        pitch += if (item == 2) 0.04f else 0.012f
    }
    private fun killEnemy(e: Enemy) {
        corpses.add(Corpse(e.x, e.y, e.z, e.yaw, e.type))
        if (e.type == 0) Sfx.play(Sfx.ZDEATH) else Sfx.playRandomVoice()
        enemies.remove(e)
        kills++
        for (i in 0..2) reserve[i] = min(WEAPONS[i].maxRes, reserve[i] + WEAPONS[i].reward)
        Sfx.play(Sfx.KILL)
    }
    private fun spawnEnemy() {
        for (t in 0 until 12) {
            val a = Random.nextFloat() * 6.2832f
            val r = 14f + Random.nextFloat() * 12f
            val x = (p.x + cos(a) * r).coerceIn(2f, World.SX - 3f)
            val z = (p.z + sin(a) * r).coerceIn(2f, World.SZ - 3f)
            val ty = world.topY(x.toInt(), z.toInt())
            if (ty < 0) continue
            val dx = x - p.x
            val dz = z - p.z
            if (dx * dx + dz * dz < 100f) continue
            val gunner = level >= 2 && Random.nextFloat() < 0.3f + 0.03f * level
            val hp = (if (gunner) 45f else 60f) + 8f * level
            enemies.add(Enemy(x, ty + 1.01f, z, if (gunner) 1 else 0, hp))
            toSpawn--
            return
        }
    }
    fun hurt(d: Float) {
        if (creative || dead) return
        hp -= d
        hurtFlash = 0.35f
        Sfx.play(Sfx.HURT)
        if (hp <= 0f) {
            hp = 0f
            dead = true
            paused = true
        }
    }
    private fun updateEnemy(e: Enemy, dt: Float) {
        val dx = p.x - e.x
        val dz = p.z - e.z
        val dist = sqrt(dx * dx + dz * dz)
        val nx = if (dist > 0.001f) dx / dist else 0f
        val nz = if (dist > 0.001f) dz / dist else 0f
        e.yaw = atan2(dx, -dz)
        if (e.hit > 0f) e.hit -= dt
        e.atk -= dt
        var mvx = 0f
        var mvz = 0f
        if (e.type == 0) {
            val sp = min(2.4f + 0.18f * level, 4.2f)
            if (dist > 1.1f) { mvx = nx * sp; mvz = nz * sp }
            if (dist < 1.5f && abs(p.y - e.y) < 1.6f && e.atk <= 0f) {
                e.atk = 0.9f
                hurt(6f + level)
            }
        } else {
            val sp = 2.6f
            if (dist > 14f) { mvx = nx * sp; mvz = nz * sp }
            else if (dist < 8f) { mvx = -nx * sp; mvz = -nz * sp }
            else { mvx = -nz * e.strafe * sp * 0.7f; mvz = nx * e.strafe * sp * 0.7f }
            if (e.atk <= 0f && dist < 28f) {
                e.atk = 1.5f - min(level * 0.05f, 0.6f)
                Sfx.play(Sfx.PISTOL)
                if (Random.nextFloat() < 0.45f) Sfx.playRandomVoice() // "hoho"/"hoiii"/"hayaaa"
                val ex = e.x
                val ey = e.y + 1.5f
                val ez = e.z
                val tx = p.x - ex
                val ty = p.y + 1.5f - ey
                val tz = p.z - ez
                val len = sqrt(tx * tx + ty * ty + tz * tz)
                if (len > 0.1f) {
                    world.raycast(ex, ey, ez, tx / len, ty / len, tz / len, len, hit2)
                    if (!hit2.found && Random.nextFloat() < 0.4f) hurt(5f + level)
                }
            }
        }
        // animasi jalan + suara periodik
        val spd = hypot(mvx, mvz)
        if (spd > 0.3f && e.onGround) e.walk += dt * spd * 3.2f
        e.sndT -= dt
        if (e.sndT <= 0f) {
            e.sndT = 2.5f + Random.nextFloat() * 3.5f
            if (dist < 26f) {
                if (e.type == 0) Sfx.play(Sfx.ZGROAN)
                else if (Random.nextFloat() < 0.5f) Sfx.playRandomVoice()
            }
        }
        e.vx = mvx
        e.vz = mvz
        e.move(world, dt)
        // musuh bisa melompat naik blok setinggi 1 bila terhalang (seperti auto-jump player)
        if (e.blocked && e.onGround && hypot(mvx, mvz) > 0.5f) e.vy = 8.2f
    }
}
