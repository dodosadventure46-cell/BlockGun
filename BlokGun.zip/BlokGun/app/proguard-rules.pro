# Game ini tidak memakai refleksi, jadi tidak perlu aturan keep tambahan.
# MainActivity otomatis dijaga lewat AndroidManifest.
-dontwarn **
