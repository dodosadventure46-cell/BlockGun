# Game ini tidak memakai refleksi, jadi tidak perlu aturan keep tambahan.
-dontobfuscate
-keepattributes SourceFile,LineNumberTable
-dontwarn **
