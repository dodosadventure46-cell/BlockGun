# BlokGun

Game Android 3D mirip Minecraft + senjata api. Dibuat dengan Kotlin dan OpenGL ES, tanpa library tambahan, jadi ukuran APK sangat kecil.

## Cara build di GitHub
1. Buat repo baru di GitHub, lalu upload SEMUA isi folder ini (termasuk folder `.github` dan `app/release.jks`).
2. Buka tab **Actions**. Build berjalan otomatis setelah upload (atau klik **Build APK** lalu **Run workflow**).
3. Setelah hijau, buka run tersebut, lalu download artifact **BlokGun-APK** (isinya `BlokGun.apk`).
4. Ekstrak zip, lalu install `BlokGun.apk` di HP.

Catatan: folder `.github` bersifat tersembunyi. Pastikan ikut ter-upload.

## Kontrol
- Kiri layar: geser untuk berjalan (joystick muncul di titik sentuh)
- Kanan layar: geser untuk melihat sekitar
- TEMBAK: tembak senjata, atau pasang blok kalau yang dipegang blok (tahan untuk auto di RIFLE)
- PECAH: hancurkan blok yang dibidik
- ZUM: scope / bidik teropong (rifle ada overlay teropong; pistol/shotgun = ADS)
- LOMPAT, ISI (reload), II (jeda)
- Hotbar bawah: slot 1-3 senjata (pistol, rifle, shotgun), slot 4-8 blok (batu, tanah, papan, kayu, pasir)

## Mode
- Survival: gelombang musuh per level (zombie + penembak mulai level 2)
- Kreatif: tanpa musuh, amunisi tak terbatas

## Ukuran kecil
Release build memakai R8 (buang kode tak terpakai), shrink resource, tanpa dependensi, tanpa file gambar/audio (tekstur dan suara dibuat lewat kode), dan artifact di-upload dengan kompresi level 9.


## Pembaruan gameplay
- Dunia diperluas menjadi 128 x 128 blok, chunk dibangun bertahap agar tidak nge-lag.
- Mining berlangsung bertahap; blok yang lebih keras membutuhkan waktu lebih lama.
- Mode survival tidak menyediakan pemasangan blok.
- Pengaturan menyediakan pilihan grafis Smooth/Sedang/Maksimum dan auto-jump.
- Bayangan musuh yang diproyeksikan ke tanah: Smooth tanpa bayangan, Sedang bayangan tipis, Maksimum bayangan ganda lebih tegas + jarak pandang lebih jauh.
- Model senjata lebih detail (laras, magazin, popor, teropong) dipegang dua tangan di pojok kanan-bawah agar tidak menutupi layar, plus animasi reload (senjata turun-naik) dan bob saat berjalan.
- Tombol ZUM (scope/ADS): rifle memakai teropong (overlay lingkaran + FOV sempit 35°), pistol/shotgun ADS memperkecil spread dan FOV 52°. Sensitivitas & kecepatan berjalan berkurang saat scope.
- Musuh punya animasi jalan (kaki & tangan berayun). Saat mati, tubuh ber-ragdoll (6 bagian tubuh terpencar lalu jatuh), setelah 2 detik tenggelam ke tanah dan menghilang.
- Efek suara musuh: deru zombie saat berjalan, geraman kematian, dan teriak variasi penembak ("hoho", "hoiii", "hayaaa") saat menembak.
