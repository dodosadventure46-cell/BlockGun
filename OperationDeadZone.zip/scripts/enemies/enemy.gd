extends CharacterBody3D
## Musuh: patroli, deteksi, kejar, serang, berlindung (cover), animasi prosedural, mati (jatuh).

const Fx := preload("res://scripts/gameplay/fx.gd")
const TexLib := preload("res://scripts/gameplay/texlib.gd")

signal killed(enemy)

enum State { PATROL, CHASE, ATTACK, COVER, DEAD }

var state: int = State.PATROL
var kind: int = 0
var phase: int = 0
var health: float = 70.0
var max_health: float = 70.0
var damage: float = 7.0
var sight_range: float = 38.0
var attack_range: float = 20.0
var target = null
var patrol_points: Array = []
var patrol_idx: int = 0
var wait_t: float = 0.0
var last_known: Vector3 = Vector3.ZERO
var has_last_known: bool = false
var los: bool = false
var los_timer: float = 0.0
var lost_t: float = 0.0
var fire_cd: float = 1.0
var burst_left: int = 0
var burst_cd: float = 0.0
var strafe_dir: float = 1.0
var strafe_t: float = 0.0
var cover_pos: Vector3 = Vector3.ZERO
var cover_wait: float = 0.0
var cover_cd: float = 0.0
var in_cover: bool = false
var anim_phase: float = 0.0
var aim_blend: float = 0.0
var recoil_anim: float = 0.0
var crouch_blend: float = 0.0
var steer_t: float = 0.0
var steer_dir: Vector3 = Vector3.ZERO
var avoid_bias: float = 1.0

var model: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var muzzle: Marker3D


func setup(p_phase: int, p_kind: int, points: Array) -> void:
    phase = p_phase
    kind = p_kind
    patrol_points = points


func _ready() -> void:
    add_to_group("enemies")
    collision_layer = 4
    collision_mask = 1 | 2 | 4
    if kind == 1:
        max_health = 140.0
        damage = 11.0
        attack_range = 24.0
    health = max_health
    target = get_tree().get_first_node_in_group("player")
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.38
    cap.height = 1.8
    cs.shape = cap
    cs.position = Vector3(0, 0.9, 0)
    add_child(cs)
    _build_model()
    fire_cd = randf_range(0.5, 1.2)
    avoid_bias = 1.0 if randf() < 0.5 else -1.0


func _part(parent: Node3D, size: Vector3, pos: Vector3, col: Color) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = TexLib.flat(col, 0.85)
    mi.position = pos
    parent.add_child(mi)
    return mi


func _pivot(parent: Node3D, pos: Vector3) -> Node3D:
    var n := Node3D.new()
    n.position = pos
    parent.add_child(n)
    return n


func _build_model() -> void:
    var cloth := Color(0.27, 0.3, 0.21)
    var vest := Color(0.14, 0.15, 0.17)
    if kind == 1:
        cloth = Color(0.2, 0.2, 0.24)
        vest = Color(0.3, 0.1, 0.08)
    var skin := Color(0.72, 0.56, 0.44)
    var dark := Color(0.08, 0.08, 0.09)
    model = Node3D.new()
    add_child(model)
    var s: float = 1.0 if kind == 0 else 1.12
    model.scale = Vector3(s, s, s)
    _part(model, Vector3(0.46, 0.2, 0.24), Vector3(0, 0.88, 0), cloth)
    _part(model, Vector3(0.5, 0.62, 0.26), Vector3(0, 1.2, 0), cloth)
    _part(model, Vector3(0.54, 0.4, 0.3), Vector3(0, 1.25, 0), vest)
    _part(model, Vector3(0.2, 0.22, 0.2), Vector3(0, 1.66, 0), skin)
    _part(model, Vector3(0.27, 0.14, 0.29), Vector3(0, 1.79, 0), dark)
    leg_l = _pivot(model, Vector3(-0.13, 0.82, 0))
    _part(leg_l, Vector3(0.18, 0.8, 0.2), Vector3(0, -0.4, 0), cloth)
    leg_r = _pivot(model, Vector3(0.13, 0.82, 0))
    _part(leg_r, Vector3(0.18, 0.8, 0.2), Vector3(0, -0.4, 0), cloth)
    arm_l = _pivot(model, Vector3(-0.34, 1.48, 0))
    _part(arm_l, Vector3(0.13, 0.6, 0.15), Vector3(0, -0.3, 0), cloth)
    arm_r = _pivot(model, Vector3(0.34, 1.48, 0))
    _part(arm_r, Vector3(0.13, 0.6, 0.15), Vector3(0, -0.3, 0), cloth)
    _part(arm_r, Vector3(0.07, 0.6, 0.09), Vector3(0, -0.72, 0), dark)
    muzzle = Marker3D.new()
    muzzle.position = Vector3(0, -1.0, 0)
    arm_r.add_child(muzzle)


func alert_to(pos: Vector3) -> void:
    if state == State.DEAD:
        return
    state = State.CHASE
    last_known = pos
    has_last_known = true


func ally_alert(pos: Vector3, radius: float, where: Vector3) -> void:
    if state == State.PATROL and global_position.distance_to(pos) < radius:
        alert_to(where)


func hear_noise(pos: Vector3, radius: float) -> void:
    if state == State.PATROL and global_position.distance_to(pos) < radius:
        alert_to(pos)


func is_head_hit(pos: Vector3) -> bool:
    return pos.y > global_position.y + 1.55 - crouch_blend * 0.35


func take_damage(amount: float, headshot: bool = false, from: Vector3 = Vector3.ZERO) -> void:
    if state == State.DEAD:
        return
    health -= amount
    SFX.play_at("impact", global_position + Vector3(0, 1.2, 0), -3.0, randf_range(0.7, 0.9))
    var by: float = 1.7 if headshot else 1.3
    Fx.blood(get_parent(), global_position + Vector3(0, by, 0))
    if target != null:
        get_tree().call_group("enemies", "ally_alert", global_position, 22.0, target.global_position)
        if state == State.PATROL:
            alert_to(target.global_position)
    if health <= 0.0:
        _die()
        return
    if state != State.COVER and cover_cd <= 0.0 and health < max_health * 0.6 and randf() < 0.3:
        if _find_cover():
            state = State.COVER
            in_cover = false
            cover_wait = randf_range(2.5, 4.0)


func _die() -> void:
    state = State.DEAD
    collision_layer = 0
    collision_mask = 1
    remove_from_group("enemies")
    killed.emit(self)
    SFX.play_at("death", global_position, 0.0)
    var tw := create_tween()
    tw.set_parallel(true)
    tw.tween_property(model, "rotation:x", PI * 0.5, 0.55).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tw.tween_property(model, "position:y", 0.15, 0.55)
    tw.chain().tween_interval(7.0)
    tw.chain().tween_callback(queue_free)


func _physics_process(delta: float) -> void:
    if state == State.DEAD:
        return
    if target == null or not is_instance_valid(target):
        return
    cover_cd = maxf(0.0, cover_cd - delta)
    if not is_on_floor():
        velocity.y -= 22.0 * delta
    else:
        velocity.y = 0.0
    los_timer -= delta
    if los_timer <= 0.0:
        los_timer = 0.18
        los = target.alive and _can_see()
        if los:
            last_known = target.global_position
            has_last_known = true
            lost_t = 0.0
            if state == State.PATROL:
                state = State.CHASE
                get_tree().call_group("enemies", "ally_alert", global_position, 18.0, last_known)
    if not los:
        lost_t += delta
    match state:
        State.PATROL:
            _patrol(delta)
        State.CHASE:
            _chase(delta)
        State.ATTACK:
            _attack(delta)
        State.COVER:
            _cover(delta)
    move_and_slide()
    _animate(delta)


func _can_see() -> bool:
    var from: Vector3 = global_position + Vector3(0, 1.6, 0)
    var to: Vector3 = target.global_position + Vector3(0, 1.4, 0)
    var d: Vector3 = to - from
    var dist: float = d.length()
    if dist > sight_range:
        return false
    if dist > 8.0:
        var fwd: Vector3 = -global_transform.basis.z
        if fwd.dot(d.normalized()) < 0.3:
            return false
    var q := PhysicsRayQueryParameters3D.create(from, to, 1, [get_rid()])
    return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func _blocked(dir: Vector3, length: float) -> bool:
    var from: Vector3 = global_position + Vector3(0, 0.7, 0)
    var q := PhysicsRayQueryParameters3D.create(from, from + dir * length, 1, [get_rid()])
    return not get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func _avoid(dir: Vector3) -> Vector3:
    if not _blocked(dir, 1.6):
        return dir
    var l: Vector3 = dir.rotated(Vector3.UP, 0.9)
    var r: Vector3 = dir.rotated(Vector3.UP, -0.9)
    var lb: bool = _blocked(l, 1.6)
    var rb: bool = _blocked(r, 1.6)
    if not lb and not rb:
        return l if avoid_bias > 0.0 else r
    if not lb:
        return l
    if not rb:
        return r
    avoid_bias = -avoid_bias
    return dir.rotated(Vector3.UP, 1.9 * avoid_bias)


func _face(dir: Vector3, delta: float) -> void:
    if dir.length() < 0.01:
        return
    var yaw: float = atan2(-dir.x, -dir.z)
    rotation.y = lerp_angle(rotation.y, yaw, minf(1.0, 9.0 * delta))


func _stop(delta: float) -> void:
    velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
    velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)


func _walk_to(p: Vector3, spd: float, delta: float, keep_facing: bool = false) -> void:
    var d: Vector3 = p - global_position
    d.y = 0.0
    if d.length() < 0.05:
        _stop(delta)
        return
    d = d.normalized()
    steer_t -= delta
    if steer_t <= 0.0 or steer_dir.dot(d) < 0.2:
        steer_t = 0.15
        steer_dir = _avoid(d)
    var v: Vector3 = steer_dir * spd
    velocity.x = lerpf(velocity.x, v.x, minf(1.0, 10.0 * delta))
    velocity.z = lerpf(velocity.z, v.z, minf(1.0, 10.0 * delta))
    if not keep_facing:
        _face(steer_dir, delta)


func _patrol(delta: float) -> void:
    if patrol_points.is_empty():
        _stop(delta)
        return
    if wait_t > 0.0:
        wait_t -= delta
        _stop(delta)
        return
    var p: Vector3 = patrol_points[patrol_idx]
    var dd: float = Vector2(p.x - global_position.x, p.z - global_position.z).length()
    if dd < 1.0:
        patrol_idx = (patrol_idx + 1) % patrol_points.size()
        wait_t = randf_range(1.0, 2.5)
        return
    _walk_to(p, 1.9, delta)


func _chase(delta: float) -> void:
    if not has_last_known:
        state = State.PATROL
        return
    var dist: float = global_position.distance_to(target.global_position)
    if los and dist < attack_range:
        state = State.ATTACK
        strafe_t = 0.0
        burst_left = 0
        fire_cd = randf_range(0.3, 0.7)
        return
    _walk_to(last_known, 4.0, delta)
    var arrive: float = Vector2(last_known.x - global_position.x, last_known.z - global_position.z).length()
    if arrive < 1.5 and not los:
        _stop(delta)
        if lost_t > 6.0:
            state = State.PATROL
            has_last_known = false
    if lost_t > 16.0:
        state = State.PATROL
        has_last_known = false


func _attack(delta: float) -> void:
    var to: Vector3 = target.global_position - global_position
    to.y = 0.0
    var dist: float = to.length()
    var nd: Vector3 = to.normalized()
    _face(nd, delta)
    if not los:
        _stop(delta)
        if lost_t > 0.8:
            state = State.CHASE
        return
    if dist > attack_range * 1.25:
        state = State.CHASE
        return
    if dist < 6.0:
        _walk_to(global_position - nd * 3.0, 2.5, delta, true)
    else:
        strafe_t -= delta
        if strafe_t <= 0.0:
            strafe_t = randf_range(0.8, 2.0)
            strafe_dir = 1.0 if randf() < 0.5 else -1.0
        var side: Vector3 = nd.cross(Vector3.UP) * strafe_dir
        if _blocked(side, 1.2):
            strafe_dir = -strafe_dir
            side = -side
        velocity.x = lerpf(velocity.x, side.x * 1.8, minf(1.0, 8.0 * delta))
        velocity.z = lerpf(velocity.z, side.z * 1.8, minf(1.0, 8.0 * delta))
    if burst_left > 0:
        burst_cd -= delta
        if burst_cd <= 0.0:
            _shoot()
            burst_left -= 1
            burst_cd = 0.13
            if burst_left == 0:
                fire_cd = randf_range(0.9, 1.8)
    else:
        fire_cd -= delta
        if fire_cd <= 0.0 and aim_blend > 0.7:
            burst_left = randi_range(2, 4)
            burst_cd = 0.0
    if health < max_health * 0.45 and cover_cd <= 0.0:
        if _find_cover():
            state = State.COVER
            in_cover = false
            cover_wait = randf_range(2.5, 4.0)


func _find_cover() -> bool:
    var best: Vector3 = Vector3.ZERO
    var best_d: float = 9999.0
    var found: bool = false
    var head: Vector3 = target.global_position + Vector3(0, 1.5, 0)
    var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
    for c in get_tree().get_nodes_in_group("cover"):
        var cp: Vector3 = (c as Node3D).global_position
        var d: float = cp.distance_to(global_position)
        if d > 22.0 or d >= best_d:
            continue
        var q := PhysicsRayQueryParameters3D.create(cp + Vector3(0, 1.0, 0), head, 1)
        if not space.intersect_ray(q).is_empty():
            best = cp
            best_d = d
            found = true
    if found:
        cover_pos = best
    return found


func _cover(delta: float) -> void:
    if not in_cover:
        var d: float = Vector2(cover_pos.x - global_position.x, cover_pos.z - global_position.z).length()
        if d < 0.9:
            in_cover = true
        else:
            _walk_to(cover_pos, 4.6, delta)
            return
    _stop(delta)
    var to: Vector3 = target.global_position - global_position
    to.y = 0.0
    _face(to.normalized(), delta)
    cover_wait -= delta
    health = minf(max_health, health + 2.0 * delta)
    if cover_wait <= 0.0:
        in_cover = false
        cover_cd = 10.0
        state = State.CHASE
        has_last_known = true
        last_known = target.global_position


func _shoot() -> void:
    var from: Vector3 = muzzle.global_position
    var chest: Vector3 = target.global_position + Vector3(0, 1.2, 0)
    var dist: float = from.distance_to(chest)
    var chance: float = clampf(0.8 - dist * 0.025, 0.18, 0.7)
    if target.weapons.aiming:
        chance *= 0.8
    var endp: Vector3 = chest
    if randf() < chance:
        target.take_damage(damage, global_position)
    else:
        endp += Vector3(randf_range(-1.2, 1.2), randf_range(-0.8, 0.8), randf_range(-1.2, 1.2))
    SFX.play_at("shot_enemy", global_position, 0.0, randf_range(0.9, 1.1))
    Fx.tracer(get_parent(), from, endp, Color(1.0, 0.55, 0.2), 0.03, 0.08)
    Fx.flash(get_parent(), from)
    recoil_anim = 1.0


func _animate(delta: float) -> void:
    var spd: float = Vector2(velocity.x, velocity.z).length()
    anim_phase += spd * delta * 2.4
    var amp: float = clampf(spd / 3.5, 0.0, 1.0)
    var want_aim: float = 0.0
    if state == State.ATTACK or (state == State.COVER and in_cover):
        want_aim = 1.0
    elif state == State.CHASE:
        want_aim = 0.55
    aim_blend = move_toward(aim_blend, want_aim, delta * 5.0)
    recoil_anim = move_toward(recoil_anim, 0.0, delta * 9.0)
    var want_crouch: float = 1.0 if (state == State.COVER and in_cover) else 0.0
    crouch_blend = move_toward(crouch_blend, want_crouch, delta * 6.0)
    var sw: float = sin(anim_phase)
    leg_l.rotation.x = sw * 0.75 * amp
    leg_r.rotation.x = -sw * 0.75 * amp
    arm_r.rotation.x = lerpf(0.4, 1.45, aim_blend) + recoil_anim * 0.12
    arm_l.rotation.x = lerpf(-sw * 0.5 * amp, 1.3, aim_blend)
    arm_l.rotation.z = aim_blend * 0.55
    model.position.y = -0.38 * crouch_blend
    model.rotation.x = 0.12 * crouch_blend
