extends Node
## Pengaturan lokal + progres. Disimpan di user://settings.cfg
signal changed
const SAVE_PATH := "user://settings.cfg"
const GRAPHICS_NAMES := ["Smooth", "Medium", "High", "Ultra"]
const GRAPHICS_DESC := [
    "Bayangan mati, efek minimal, render ringan (resolusi 3D 75%).",
    "Bayangan 2-split, efek sedang, tekstur menengah.",
    "Bayangan 4-split, tekstur tinggi, bloom + SSAO, partikel sedang.",
    "Kualitas maksimum: bayangan detail, tekstur tajam, bloom, SSAO, partikel penuh."
]
const FPS_OPTIONS := [30, 45, 60]
var sensitivity: float = 1.0
var master_volume: float = 0.8
var music_on: bool = true
var auto_scope: bool = false
var graphics: int = 1
var target_fps: int = 60
var checkpoint: int = 0
var missions_completed: int = 0
var best_time: float = 0.0
func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    load_settings()
    Engine.max_fps = target_fps
func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    sensitivity = float(cfg.get_value("input", "sensitivity", 1.0))
    auto_scope = bool(cfg.get_value("input", "auto_scope", false))
    if not auto_scope:
        auto_scope = bool(cfg.get_value("input", "auto_aim", false))
    master_volume = float(cfg.get_value("audio", "master_volume", 0.8))
    music_on = bool(cfg.get_value("audio", "music_on", true))
    graphics = clampi(int(cfg.get_value("graphics", "preset", 1)), 0, 3)
    target_fps = int(cfg.get_value("graphics", "target_fps", 60))
    checkpoint = clampi(int(cfg.get_value("progress", "checkpoint", 0)), 0, 2)
    missions_completed = int(cfg.get_value("progress", "missions_completed", 0))
    best_time = float(cfg.get_value("progress", "best_time", 0.0))
func save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("input", "sensitivity", sensitivity)
    cfg.set_value("input", "auto_scope", auto_scope)
    cfg.set_value("audio", "master_volume", master_volume)
    cfg.set_value("audio", "music_on", music_on)
    cfg.set_value("graphics", "preset", graphics)
    cfg.set_value("graphics", "target_fps", target_fps)
    cfg.set_value("progress", "checkpoint", checkpoint)
    cfg.set_value("progress", "missions_completed", missions_completed)
    cfg.set_value("progress", "best_time", best_time)
    cfg.save(SAVE_PATH)
    apply_audio()
    Engine.max_fps = target_fps
    changed.emit()
func apply_audio() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.0001)))
    var mi: int = AudioServer.get_bus_index("Music")
    if mi >= 0:
        AudioServer.set_bus_mute(mi, not music_on)
func texture_size() -> int:
    return [64, 128, 256, 512][clampi(graphics, 0, 3)]
func view_distance() -> float:
    return [55.0, 90.0, 150.0, 200.0][clampi(graphics, 0, 3)]
func dust_amount() -> int:
    return [0, 60, 160, 240][clampi(graphics, 0, 3)]
func apply_graphics(vp: Viewport, sun: DirectionalLight3D, env: Environment) -> void:
    var g: int = clampi(graphics, 0, 3)
    Engine.max_fps = target_fps
    var scales := [0.75, 0.9, 1.0, 1.0]
    vp.scaling_3d_scale = scales[g]
    if g <= 1:
        vp.msaa_3d = Viewport.MSAA_DISABLED
    elif g == 2:
        vp.msaa_3d = Viewport.MSAA_2X
    else:
        vp.msaa_3d = Viewport.MSAA_4X
    sun.shadow_enabled = g > 0
    if g == 1:
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
        sun.directional_shadow_max_distance = 40.0
    elif g >= 2:
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
        sun.directional_shadow_max_distance = 70.0 if g == 2 else 100.0
    var atlas := [1024, 2048, 4096, 4096]
    RenderingServer.directional_shadow_atlas_set_size(atlas[g], true)
    env.glow_enabled = g >= 2
    if g >= 2:
        env.glow_intensity = 0.7
        env.glow_bloom = 0.04
    env.ssao_enabled = g >= 2
    if g >= 2:
        env.ssao_light_affect = 0.5
    var fogs := [0.008, 0.011, 0.013, 0.015]
    env.fog_density = fogs[g]
