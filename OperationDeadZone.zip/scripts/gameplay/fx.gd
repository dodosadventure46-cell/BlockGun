extends RefCounted
## Efek visual: impact, tracer, muzzle flash, bekas peluru, darah.

static var _holes: Array = []
static var _flash_mat: StandardMaterial3D = null
static var _hole_mat: StandardMaterial3D = null
static var _mats: Dictionary = {}


static func _unshaded(c: Color) -> StandardMaterial3D:
    var key: String = "u_" + c.to_html()
    if _mats.has(key):
        return _mats[key]
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.albedo_color = c
    _mats[key] = m
    return m


static func _radial(c0: Color, c1: Color, mid: float) -> GradientTexture2D:
    var g := Gradient.new()
    g.colors = PackedColorArray([c0, c0, c1])
    g.offsets = PackedFloat32Array([0.0, mid, 1.0])
    var t := GradientTexture2D.new()
    t.gradient = g
    t.fill = GradientTexture2D.FILL_RADIAL
    t.fill_from = Vector2(0.5, 0.5)
    t.fill_to = Vector2(1.0, 0.5)
    t.width = 64
    t.height = 64
    return t


static func _free_later(node: Node, t: float) -> void:
    node.get_tree().create_timer(t).timeout.connect(node.queue_free)


static func _particles(parent: Node, pos: Vector3, dir: Vector3, amount: int, color: Color, life: float, vmin: float, vmax: float, spread: float) -> void:
    var p := CPUParticles3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.025
    mesh.height = 0.05
    mesh.radial_segments = 4
    mesh.rings = 2
    mesh.material = _unshaded(color)
    p.mesh = mesh
    p.amount = amount
    p.lifetime = life
    p.one_shot = true
    p.explosiveness = 1.0
    p.direction = dir
    p.spread = spread
    p.initial_velocity_min = vmin
    p.initial_velocity_max = vmax
    p.gravity = Vector3(0, -9.0, 0)
    p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(p)
    p.global_position = pos
    p.emitting = true
    _free_later(p, life + 0.6)


static func impact(parent: Node, pos: Vector3, normal: Vector3) -> void:
    _particles(parent, pos, normal, 4 + Settings.graphics * 3, Color(1.0, 0.8, 0.4), 0.35, 1.5, 4.0, 55.0)
    if Settings.graphics > 0:
        _particles(parent, pos, normal, 3, Color(0.5, 0.48, 0.45), 0.7, 0.4, 1.2, 70.0)
    if _hole_mat == null:
        _hole_mat = StandardMaterial3D.new()
        _hole_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _hole_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _hole_mat.albedo_texture = _radial(Color(0, 0, 0, 0.85), Color(0, 0, 0, 0), 0.35)
    var q := MeshInstance3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2(0.14, 0.14)
    qm.material = _hole_mat
    q.mesh = qm
    q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(q)
    q.global_position = pos + normal * 0.012
    var up: Vector3 = Vector3.UP
    if absf(normal.y) > 0.99:
        up = Vector3.RIGHT
    q.look_at(q.global_position - normal, up)
    _holes.append(q)
    if _holes.size() > 36:
        var old = _holes.pop_front()
        if is_instance_valid(old):
            old.queue_free()


static func blood(parent: Node, pos: Vector3) -> void:
    _particles(parent, pos, Vector3.UP, 6 + Settings.graphics * 3, Color(0.6, 0.02, 0.02), 0.5, 1.0, 3.0, 80.0)


static func tracer(parent: Node, a: Vector3, b: Vector3, color: Color, w: float = 0.02, life: float = 0.07) -> void:
    var d: Vector3 = b - a
    var l: float = d.length()
    if l < 0.3:
        return
    var m := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(w, w, l)
    bm.material = _unshaded(color)
    m.mesh = bm
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(m)
    m.global_position = a + d * 0.5
    var up: Vector3 = Vector3.UP
    if absf(d.normalized().y) > 0.99:
        up = Vector3.RIGHT
    m.look_at(b, up)
    _free_later(m, life)


static func flash_mesh(size: float) -> MeshInstance3D:
    if _flash_mat == null:
        _flash_mat = StandardMaterial3D.new()
        _flash_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _flash_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _flash_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
        _flash_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
        _flash_mat.albedo_texture = _radial(Color(1.0, 0.8, 0.4, 1.0), Color(0, 0, 0, 1.0), 0.1)
    var q := MeshInstance3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2(size, size)
    qm.material = _flash_mat
    q.mesh = qm
    q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    return q


static func flash(parent: Node, pos: Vector3, size: float = 0.6) -> void:
    var q: MeshInstance3D = flash_mesh(size)
    parent.add_child(q)
    q.global_position = pos
    _free_later(q, 0.05)
