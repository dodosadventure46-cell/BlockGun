extends Node3D
## Sistem senjata: magasin, cadangan, tembak (hitscan), recoil, reload, ganti senjata, animasi.
const Fx := preload("res://scripts/gameplay/fx.gd")
const WeaponModels := preload("res://scripts/weapons/weapon_models.gd")
signal hit_confirmed(headshot: bool, killed: bool)
enum S { IDLE, RELOADING, SWITCHING }
const DEFS := [
    {"title": "SCAR-H SCORPION", "is_auto": true, "mag": 30, "reserve": 150, "damage": 24.0, "rate": 0.095, "spread": 0.018, "recoil": 0.011, "reload": 2.1, "dist": 140.0, "sound": "shot_rifle", "pellets": 1, "zoom": 22.0, "noise": 55.0, "kick": 0.035},
    {"title": "P9 PISTOL", "is_auto": false, "mag": 12, "reserve": 72, "damage": 40.0, "rate": 0.2, "spread": 0.012, "recoil": 0.016, "reload": 1.5, "dist": 120.0, "sound": "shot_pistol", "pellets": 1, "zoom": 12.0, "noise": 38.0, "kick": 0.05},
    {"title": "S12 SHOTGUN", "is_auto": false, "mag": 6, "reserve": 36, "damage": 13.0, "rate": 0.85, "spread": 0.055, "recoil": 0.045, "reload": 2.6, "dist": 50.0, "sound": "shot_shotgun", "pellets": 9, "zoom": 8.0, "noise": 62.0, "kick": 0.09}
]
var player = null
var vm: Node3D
var models: Array = []
var ammo: Array = []
var reserve: Array = []
var cur: int = 0
var state: int = S.IDLE
var state_t: float = 0.0
var state_dur: float = 1.0
var cooldown: float = 0.0
var buffer_t: float = 0.0
var aiming: bool = false
var aim_t: float = 0.0
var kick_pos: float = 0.0
var kick_rot: float = 0.0
var bob: float = 0.0
var pump_t: float = 0.0
var burst: int = 0
var fire_gap: float = 99.0
var firing: bool = false
var flash: Node3D
var flash_light: OmniLight3D
var flash_t: float = 0.0
var switch_to: int = 0
var swapped: bool = false
func setup(p: Node) -> void:
    player = p
    vm = Node3D.new()
    add_child(vm)
    for i in DEFS.size():
        var m: Node3D = WeaponModels.build(i)
        vm.add_child(m)
        m.visible = false
        models.append(m)
        ammo.append(int(DEFS[i]["mag"]))
        reserve.append(int(DEFS[i]["reserve"]))
    flash = Node3D.new()
    flash.visible = false
    add_child(flash)
    flash.add_child(Fx.flash_mesh(0.28))
    flash_light = OmniLight3D.new()
    flash_light.light_color = Color(1.0, 0.75, 0.4)
    flash_light.light_energy = 2.0
    flash_light.omni_range = 7.0
    flash_light.shadow_enabled = false
    flash.add_child(flash_light)
    _show_current()
func _show_current() -> void:
    for i in models.size():
        models[i].visible = (i == cur)
func weapon_def() -> Dictionary:
    return DEFS[cur]
func weapon_title() -> String:
    return str(DEFS[cur]["title"])
func mag_ammo() -> int:
    return int(ammo[cur])
func reserve_ammo() -> int:
    return int(reserve[cur])
func is_reloading() -> bool:
    return state == S.RELOADING
func spread_amount() -> float:
    var sp: float = float(DEFS[cur]["spread"])
    if aiming:
        sp *= 0.35
    if player != null:
        sp += Vector2(player.velocity.x, player.velocity.z).length() * 0.0015
        if player.has_method("is_crouching") and player.is_crouching():
            sp *= 0.7
    return sp
func reload_progress() -> float:
    if state != S.RELOADING:
        return -1.0
    return clampf(1.0 - state_t / state_dur, 0.0, 1.0)
func _process(delta: float) -> void:
    if player == null:
        return
    var c = player.controls
    cooldown = maxf(0.0, cooldown - delta)
    buffer_t = maxf(0.0, buffer_t - delta)
    fire_gap += delta
    if fire_gap > 0.3:
        burst = 0
    firing = fire_gap < 0.15
    if flash_t > 0.0:
        flash_t -= delta
        var mz: Node3D = models[cur].get_node_or_null("Muzzle")
        if mz != null:
            flash.global_position = mz.global_position
        if flash_t <= 0.0:
            flash.visible = false
    if player.alive and c != null:
        _handle_input(c)
    else:
        aiming = false
    _update_state(delta)
    var want_aim: float = 0.0
    if aiming and state != S.SWITCHING:
        want_aim = 1.0
    aim_t = move_toward(aim_t, want_aim, delta * 7.0)
    player.camera.fov = lerpf(75.0, 75.0 - float(DEFS[cur]["zoom"]), aim_t)
    _animate(delta)
func _handle_input(c) -> void:
    var w: Dictionary = DEFS[cur]
    aiming = c.aim_on or (Settings.auto_scope and c.fire_held)
    if c.consume("reload"):
        start_reload()
    if c.consume("switch"):
        switch_next()
    var pressed: bool = c.consume("fire_edge")
    if pressed:
        buffer_t = 0.2
    if state == S.IDLE and cooldown <= 0.0:
        var wants: bool = (bool(w["is_auto"]) and c.fire_held) or buffer_t > 0.0
        if wants:
            if int(ammo[cur]) > 0:
                _shoot()
                buffer_t = 0.0
            else:
                if buffer_t > 0.0:
                    SFX.play("empty")
                    buffer_t = 0.0
                if int(reserve[cur]) > 0:
                    start_reload()
func _update_state(delta: float) -> void:
    if state == S.IDLE:
        return
    state_t -= delta
    if state == S.SWITCHING and not swapped and state_t <= state_dur * 0.5:
        cur = switch_to
        swapped = true
        _show_current()
    if state_t <= 0.0:
        if state == S.RELOADING:
            _finish_reload()
        state = S.IDLE
func _spread_dir(spread: float) -> Vector3:
    var b: Basis = player.camera.global_transform.basis
    var sp: float = spread
    if aiming:
        sp *= 0.35
    sp += Vector2(player.velocity.x, player.velocity.z).length() * 0.0015
    var dir: Vector3 = -b.z + b.x * randf_range(-sp, sp) + b.y * randf_range(-sp, sp)
    return dir.normalized()
func _shoot() -> void:
    var w: Dictionary = DEFS[cur]
    ammo[cur] = int(ammo[cur]) - 1
    cooldown = float(w["rate"])
    burst += 1
    fire_gap = 0.0
    SFX.play(str(w["sound"]), -1.0, randf_range(0.96, 1.04))
    get_tree().call_group("enemies", "hear_noise", player.global_position, float(w["noise"]))
    var cam: Camera3D = player.camera
    var origin: Vector3 = cam.global_position
    var space: PhysicsDirectSpaceState3D = player.get_world_3d().direct_space_state
    var scene: Node = get_tree().current_scene
    var mz: Node3D = models[cur].get_node_or_null("Muzzle")
    var mpos: Vector3 = origin
    if mz != null:
        mpos = mz.global_position
    var rng_d: float = float(w["dist"])
    for i in int(w["pellets"]):
        var dir: Vector3 = _spread_dir(float(w["spread"]))
        var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * rng_d, 5, [player.get_rid()])
        var hit: Dictionary = space.intersect_ray(q)
        var endp: Vector3 = origin + dir * rng_d
        if not hit.is_empty():
            endp = hit["position"]
            var col = hit["collider"]
            if col != null and col.has_method("take_damage"):
                var dist: float = origin.distance_to(endp)
                var dmg: float = float(w["damage"]) * clampf(1.0 - (dist / rng_d) * 0.6, 0.3, 1.0)
                var head: bool = col.has_method("is_head_hit") and col.is_head_hit(endp)
                if head:
                    dmg *= 2.2
                col.take_damage(dmg, head, player.global_position)
                SFX.play("hit", -6.0)
                hit_confirmed.emit(head, col.health <= 0.0)
            else:
                Fx.impact(scene, endp, hit["normal"])
                SFX.play_at("impact", endp, -6.0, randf_range(0.9, 1.2))
        if i < 3:
            Fx.tracer(scene, mpos, endp, Color(1.0, 0.9, 0.55), 0.012, 0.05)
    var rec_mult: float = 1.0
    if aiming:
        rec_mult *= 0.55
    if player != null and player.has_method("is_crouching") and player.is_crouching():
        rec_mult *= 0.75
    player.kick(float(w["recoil"]) * rec_mult, burst)
    kick_pos = float(w["kick"])
    kick_rot = 0.1 + float(w["kick"]) * 2.0
    pump_t = 1.0
    flash.visible = true
    flash_t = 0.05
    flash.scale = Vector3.ONE * randf_range(0.8, 1.3)
    flash_light.visible = Settings.graphics > 0
func start_reload() -> void:
    var w: Dictionary = DEFS[cur]
    if state != S.IDLE or int(ammo[cur]) >= int(w["mag"]) or int(reserve[cur]) <= 0:
        return
    state = S.RELOADING
    state_dur = float(w["reload"])
    state_t = state_dur
    SFX.play("reload", -2.0)
func _finish_reload() -> void:
    var w: Dictionary = DEFS[cur]
    var need: int = int(w["mag"]) - int(ammo[cur])
    var take: int = mini(need, int(reserve[cur]))
    ammo[cur] = int(ammo[cur]) + take
    reserve[cur] = int(reserve[cur]) - take
func switch_next() -> void:
    if state == S.SWITCHING:
        return
    switch_to = (cur + 1) % DEFS.size()
    state = S.SWITCHING
    state_dur = 0.5
    state_t = 0.5
    swapped = false
    SFX.play("switch", -3.0)
func add_ammo() -> void:
    for i in DEFS.size():
        reserve[i] = int(reserve[i]) + int(DEFS[i]["mag"]) * 2
func snapshot() -> Dictionary:
    return {"ammo": ammo.duplicate(), "reserve": reserve.duplicate(), "cur": cur}
func restore(snap: Dictionary) -> void:
    if snap.has("ammo"):
        ammo = snap["ammo"].duplicate()
        reserve = snap["reserve"].duplicate()
        cur = int(snap["cur"])
        _show_current()
func smoke_test() -> void:
    _shoot()
    start_reload()
    state_t = 0.0
    _update_state(0.01)
    switch_next()
    state_t = 0.0
    _update_state(0.01)
    cooldown = 0.0
func _animate(delta: float) -> void:
    var hip := Vector3(0.2, -0.2, -0.42)
    var aimp := Vector3(0.0, -0.107, -0.48)
    var pos: Vector3 = hip.lerp(aimp, aim_t)
    var rot := Vector3.ZERO
    kick_pos = lerpf(kick_pos, 0.0, minf(1.0, 14.0 * delta))
    kick_rot = lerpf(kick_rot, 0.0, minf(1.0, 12.0 * delta))
    pos.z += kick_pos
    rot.x += kick_rot
    var spd: float = Vector2(player.velocity.x, player.velocity.z).length()
    if player.is_on_floor():
        bob += delta * spd * 1.6
    var amp: float = 1.0 - aim_t * 0.8
    pos.y += sin(bob * 2.0) * 0.004 * amp
    pos.x += cos(bob) * 0.005 * amp
    var model: Node3D = models[cur]
    var mag: Node3D = model.get_node_or_null("Mag")
    var pump: Node3D = model.get_node_or_null("Pump")
    if mag != null:
        mag.position = mag.get_meta("base")
    if state == S.RELOADING:
        var k: float = 1.0 - state_t / state_dur
        var curve: float = sin(k * PI)
        pos.y -= curve * 0.1
        rot.x -= curve * 0.55
        rot.z += curve * 0.3
        if mag != null:
            var mk: float = clampf((k - 0.2) / 0.5, 0.0, 1.0)
            mag.position = Vector3(mag.get_meta("base")) + Vector3(0, -sin(mk * PI) * 0.14, 0)
    elif state == S.SWITCHING:
        var k2: float = 1.0 - state_t / state_dur
        var low: float = 1.0 - absf(k2 * 2.0 - 1.0)
        pos.y -= low * 0.3
        rot.x -= low * 0.9
    pump_t = move_toward(pump_t, 0.0, delta * 2.5)
    if pump != null:
        pump.position = Vector3(pump.get_meta("base")) + Vector3(0, 0, 0.12 * sin(pump_t * PI))
    vm.position = vm.position.lerp(pos, minf(1.0, 18.0 * delta))
    vm.rotation = vm.rotation.lerp(rot, minf(1.0, 18.0 * delta))
