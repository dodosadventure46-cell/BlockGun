extends Control
## Kontrol sentuh: joystick melayang (kiri), kamera (kanan), tombol aksi.
const JOY_RADIUS := 100.0
var move_vec: Vector2 = Vector2.ZERO
var fire_held: bool = false
var aim_on: bool = false
var crouch_on: bool = false
var look_accum: Vector2 = Vector2.ZERO
var edges: Dictionary = {}
var touches: Dictionary = {}
var buttons: Dictionary = {}
var down: Dictionary = {}
var joy_center: Vector2 = Vector2.ZERO
var joy_off: Vector2 = Vector2.ZERO
var joy_active: bool = false
func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    anchor_right = 1.0
    anchor_bottom = 1.0
    _layout()
    get_viewport().size_changed.connect(_layout)
func _layout() -> void:
    var s: Vector2 = get_viewport_rect().size
    buttons = {
        "fire": {"pos": Vector2(s.x - 170, s.y - 170), "r": 85.0, "label": "TEMBAK"},
        "aim": {"pos": Vector2(s.x - 330, s.y - 110), "r": 55.0, "label": "BIDIK"},
        "reload": {"pos": Vector2(s.x - 350, s.y - 250), "r": 50.0, "label": "ISI"},
        "jump": {"pos": Vector2(s.x - 150, s.y - 330), "r": 55.0, "label": "LOMPAT"},
        "switch": {"pos": Vector2(s.x - 470, s.y - 320), "r": 48.0, "label": "GANTI"},
        "crouch": {"pos": Vector2(s.x - 470, s.y - 190), "r": 48.0, "label": "JONGKOK"},
        "pause": {"pos": Vector2(s.x - 70, 60), "r": 36.0, "label": "II"}
    }
    if not joy_active:
        joy_center = Vector2(190, s.y - 190)
    queue_redraw()
func reset() -> void:
    touches.clear()
    down.clear()
    move_vec = Vector2.ZERO
    fire_held = false
    aim_on = false
    crouch_on = false
    joy_active = false
    joy_off = Vector2.ZERO
    look_accum = Vector2.ZERO
    edges.clear()
    _layout()
func consume(nm: String) -> bool:
    if edges.get(nm, false):
        edges[nm] = false
        return true
    return false
func consume_look() -> Vector2:
    var l: Vector2 = look_accum
    look_accum = Vector2.ZERO
    return l
func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _press(event.index, event.position)
        else:
            _release(event.index)
    elif event is InputEventScreenDrag:
        _drag(event.index, event.position, event.relative)
func _press(idx: int, pos: Vector2) -> void:
    var s: Vector2 = get_viewport_rect().size
    for n in buttons:
        var b: Dictionary = buttons[n]
        if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.2:
            touches[idx] = {"role": "btn", "btn": n}
            down[n] = int(down.get(n, 0)) + 1
            match n:
                "fire":
                    fire_held = true
                    edges["fire_edge"] = true
                "aim":
                    aim_on = not aim_on
                "crouch":
                    crouch_on = not crouch_on
                "jump":
                    edges["jump"] = true
                "reload":
                    edges["reload"] = true
                "switch":
                    edges["switch"] = true
                "pause":
                    edges["pause"] = true
            queue_redraw()
            return
    if pos.x < s.x * 0.42 and not joy_active:
        joy_active = true
        joy_center = Vector2(clampf(pos.x, JOY_RADIUS + 10.0, s.x * 0.42), clampf(pos.y, JOY_RADIUS + 10.0, s.y - JOY_RADIUS - 10.0))
        joy_off = pos - joy_center
        touches[idx] = {"role": "joy"}
        _update_joy()
    else:
        touches[idx] = {"role": "look"}
    queue_redraw()
func _release(idx: int) -> void:
    if not touches.has(idx):
        return
    var t: Dictionary = touches[idx]
    touches.erase(idx)
    if t["role"] == "joy":
        joy_active = false
        joy_off = Vector2.ZERO
        move_vec = Vector2.ZERO
        _layout()
    elif t["role"] == "btn":
        var n: String = t["btn"]
        down[n] = maxi(0, int(down.get(n, 1)) - 1)
        if n == "fire" and int(down[n]) == 0:
            fire_held = false
    queue_redraw()
func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
    if not touches.has(idx):
        return
    var t: Dictionary = touches[idx]
    if t["role"] == "joy":
        joy_off = pos - joy_center
        _update_joy()
    elif t["role"] == "look":
        look_accum += rel
    elif t["role"] == "btn" and t["btn"] == "fire":
        look_accum += rel
    queue_redraw()
func _update_joy() -> void:
    var v: Vector2 = joy_off / JOY_RADIUS
    if v.length() > 1.0:
        v = v.normalized()
        joy_off = v * JOY_RADIUS
    if v.length() < 0.12:
        v = Vector2.ZERO
    move_vec = v
func _draw() -> void:
    var font: Font = ThemeDB.fallback_font
    draw_circle(joy_center, JOY_RADIUS, Color(1, 1, 1, 0.08))
    draw_arc(joy_center, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.4), 3.0)
    draw_circle(joy_center + joy_off, 44.0, Color(1, 1, 1, 0.28))
    for n in buttons:
        var b: Dictionary = buttons[n]
        var pressed: bool = int(down.get(n, 0)) > 0 or (n == "aim" and aim_on) or (n == "crouch" and crouch_on)
        var fill: Color = Color(0.95, 0.3, 0.1, 0.4) if pressed else Color(1, 1, 1, 0.13)
        draw_circle(b["pos"], b["r"], fill)
        draw_arc(b["pos"], b["r"], 0.0, TAU, 40, Color(1, 1, 1, 0.5), 3.0)
        var fs: int = 20 if float(b["r"]) > 50.0 else 16
        draw_string(font, b["pos"] + Vector2(-float(b["r"]), 6), str(b["label"]), HORIZONTAL_ALIGNMENT_CENTER, float(b["r"]) * 2.0, fs, Color(1, 1, 1, 0.9))
