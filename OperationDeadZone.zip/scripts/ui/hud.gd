extends CanvasLayer
## HUD: HP, amunisi, crosshair, objektif, pesan, progres, slot senjata, kontrol sentuh.
signal pause_requested
const TouchControls := preload("res://scripts/ui/touch_controls.gd")
const CrosshairScript := preload("res://scripts/ui/crosshair.gd")
const UiKit := preload("res://scripts/ui/ui_kit.gd")
const HP_W := 270.0
var player = null
var controls = null
var crosshair = null
var hp_fill: ColorRect
var hp_label: Label
var ammo_label: Label
var weapon_label: Label
var obj_label: Label
var dist_label: Label
var msg_label: Label
var vignette: TextureRect
var prog_back: ColorRect
var prog_fill: ColorRect
var prog_label: Label
var status_label: Label
var reload_back: ColorRect
var reload_fill: ColorRect
var slot_btns: Array = []
var msg_t: float = 0.0
var msg_dur: float = 0.0
var vig: float = 0.0
var pulse_t: float = 0.0
static func _slot_style(active: bool) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = Color(0.06, 0.07, 0.09, 0.85) if not active else Color(0.18, 0.1, 0.04, 0.95)
    s.border_color = Color(0.5, 0.5, 0.5, 0.7) if not active else Color(1.0, 0.6, 0.2, 1.0)
    s.set_border_width_all(2)
    s.set_corner_radius_all(8)
    s.content_margin_left = 4
    s.content_margin_right = 4
    s.content_margin_top = 4
    s.content_margin_bottom = 4
    return s
func _ready() -> void:
    layer = 5
    var root := Control.new()
    root.anchor_right = 1.0
    root.anchor_bottom = 1.0
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    var g := Gradient.new()
    g.colors = PackedColorArray([Color(0.8, 0, 0, 0), Color(0.8, 0, 0, 0), Color(0.8, 0, 0, 0.85)])
    g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
    var gt := GradientTexture2D.new()
    gt.gradient = g
    gt.fill = GradientTexture2D.FILL_RADIAL
    gt.fill_from = Vector2(0.5, 0.5)
    gt.fill_to = Vector2(1.0, 1.0)
    gt.width = 128
    gt.height = 128
    vignette = TextureRect.new()
    vignette.texture = gt
    vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    vignette.stretch_mode = TextureRect.STRETCH_SCALE
    vignette.anchor_right = 1.0
    vignette.anchor_bottom = 1.0
    vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
    vignette.modulate.a = 0.0
    root.add_child(vignette)
    crosshair = Control.new()
    crosshair.set_script(CrosshairScript)
    root.add_child(crosshair)
    var hp_border := ColorRect.new()
    hp_border.color = Color(0.88, 0.45, 0.16, 0.9)
    hp_border.position = Vector2(16, 14)
    hp_border.size = Vector2(316, 44)
    hp_border.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hp_border)
    var hp_back := ColorRect.new()
    hp_back.color = Color(0, 0, 0, 0.62)
    hp_back.position = Vector2(18, 16)
    hp_back.size = Vector2(312, 40)
    hp_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hp_back)
    var cross1 := ColorRect.new()
    cross1.color = Color(0.9, 0.15, 0.15)
    cross1.position = Vector2(28, 32)
    cross1.size = Vector2(12, 4)
    cross1.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(cross1)
    var cross2 := ColorRect.new()
    cross2.color = Color(0.9, 0.15, 0.15)
    cross2.position = Vector2(32, 28)
    cross2.size = Vector2(4, 12)
    cross2.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(cross2)
    hp_fill = ColorRect.new()
    hp_fill.color = Color(0.25, 0.85, 0.3)
    hp_fill.position = Vector2(46, 22)
    hp_fill.size = Vector2(HP_W, 28)
    hp_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hp_fill)
    hp_label = UiKit.label("HP 100", 18)
    hp_label.position = Vector2(52, 24)
    root.add_child(hp_label)
    status_label = UiKit.label("", 18, Color(1.0, 0.65, 0.3))
    status_label.position = Vector2(24, 66)
    root.add_child(status_label)
    var ammo_border := ColorRect.new()
    ammo_border.color = Color(0.88, 0.45, 0.16, 0.9)
    ammo_border.anchor_left = 1.0
    ammo_border.anchor_right = 1.0
    ammo_border.offset_left = -348
    ammo_border.offset_right = -14
    ammo_border.offset_top = 88
    ammo_border.offset_bottom = 194
    ammo_border.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(ammo_border)
    var ammo_back := ColorRect.new()
    ammo_back.color = Color(0, 0, 0, 0.62)
    ammo_back.anchor_left = 1.0
    ammo_back.anchor_right = 1.0
    ammo_back.offset_left = -346
    ammo_back.offset_right = -16
    ammo_back.offset_top = 90
    ammo_back.offset_bottom = 192
    ammo_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(ammo_back)
    weapon_label = UiKit.label("", 20, Color(1, 0.75, 0.4))
    weapon_label.anchor_left = 1.0
    weapon_label.anchor_right = 1.0
    weapon_label.offset_left = -340
    weapon_label.offset_right = -24
    weapon_label.offset_top = 94
    weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    root.add_child(weapon_label)
    ammo_label = UiKit.label("", 44)
    ammo_label.anchor_left = 1.0
    ammo_label.anchor_right = 1.0
    ammo_label.offset_left = -340
    ammo_label.offset_right = -24
    ammo_label.offset_top = 116
    ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    root.add_child(ammo_label)
    reload_back = ColorRect.new()
    reload_back.color = Color(0.1, 0.1, 0.12, 0.9)
    reload_back.anchor_left = 1.0
    reload_back.anchor_right = 1.0
    reload_back.offset_left = -338
    reload_back.offset_right = -26
    reload_back.offset_top = 172
    reload_back.offset_bottom = 184
    reload_back.visible = false
    reload_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(reload_back)
    reload_fill = ColorRect.new()
    reload_fill.color = Color(0.95, 0.55, 0.15)
    reload_fill.position = Vector2(2, 2)
    reload_fill.size = Vector2(0, 8)
    reload_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    reload_back.add_child(reload_fill)
    obj_label = UiKit.label("", 22, Color(1, 0.9, 0.6))
    obj_label.anchor_left = 0.5
    obj_label.anchor_right = 0.5
    obj_label.offset_left = -400
    obj_label.offset_right = 400
    obj_label.offset_top = 16
    obj_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    obj_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    root.add_child(obj_label)
    dist_label = UiKit.label("", 20, Color(0.8, 0.9, 1.0))
    dist_label.anchor_left = 0.5
    dist_label.anchor_right = 0.5
    dist_label.offset_left = -200
    dist_label.offset_right = 200
    dist_label.offset_top = 82
    dist_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    root.add_child(dist_label)
    msg_label = UiKit.label("", 34, Color(1, 1, 1))
    msg_label.anchor_left = 0.5
    msg_label.anchor_right = 0.5
    msg_label.offset_left = -450
    msg_label.offset_right = 450
    msg_label.offset_top = 150
    msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    msg_label.modulate.a = 0.0
    root.add_child(msg_label)
    prog_back = ColorRect.new()
    prog_back.color = Color(0, 0, 0, 0.6)
    prog_back.anchor_left = 0.5
    prog_back.anchor_right = 0.5
    prog_back.offset_left = -200
    prog_back.offset_right = 200
    prog_back.offset_top = 520
    prog_back.offset_bottom = 548
    prog_back.visible = false
    prog_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(prog_back)
    prog_fill = ColorRect.new()
    prog_fill.color = Color(0.3, 0.9, 0.4)
    prog_fill.position = Vector2(3, 3)
    prog_fill.size = Vector2(0, 22)
    prog_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    prog_back.add_child(prog_fill)
    prog_label = UiKit.label("MENGAKTIFKAN GENERATOR...", 20, Color(0.7, 1.0, 0.8))
    prog_label.anchor_left = 0.5
    prog_label.anchor_right = 0.5
    prog_label.offset_left = -250
    prog_label.offset_right = 250
    prog_label.offset_top = 486
    prog_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    prog_label.visible = false
    root.add_child(prog_label)
    # slot senjata bergambar (tengah bawah)
    var slot_bar := HBoxContainer.new()
    slot_bar.add_theme_constant_override("separation", 10)
    slot_bar.anchor_left = 0.5
    slot_bar.anchor_right = 0.5
    slot_bar.anchor_top = 1.0
    slot_bar.anchor_bottom = 1.0
    slot_bar.offset_left = -170
    slot_bar.offset_right = 170
    slot_bar.offset_top = -80
    slot_bar.offset_bottom = -10
    slot_bar.alignment = BoxContainer.ALIGNMENT_CENTER
    root.add_child(slot_bar)
    for i in 3:
        var b := Button.new()
        b.custom_minimum_size = Vector2(100, 70)
        b.add_theme_stylebox_override("normal", _slot_style(false))
        b.add_theme_stylebox_override("hover", _slot_style(false))
        b.add_theme_stylebox_override("pressed", _slot_style(true))
        b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
        var vb := VBoxContainer.new()
        vb.alignment = BoxContainer.ALIGNMENT_CENTER
        vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
        var tr := TextureRect.new()
        var tx = load("res://assets/textures/w_slot_%d.jpeg" % i) as Texture2D
        if tx != null:
            tr.texture = tx
        tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
        tr.custom_minimum_size = Vector2(84, 38)
        tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
        vb.add_child(tr)
        var lb := UiKit.label("", 13, Color(1, 1, 1))
        lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        lb.mouse_filter = Control.MOUSE_FILTER_IGNORE
        vb.add_child(lb)
        b.add_child(vb)
        var idx: int = i
        b.pressed.connect(func():
            if player != null and is_instance_valid(player):
                player.weapons.switch_to_idx(idx))
        slot_bar.add_child(b)
        slot_btns.append({"btn": b, "label": lb, "idx": idx})
    controls = Control.new()
    controls.set_script(TouchControls)
    root.add_child(controls)
func bind(p: Node) -> void:
    player = p
func set_objective(text: String) -> void:
    obj_label.text = "OBJEKTIF: " + text
func set_distance(m: float) -> void:
    dist_label.text = "Jarak: %d m" % int(m)
func set_progress(v: float) -> void:
    var vis: bool = v >= 0.0
    prog_back.visible = vis
    prog_label.visible = vis
    if vis:
        prog_fill.size.x = 394.0 * clampf(v, 0.0, 1.0)
func show_message(text: String, secs: float = 3.0) -> void:
    msg_label.text = text
    msg_t = secs
    msg_dur = secs
    msg_label.modulate.a = 1.0
func flash_damage() -> void:
    vig = 1.0
func hitmarker(head: bool, killed: bool) -> void:
    crosshair.hit_t = 0.3
    crosshair.hit_head = head or killed
func _process(delta: float) -> void:
    if player == null or not is_instance_valid(player):
        return
    pulse_t += delta
    if controls.consume("pause"):
        pause_requested.emit()
    var ratio: float = clampf(player.health / player.max_health, 0.0, 1.0)
    hp_fill.size.x = HP_W * ratio
    hp_fill.color = Color(0.85, 0.15, 0.1).lerp(Color(0.25, 0.85, 0.3), ratio)
    if ratio < 0.3:
        hp_fill.modulate.a = 0.65 + 0.35 * absf(sin(pulse_t * 6.0))
    else:
        hp_fill.modulate.a = 1.0
    hp_label.text = "HP  %d" % int(ceil(player.health))
    var wp = player.weapons
    var mode: String = "AUTO" if bool(wp.weapon_def()["is_auto"]) else "SEMI"
    weapon_label.text = wp.weapon_title() + "   [" + mode + "]"
    var rp: float = wp.reload_progress()
    if rp >= 0.0:
        ammo_label.text = "ISI ULANG..."
        reload_back.visible = true
        reload_fill.size.x = 306.0 * rp
    else:
        ammo_label.text = "%d / %d" % [wp.mag_ammo(), wp.reserve_ammo()]
        reload_back.visible = false
    # update slot senjata: highlight aktif + amunisi
    for s in slot_btns:
        var i: int = int(s["idx"])
        var active: bool = (i == wp.cur)
        s["btn"].add_theme_stylebox_override("normal", _slot_style(active))
        var am: int = int(wp.ammo[i]) if i < wp.ammo.size() else 0
        var rs: int = int(wp.reserve[i]) if i < wp.reserve.size() else 0
        s["label"].text = "%d/%d" % [am, rs]
    var st: String = ""
    if Settings.auto_scope:
        st += "AUTO-SCOPE   "
    if player.is_crouching():
        st += "JONGKOK   "
    if wp.aiming:
        st += "BIDIK"
    status_label.text = st
    status_label.modulate.a = 0.95 if st != "" else 0.0
    crosshair.aiming = wp.aiming
    crosshair.gap = lerpf(crosshair.gap, 8.0 + wp.spread_amount() * 500.0, minf(1.0, 12.0 * delta))
    if msg_t > 0.0:
        msg_t -= delta
        msg_label.modulate.a = clampf(msg_t / 0.6, 0.0, 1.0)
    if vig > 0.0:
        vig = maxf(0.0, vig - delta * 1.6)
    var low: float = 0.35 if ratio < 0.3 else 0.0
    vignette.modulate.a = maxf(vig, low)
