extends CharacterBody3D
## Pemain FPS: gerak, lompat, kamera, kesehatan.

const WeaponHolderScene := preload("res://scenes/weapons/weapon_holder.tscn")

signal died
signal damaged(amount)
signal health_changed(hp, max_hp)

const WALK_SPEED := 5.4
const JUMP_VELOCITY := 5.2
const GRAVITY := 15.0

var controls = null
var max_health: float = 100.0
var health: float = 100.0
var alive: bool = true
var pitch: float = 0.0
var recoil_offset: float = 0.0
var head: Node3D
var camera: Camera3D
var weapons = null
var step_acc: float = 0.0
var bob_t: float = 0.0
var since_damage: float = 99.0
var crouch_t: float = 0.0
var collision_cs: CollisionShape3D
var collision_cap: CapsuleShape3D


func _ready() -> void:
    add_to_group("player")
    collision_layer = 2
    collision_mask = 1 | 4
    floor_snap_length = 0.3
    collision_cs = CollisionShape3D.new()
    collision_cap = CapsuleShape3D.new()
    collision_cap.radius = 0.4
    collision_cap.height = 1.8
    collision_cs.shape = collision_cap
    collision_cs.position = Vector3(0, 0.9, 0)
    add_child(collision_cs)
    head = Node3D.new()
    head.position = Vector3(0, 1.62, 0)
    add_child(head)
    camera = Camera3D.new()
    camera.fov = 75.0
    camera.near = 0.05
    camera.far = 220.0
    head.add_child(camera)
    camera.make_current()
    weapons = WeaponHolderScene.instantiate()
    camera.add_child(weapons)
    weapons.setup(self)
    # partikel debu atmosfer (mengikuti pemain, dunia-lokal)
    var amount: int = Settings.dust_amount()
    if amount > 0:
        var dust := CPUParticles3D.new()
        var qm := QuadMesh.new()
        qm.size = Vector2(0.05, 0.05)
        var mat := StandardMaterial3D.new()
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.albedo_color = Color(0.8, 0.75, 0.65, 0.5)
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
        qm.material = mat
        dust.mesh = qm
        dust.amount = amount
        dust.lifetime = 7.0
        dust.preprocess = 7.0
        dust.local_coords = false
        dust.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
        dust.emission_box_extents = Vector3(14, 4, 14)
        dust.direction = Vector3(1, 0.1, 0.3)
        dust.spread = 40.0
        dust.initial_velocity_min = 0.2
        dust.initial_velocity_max = 0.8
        dust.gravity = Vector3(0, -0.05, 0)
        dust.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        dust.position = Vector3(0, 1.5, 0)
        add_child(dust)


func _process(delta: float) -> void:
    if not alive:
        return
    var look := Vector2.ZERO
    if controls != null:
        look = controls.consume_look()
    var f: float = 0.0042 * Settings.sensitivity
    if weapons.aiming:
        f *= 0.55
    rotate_y(-look.x * f)
    pitch = clampf(pitch - look.y * f, -1.45, 1.45)
    if Settings.auto_aim and controls != null and controls.fire_held:
        _apply_auto_aim(delta)
    recoil_offset = lerpf(recoil_offset, 0.0, minf(1.0, 9.0 * delta))
    head.rotation.x = pitch + recoil_offset
    var head_base: float = lerpf(1.62, 0.95, crouch_t)
    var spd: float = Vector2(velocity.x, velocity.z).length()
    if is_on_floor() and spd > 0.5:
        bob_t += delta * spd * 1.9
        head.position.y = head_base + sin(bob_t) * 0.035 * minf(spd / 5.0, 1.0)
    else:
        head.position.y = lerpf(head.position.y, head_base, minf(1.0, 8.0 * delta))


func _physics_process(delta: float) -> void:
    if not alive:
        velocity.x = move_toward(velocity.x, 0.0, 10.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 10.0 * delta)
        if not is_on_floor():
            velocity.y -= GRAVITY * delta
        move_and_slide()
        return
    since_damage += delta
    if since_damage > 6.0 and health < 50.0:
        health = minf(50.0, health + 4.0 * delta)
        health_changed.emit(health, max_health)
    var input := Vector2.ZERO
    var jump: bool = false
    if controls != null:
        input = controls.move_vec
        jump = controls.consume("jump")
    input += Vector2(float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)), float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
    input = input.limit_length(1.0)
    if Input.is_key_pressed(KEY_SPACE):
        jump = true
    var want_crouch: bool = (controls != null and controls.crouch_on) or Input.is_key_pressed(KEY_CTRL) or Input.is_key_pressed(KEY_C)
    if not want_crouch and crouch_t > 0.01 and not _can_stand():
        want_crouch = true
    crouch_t = move_toward(crouch_t, 1.0 if want_crouch else 0.0, delta * 8.0)
    if collision_cap != null:
        collision_cap.height = lerpf(1.8, 1.0, crouch_t)
        collision_cs.position.y = lerpf(0.9, 0.5, crouch_t)
    var dir: Vector3 = global_transform.basis * Vector3(input.x, 0.0, input.y)
    var speed: float = WALK_SPEED * lerpf(1.0, 0.55, crouch_t)
    if weapons.aiming:
        speed *= 0.62
    var accel: float = 14.0 if is_on_floor() else 4.0
    velocity.x = lerpf(velocity.x, dir.x * speed, minf(1.0, accel * delta))
    velocity.z = lerpf(velocity.z, dir.z * speed, minf(1.0, accel * delta))
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    elif jump:
        velocity.y = JUMP_VELOCITY
    move_and_slide()
    var hs: float = Vector2(velocity.x, velocity.z).length()
    if is_on_floor() and hs > 1.0:
        step_acc += hs * delta
        if step_acc > 2.3:
            step_acc = 0.0
            SFX.play("step", -9.0, randf_range(0.9, 1.1))


func kick(amount: float, burst_idx: int = 0) -> void:
    var b: float = float(clampi(burst_idx, 0, 14))
    var v: float = amount * (0.5 + b * 0.07)
    var h_mag: float = amount * (0.22 + minf(b, 8.0) * 0.035)
    var h_dir: float = sin(b * 1.7) * 0.6 + randf_range(-0.5, 0.5)
    pitch += v
    recoil_offset += amount * 0.65
    rotate_y(h_dir * h_mag)

func is_crouching() -> bool:
    return crouch_t > 0.5

func _can_stand() -> bool:
    if collision_cap == null:
        return true
    var space := get_world_3d().direct_space_state
    var shape := CapsuleShape3D.new()
    shape.radius = 0.4
    shape.height = 1.8
    var q := PhysicsShapeQueryParameters3D.new()
    q.shape = shape
    q.transform = Transform3D(Basis.IDENTITY, global_position + Vector3(0, 0.9, 0))
    q.collision_mask = 1
    q.exclude = [get_rid()]
    return space.intersect_shape(q, 1).is_empty()

func _apply_auto_aim(delta: float) -> void:
    if camera == null:
        return
    var enemies: Array = get_tree().get_nodes_in_group("enemies")
    if enemies.is_empty():
        return
    var cam_pos: Vector3 = camera.global_position
    var fwd: Vector3 = -camera.global_transform.basis.z
    var best: Node3D = null
    var best_angle: float = 0.32
    for e in enemies:
        var en: Node3D = e
        if not is_instance_valid(en):
            continue
        var tgt: Vector3 = en.global_position + Vector3(0, 1.25, 0)
        var d: Vector3 = tgt - cam_pos
        var dist: float = d.length()
        if dist < 1.0 or dist > 80.0:
            continue
        var ang: float = fwd.angle_to(d.normalized())
        if ang < best_angle:
            best_angle = ang
            best = en
    if best == null:
        return
    var tgt2: Vector3 = best.global_position + Vector3(0, 1.25, 0)
    var desired: Vector3 = (tgt2 - cam_pos).normalized()
    var yaw_tgt: float = atan2(-desired.x, -desired.z)
    var yaw_cur: float = atan2(-fwd.x, -fwd.z)
    var dyaw: float = wrapf(yaw_tgt - yaw_cur, -PI, PI)
    var pitch_tgt: float = asin(clampf(desired.y, -0.999, 0.999))
    var pitch_cur: float = asin(clampf(fwd.y, -0.999, 0.999))
    var dpitch: float = pitch_tgt - pitch_cur
    var strength: float = minf(1.0, 7.0 * delta)
    var max_rot: float = 0.05
    rotate_y(clampf(dyaw * strength, -max_rot, max_rot))
    pitch = clampf(pitch + clampf(dpitch * strength, -max_rot, max_rot), -1.45, 1.45)


func take_damage(amount: float, from: Vector3 = Vector3.ZERO) -> void:
    if not alive:
        return
    health = maxf(0.0, health - amount)
    since_damage = 0.0
    SFX.play("hurt", -4.0)
    damaged.emit(amount)
    health_changed.emit(health, max_health)
    if health <= 0.0:
        _die()


func heal(amount: float) -> void:
    health = minf(max_health, health + amount)
    health_changed.emit(health, max_health)


func _die() -> void:
    alive = false
    died.emit()
    var tw := create_tween()
    tw.set_parallel(true)
    tw.tween_property(head, "rotation:z", 0.9, 0.7)
    tw.tween_property(head, "position:y", 0.4, 0.7)
