# Operation: Dead Zone

FPS 3D single-player untuk Android (ARM64), dibuat dengan **Godot 4.3** (GDScript, renderer *Mobile*).
Satu misi lengkap di kota industri terbengkalai **Vesper**. Semua aset (tekstur, model, suara, musik) dibuat
secara prosedural lewat kode, jadi tidak ada file aset eksternal dan tidak ada masalah lisensi.

## Cara mengunggah ke GitHub dan membangun APK

1. Buat repository baru di GitHub (kosong).
2. Ekstrak `OperationDeadZone.zip`. Unggah **isi folder `OperationDeadZone/`** (bukan folder pembungkusnya)
   ke root repository, termasuk folder tersembunyi `.github`.
   - Lewat web: *Add file -> Upload files*, seret semua isi folder. Pastikan `.github/workflows/android-build.yml` ikut.
     (Jika folder tersembunyi tidak terlihat di file manager, aktifkan "tampilkan file tersembunyi".)
   - Lewat git: `git init && git add -A && git commit -m "Operation Dead Zone" && git branch -M main && git remote add origin <URL> && git push -u origin main`.
3. Push ke branch `main`/`master` otomatis menjalankan workflow. Manual: tab **Actions -> Build Android APK -> Run workflow**.
4. Setelah hijau (sekitar 10-20 menit pertama kali), buka run tersebut -> bagian **Artifacts** ->
   unduh **OperationDeadZone-APK** (zip berisi `OperationDeadZone.apk`). Ekstrak, kirim ke HP, install
   (izinkan "pasang dari sumber tidak dikenal").
5. Jika build gagal, unduh artifact **build-logs** (`import.log`, `smoke.log`, `export.log`).

APK yang dihasilkan adalah build *debug* yang ditandatangani debug keystore otomatis (dibuat di CI), jadi langsung bisa dipasang.

### Opsi workflow
- `STRICT_SMOKE: "true"` (di `android-build.yml`): job gagal bila uji asap menemukan error script.
  Ubah ke `"false"` jika hanya ingin APK walau ada peringatan.
- Versi Godot dipatok `4.3-stable` (engine + export template sama). Jangan ubah sebagian saja.

## Cara bermain
- **Joystick kiri**: sentuh di mana saja di sisi kiri layar, geser untuk berjalan.
- **Kamera**: geser jari di sisi kanan (atau geser dari tombol TEMBAK sambil menembak).
- Tombol: TEMBAK, BIDIK (toggle), ISI (reload), LOMPAT, GANTI (senjata), II (pause).
- Senjata: AR-7 Karabin (otomatis), P9 Pistol, S12 Shotgun.
- Misi: (1) habisi musuh di alun-alun -> checkpoint 1, (2) masuk gudang pabrik dan berdiri dekat generator
  6 detik -> checkpoint 2 + bala bantuan, (3) capai helikopter ekstraksi.
- Pickup hijau/putih (HP) dan olive (amunisi) tersebar di peta dan kadang dijatuhkan musuh.
- Tombol Back Android / keluar dari aplikasi membuka menu jeda.

## Grafis
| Preset | Bayangan | Efek | Tekstur | Lainnya |
|---|---|---|---|---|
| Smooth | mati | tanpa glow, lampu flash mati | 64px | resolusi 3D 75%, tanpa debu |
| Medium | 2 split, 40 m | fog sedang | 128px | resolusi 90%, debu 60 partikel |
| Max | 4 split, 90 m, atlas 4096 | glow/bloom, fog tebal | 256px | MSAA 2x, debu 160 partikel |

Bayangan/efek berubah langsung saat preset diganti; ukuran tekstur berlaku saat misi dimulai ulang.

## Struktur
```
project.godot, export_presets.cfg, icon.svg
.github/workflows/android-build.yml
scenes/    main (menu), player, enemies, levels (vesper), weapons, ui
scripts/   player, enemies, gameplay (level, map, misi, audio, tekstur, efek), weapons, ui
assets/    kosong (semua aset dibuat prosedural)
```

## Catatan jujur
- Proyek ini ditulis tanpa bisa menjalankan Godot di lingkungan pembuatnya, jadi belum pernah dijalankan di engine.
  Workflow menyertakan uji asap headless (muat menu, bangun level, tembak, selesaikan misi) untuk menangkap error
  script di CI. Jika ada error, kirim `smoke.log` agar bisa diperbaiki.
- Ragdoll fisika belum ada: musuh mati dengan animasi jatuh (tween).
- Navigasi musuh memakai steering + raycast (tanpa navmesh), jadi tidak sepintar pathfinding penuh.
