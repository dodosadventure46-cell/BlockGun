extends RefCounted
## Tekstur & material prosedural (dibuat dengan operasi Image native, cepat).

static var _cache: Dictionary = {}


static func material(kind: String, size: int, tint: Color = Color(1, 1, 1), uv: float = 0.25, metallic: float = 0.0, rough: float = 0.9) -> StandardMaterial3D:
    var key: String = "m_%s_%d_%s_%.2f_%.2f_%.2f" % [kind, size, tint.to_html(), uv, metallic, rough]
    if _cache.has(key):
        return _cache[key]
    var m := StandardMaterial3D.new()
    m.albedo_texture = _texture(kind, size)
    m.albedo_color = tint
    m.uv1_triplanar = true
    m.uv1_world_triplanar = true
    m.uv1_scale = Vector3(uv, uv, uv)
    m.metallic = metallic
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    if size >= 128:
        # PBR: peta roughness (kualitas sedang ke atas), normal map (kualitas tinggi ke atas)
        m.roughness = 1.0
        m.roughness_texture = _rough_texture(kind, size, rough)
        m.roughness_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_RED
    else:
        m.roughness = rough
    if size >= 256:
        m.normal_enabled = true
        m.normal_texture = _normal_texture(kind, size)
        m.normal_scale = 0.9
    _cache[key] = m
    return m


static func flat(color: Color, rough: float = 0.8, emission: float = 0.0, metallic: float = 0.0) -> StandardMaterial3D:
    var key: String = "f_%s_%.2f_%.2f_%.2f" % [color.to_html(), rough, emission, metallic]
    if _cache.has(key):
        return _cache[key]
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    m.metallic = metallic
    if emission > 0.0:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = emission
    _cache[key] = m
    return m


static func _texture(kind: String, size: int) -> ImageTexture:
    var ck: String = "t_%s_%d" % [kind, size]
    if _cache.has(ck):
        return _cache[ck]
    var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
    match kind:
        "concrete":
            _paint_concrete(img)
        "brick":
            _paint_brick(img)
        "asphalt":
            _paint_asphalt(img)
        "metal":
            _paint_metal(img)
        "rust":
            _paint_rust(img)
        "wood":
            _paint_wood(img)
        "plaster":
            _paint_plaster(img)
        _:
            img.fill(Color(0.5, 0.5, 0.5, 1.0))
    img.generate_mipmaps()
    var tex := ImageTexture.create_from_image(img)
    _cache[ck] = tex
    return tex


static func _noise(img: Image, cells: int, alpha: float, seed_v: int) -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_v
    var n := Image.create(cells, cells, false, Image.FORMAT_RGBA8)
    for y in cells:
        for x in cells:
            var g: float = rng.randf()
            n.set_pixel(x, y, Color(g, g, g, alpha * absf(g - 0.5) * 2.0))
    n.resize(img.get_width(), img.get_height(), Image.INTERPOLATE_BILINEAR)
    img.blend_rect(n, Rect2i(0, 0, img.get_width(), img.get_height()), Vector2i.ZERO)


static func _stain(img: Image, cells: int, color: Color, alpha: float, seed_v: int, thr: float) -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_v
    var n := Image.create(cells, cells, false, Image.FORMAT_RGBA8)
    for y in cells:
        for x in cells:
            var g: float = rng.randf()
            var a: float = maxf(0.0, g - thr) / (1.0 - thr) * alpha
            n.set_pixel(x, y, Color(color.r, color.g, color.b, a))
    n.resize(img.get_width(), img.get_height(), Image.INTERPOLATE_BILINEAR)
    img.blend_rect(n, Rect2i(0, 0, img.get_width(), img.get_height()), Vector2i.ZERO)


static func _paint_concrete(img: Image) -> void:
    var s: int = img.get_width()
    img.fill(Color(0.5, 0.5, 0.48, 1.0))
    _noise(img, 6, 0.35, 1)
    _noise(img, 24, 0.25, 2)
    _noise(img, 64, 0.15, 3)
    var seam := Color(0.33, 0.33, 0.32, 1.0)
    img.fill_rect(Rect2i(0, 0, s, 2), seam)
    img.fill_rect(Rect2i(0, s / 2, s, 2), seam)
    img.fill_rect(Rect2i(0, 0, 2, s), seam)
    img.fill_rect(Rect2i(s / 2, 0, 2, s), seam)
    _stain(img, 10, Color(0.12, 0.11, 0.1, 1.0), 0.5, 4, 0.6)


static func _paint_brick(img: Image) -> void:
    var s: int = img.get_width()
    var rng := RandomNumberGenerator.new()
    rng.seed = 11
    img.fill(Color(0.56, 0.54, 0.5, 1.0))
    var rows: int = 8
    var bh: int = s / rows
    var bw: int = s / 4
    for r in rows:
        var off: int = (bw / 2) if r % 2 == 1 else 0
        for c in range(-1, 5):
            var v: float = rng.randf_range(0.75, 1.15)
            img.fill_rect(Rect2i(c * bw + off + 1, r * bh + 1, bw - 2, bh - 2), Color(0.55 * v, 0.24 * v, 0.17 * v, 1.0))
    _noise(img, 8, 0.3, 5)
    _noise(img, 40, 0.3, 6)
    _stain(img, 12, Color(0.08, 0.07, 0.06, 1.0), 0.55, 7, 0.55)


static func _paint_asphalt(img: Image) -> void:
    var s: int = img.get_width()
    var rng := RandomNumberGenerator.new()
    rng.seed = 21
    img.fill(Color(0.16, 0.16, 0.17, 1.0))
    _noise(img, 8, 0.4, 8)
    _noise(img, 48, 0.5, 9)
    _noise(img, 96, 0.35, 10)
    for i in 6:
        img.fill_rect(Rect2i(rng.randi_range(0, s - 1), rng.randi_range(0, s - 1), rng.randi_range(s / 6, s / 3), 1), Color(0.05, 0.05, 0.05, 1.0))


static func _paint_metal(img: Image) -> void:
    var s: int = img.get_width()
    img.fill(Color(0.36, 0.4, 0.42, 1.0))
    var step: int = maxi(1, s / 8)
    for i in range(0, s, step):
        img.fill_rect(Rect2i(i, 0, maxi(1, step / 2), s), Color(0.46, 0.5, 0.52, 1.0))
    _noise(img, 10, 0.3, 12)
    _stain(img, 14, Color(0.45, 0.22, 0.1, 1.0), 0.65, 13, 0.55)


static func _paint_rust(img: Image) -> void:
    img.fill(Color(0.52, 0.26, 0.14, 1.0))
    _noise(img, 6, 0.45, 14)
    _noise(img, 30, 0.4, 15)
    _stain(img, 12, Color(0.12, 0.06, 0.04, 1.0), 0.6, 16, 0.5)


static func _paint_wood(img: Image) -> void:
    var s: int = img.get_width()
    var rng := RandomNumberGenerator.new()
    rng.seed = 31
    img.fill(Color(0.2, 0.12, 0.06, 1.0))
    var rows: int = 6
    var ph: int = s / rows
    for r in rows:
        var v: float = rng.randf_range(0.8, 1.2)
        img.fill_rect(Rect2i(0, r * ph + 1, s, ph - 2), Color(0.45 * v, 0.3 * v, 0.16 * v, 1.0))
    _noise(img, 6, 0.3, 17)
    _noise(img, 64, 0.25, 18)


static func _paint_plaster(img: Image) -> void:
    img.fill(Color(0.72, 0.68, 0.6, 1.0))
    _noise(img, 6, 0.3, 19)
    _noise(img, 32, 0.2, 20)
    _stain(img, 8, Color(0.2, 0.17, 0.13, 1.0), 0.6, 22, 0.55)


# ---------------------------------------------------------------- PBR
static func _rough_texture(kind: String, size: int, base: float) -> ImageTexture:
    var ck: String = "r_%s_%d_%.2f" % [kind, size, base]
    if _cache.has(ck):
        return _cache[ck]
    var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
    img.fill(Color(base, base, base, 1.0))
    _noise(img, 8, 0.35, 51)
    _noise(img, 40, 0.3, 52)
    if kind == "metal" or kind == "rust":
        _stain(img, 14, Color(0.95, 0.95, 0.95, 1.0), 0.6, 53, 0.5)
    img.generate_mipmaps()
    var tex := ImageTexture.create_from_image(img)
    _cache[ck] = tex
    return tex


static func _height_image(kind: String, size: int) -> Image:
    var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
    var s: int = size
    match kind:
        "brick":
            var rng := RandomNumberGenerator.new()
            rng.seed = 11
            img.fill(Color(0.1, 0.1, 0.1, 1.0))
            var rows: int = 8
            var bh: int = s / rows
            var bw: int = s / 4
            for r in rows:
                var off: int = (bw / 2) if r % 2 == 1 else 0
                for c in range(-1, 5):
                    var v: float = rng.randf_range(0.6, 0.85)
                    img.fill_rect(Rect2i(c * bw + off + 1, r * bh + 1, bw - 2, bh - 2), Color(v, v, v, 1.0))
            _noise(img, 40, 0.5, 61)
        "metal":
            img.fill(Color(0.3, 0.3, 0.3, 1.0))
            var step: int = maxi(1, s / 8)
            for i in range(0, s, step):
                img.fill_rect(Rect2i(i, 0, maxi(1, step / 2), s), Color(0.85, 0.85, 0.85, 1.0))
            _noise(img, 30, 0.2, 62)
        "wood":
            img.fill(Color(0.1, 0.1, 0.1, 1.0))
            var rows2: int = 6
            var ph: int = s / rows2
            for r2 in rows2:
                img.fill_rect(Rect2i(0, r2 * ph + 1, s, ph - 2), Color(0.7, 0.7, 0.7, 1.0))
            _noise(img, 64, 0.5, 63)
        "asphalt":
            img.fill(Color(0.5, 0.5, 0.5, 1.0))
            _noise(img, 48, 0.9, 64)
            _noise(img, 96, 0.8, 65)
        _:
            img.fill(Color(0.5, 0.5, 0.5, 1.0))
            _noise(img, 6, 0.5, 66)
            _noise(img, 32, 0.5, 67)
            _noise(img, 96, 0.4, 68)
    return img


static func _normal_texture(kind: String, size: int) -> ImageTexture:
    var ck: String = "n_%s_%d" % [kind, size]
    if _cache.has(ck):
        return _cache[ck]
    var img: Image = _height_image(kind, size)
    var strength: float = 4.0
    if kind == "brick" or kind == "asphalt":
        strength = 7.0
    img.bump_map_to_normal_map(strength)
    img.generate_mipmaps()
    var tex := ImageTexture.create_from_image(img)
    _cache[ck] = tex
    return tex


# ---------------------------------------------------------------- decal (retak, noda, hangus)
static func decal_texture(kind: String) -> ImageTexture:
    var ck: String = "d_" + kind
    if _cache.has(ck):
        return _cache[ck]
    var n: int = 128
    var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    var rng := RandomNumberGenerator.new()
    rng.seed = 77 + kind.length() * 13
    if kind == "crack":
        for branch in 4:
            var p := Vector2(n * 0.5, n * 0.5)
            var ang: float = rng.randf_range(0.0, TAU)
            for step in 60:
                ang += rng.randf_range(-0.5, 0.5)
                p += Vector2(cos(ang), sin(ang)) * 1.8
                if p.x < 2 or p.y < 2 or p.x > n - 3 or p.y > n - 3:
                    break
                var fade: float = 1.0 - float(step) / 60.0
                img.fill_rect(Rect2i(int(p.x), int(p.y), 2, 2), Color(0.03, 0.03, 0.03, 0.85 * fade))
    else:
        var tint := Color(0.05, 0.04, 0.03)
        var amp: float = 0.55
        if kind == "scorch":
            tint = Color(0.02, 0.02, 0.02)
            amp = 0.8
        for y in n:
            for x in n:
                var d: float = Vector2(x - n * 0.5, y - n * 0.5).length() / (n * 0.5)
                var a: float = clampf(1.0 - d, 0.0, 1.0)
                a = a * a * (0.45 + 0.55 * rng.randf()) * amp
                if a > 0.01:
                    img.set_pixel(x, y, Color(tint.r, tint.g, tint.b, a))
    var tex := ImageTexture.create_from_image(img)
    _cache[ck] = tex
    return tex
