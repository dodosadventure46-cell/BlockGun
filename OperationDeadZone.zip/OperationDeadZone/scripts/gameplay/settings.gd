extends Node
## Pengaturan lokal + progres. Disimpan di user://settings.cfg

signal changed

const SAVE_PATH := "user://settings.cfg"
const GRAPHICS_NAMES := ["Smooth", "Medium", "Max"]
const GRAPHICS_DESC := [
    "Bayangan mati, efek minimal, render ringan (resolusi 3D 75%).",
    "Bayangan terbatas, efek sedang, tekstur menengah.",
    "Bayangan detail, tekstur tajam, bloom, partikel atmosfer."
]

var sensitivity: float = 1.0
var master_volume: float = 0.8
var music_on: bool = true
var auto_aim: bool = false
var graphics: int = 1
var checkpoint: int = 0
var missions_completed: int = 0
var best_time: float = 0.0


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    load_settings()


func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    sensitivity = float(cfg.get_value("input", "sensitivity", 1.0))
    auto_aim = bool(cfg.get_value("input", "auto_aim", false))
    master_volume = float(cfg.get_value("audio", "master_volume", 0.8))
    music_on = bool(cfg.get_value("audio", "music_on", true))
    graphics = clampi(int(cfg.get_value("graphics", "preset", 1)), 0, 2)
    checkpoint = clampi(int(cfg.get_value("progress", "checkpoint", 0)), 0, 2)
    missions_completed = int(cfg.get_value("progress", "missions_completed", 0))
    best_time = float(cfg.get_value("progress", "best_time", 0.0))


func save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("input", "sensitivity", sensitivity)
    cfg.set_value("input", "auto_aim", auto_aim)
    cfg.set_value("audio", "master_volume", master_volume)
    cfg.set_value("audio", "music_on", music_on)
    cfg.set_value("graphics", "preset", graphics)
    cfg.set_value("progress", "checkpoint", checkpoint)
    cfg.set_value("progress", "missions_completed", missions_completed)
    cfg.set_value("progress", "best_time", best_time)
    cfg.save(SAVE_PATH)
    apply_audio()
    changed.emit()


func apply_audio() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.0001)))
    var mi: int = AudioServer.get_bus_index("Music")
    if mi >= 0:
        AudioServer.set_bus_mute(mi, not music_on)


func texture_size() -> int:
    return [64, 128, 256][clampi(graphics, 0, 2)]


func view_distance() -> float:
    return [55.0, 90.0, 150.0][clampi(graphics, 0, 2)]


func dust_amount() -> int:
    return [0, 60, 160][clampi(graphics, 0, 2)]


func apply_graphics(vp: Viewport, sun: DirectionalLight3D, env: Environment) -> void:
    var g: int = clampi(graphics, 0, 2)
    if g == 0:
        vp.msaa_3d = Viewport.MSAA_DISABLED
        vp.scaling_3d_scale = 0.75
        sun.shadow_enabled = false
        RenderingServer.directional_shadow_atlas_set_size(1024, true)
        env.glow_enabled = false
        env.fog_density = 0.008
    elif g == 1:
        vp.msaa_3d = Viewport.MSAA_DISABLED
        vp.scaling_3d_scale = 0.9
        sun.shadow_enabled = true
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
        sun.directional_shadow_max_distance = 40.0
        RenderingServer.directional_shadow_atlas_set_size(2048, true)
        env.glow_enabled = false
        env.fog_density = 0.011
    else:
        vp.msaa_3d = Viewport.MSAA_2X
        vp.scaling_3d_scale = 1.0
        sun.shadow_enabled = true
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
        sun.directional_shadow_max_distance = 90.0
        RenderingServer.directional_shadow_atlas_set_size(4096, true)
        env.glow_enabled = true
        env.glow_intensity = 0.7
        env.glow_bloom = 0.04
        env.fog_density = 0.015
