extends Node
## Pengaturan lokal + progres + sistem grafis (preset Smooth/Medium/High/Ultra + pengaturan terpisah).

signal changed

const SAVE_PATH := "user://settings.cfg"
const PRESET_NAMES := ["Smooth", "Medium", "High", "Ultra"]
const PRESET_DESC := [
    "Tanpa bayangan, efek minimal, render 70%, tekstur 64px.",
    "Bayangan sederhana, efek rendah, tekstur 128px + roughness.",
    "Bayangan dinamis baik, tekstur 256px + normal map, FXAA.",
    "Bayangan terbaik, tekstur 512px PBR, MSAA 2x, bloom, efek penuh."
]
const SHADOW_NAMES := ["Mati", "Sederhana", "Baik", "Terbaik"]
const TEX_NAMES := ["Rendah 64px", "Sedang 128px", "Tinggi 256px", "Ultra 512px"]
const FX_NAMES := ["Minimal", "Rendah", "Sedang", "Tinggi"]
const VIEW_NAMES := ["Dekat 45 m", "Sedang 70 m", "Jauh 110 m", "Terjauh 170 m"]
const AA_NAMES := ["Mati", "FXAA", "MSAA 2x", "MSAA 4x"]
const FPS_OPTIONS := [30, 45, 60]
const FPS_NAMES := ["30 FPS", "45 FPS", "60 FPS"]
# scale, shadow, texture, effects, view, aa, adaptive
const PRESETS := [
    {"scale": 0.7, "shadow": 0, "texture": 0, "effects": 0, "view": 0, "aa": 0, "adaptive": true},
    {"scale": 0.85, "shadow": 1, "texture": 1, "effects": 1, "view": 1, "aa": 0, "adaptive": true},
    {"scale": 1.0, "shadow": 2, "texture": 2, "effects": 2, "view": 2, "aa": 1, "adaptive": false},
    {"scale": 1.0, "shadow": 3, "texture": 3, "effects": 3, "view": 3, "aa": 2, "adaptive": false}
]

var sensitivity: float = 1.0
var master_volume: float = 0.8
var music_on: bool = true
var preset: int = 1            # -1 = kustom
var render_scale: float = 0.85
var shadow_q: int = 1
var texture_q: int = 1
var effects_q: int = 1
var view_q: int = 1
var aa: int = 0
var motion_blur: bool = false
var vsync: bool = true
var adaptive: bool = true
var target_fps: int = 60
var checkpoint: int = 0
var missions_completed: int = 0
var best_time: float = 0.0

var fps_idx: int:
    get:
        return maxi(0, FPS_OPTIONS.find(target_fps))
    set(v):
        target_fps = FPS_OPTIONS[clampi(v, 0, 2)]


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    load_settings()
    apply_display()


func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    sensitivity = float(cfg.get_value("input", "sensitivity", 1.0))
    master_volume = float(cfg.get_value("audio", "master_volume", 0.8))
    music_on = bool(cfg.get_value("audio", "music_on", true))
    preset = clampi(int(cfg.get_value("graphics", "preset", 1)), -1, 3)
    render_scale = clampf(float(cfg.get_value("graphics", "render_scale", 0.85)), 0.5, 1.0)
    shadow_q = clampi(int(cfg.get_value("graphics", "shadow", 1)), 0, 3)
    texture_q = clampi(int(cfg.get_value("graphics", "texture", 1)), 0, 3)
    effects_q = clampi(int(cfg.get_value("graphics", "effects", 1)), 0, 3)
    view_q = clampi(int(cfg.get_value("graphics", "view", 1)), 0, 3)
    aa = clampi(int(cfg.get_value("graphics", "aa", 0)), 0, 3)
    motion_blur = bool(cfg.get_value("graphics", "motion_blur", false))
    vsync = bool(cfg.get_value("graphics", "vsync", true))
    adaptive = bool(cfg.get_value("graphics", "adaptive", true))
    target_fps = int(cfg.get_value("graphics", "target_fps", 60))
    if not FPS_OPTIONS.has(target_fps):
        target_fps = 60
    checkpoint = clampi(int(cfg.get_value("progress", "checkpoint", 0)), 0, 2)
    missions_completed = int(cfg.get_value("progress", "missions_completed", 0))
    best_time = float(cfg.get_value("progress", "best_time", 0.0))


func save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("input", "sensitivity", sensitivity)
    cfg.set_value("audio", "master_volume", master_volume)
    cfg.set_value("audio", "music_on", music_on)
    cfg.set_value("graphics", "preset", preset)
    cfg.set_value("graphics", "render_scale", render_scale)
    cfg.set_value("graphics", "shadow", shadow_q)
    cfg.set_value("graphics", "texture", texture_q)
    cfg.set_value("graphics", "effects", effects_q)
    cfg.set_value("graphics", "view", view_q)
    cfg.set_value("graphics", "aa", aa)
    cfg.set_value("graphics", "motion_blur", motion_blur)
    cfg.set_value("graphics", "vsync", vsync)
    cfg.set_value("graphics", "adaptive", adaptive)
    cfg.set_value("graphics", "target_fps", target_fps)
    cfg.set_value("progress", "checkpoint", checkpoint)
    cfg.set_value("progress", "missions_completed", missions_completed)
    cfg.set_value("progress", "best_time", best_time)
    cfg.save(SAVE_PATH)
    apply_audio()
    apply_display()
    changed.emit()


func apply_preset(i: int) -> void:
    var idx: int = clampi(i, 0, 3)
    var p: Dictionary = PRESETS[idx]
    preset = idx
    render_scale = float(p["scale"])
    shadow_q = int(p["shadow"])
    texture_q = int(p["texture"])
    effects_q = int(p["effects"])
    view_q = int(p["view"])
    aa = int(p["aa"])
    adaptive = bool(p["adaptive"])
    save_settings()


func apply_audio() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.0001)))
    var mi: int = AudioServer.get_bus_index("Music")
    if mi >= 0:
        AudioServer.set_bus_mute(mi, not music_on)


func apply_display() -> void:
    Engine.max_fps = target_fps
    if vsync:
        DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
    else:
        DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)


func texture_size() -> int:
    return [64, 128, 256, 512][clampi(texture_q, 0, 3)]


func view_distance() -> float:
    return [45.0, 70.0, 110.0, 170.0][clampi(view_q, 0, 3)]


func dust_amount() -> int:
    return [0, 50, 100, 160][clampi(effects_q, 0, 3)]


func decal_count() -> int:
    return [0, 16, 36, 60][clampi(effects_q, 0, 3)]


func smoke_enabled() -> bool:
    return effects_q >= 2


func casings_enabled() -> bool:
    return effects_q >= 1


func muzzle_light_enabled() -> bool:
    return effects_q >= 1


func particle_scale() -> float:
    return [0.5, 0.8, 1.0, 1.3][clampi(effects_q, 0, 3)]


## Menerapkan parameter rendering nyata ke viewport, matahari, dan environment.
func apply_graphics(vp: Viewport, sun: DirectionalLight3D, env: Environment) -> void:
    vp.scaling_3d_scale = clampf(render_scale, 0.5, 1.0)
    if aa >= 2:
        vp.msaa_3d = Viewport.MSAA_4X if aa == 3 else Viewport.MSAA_2X
    else:
        vp.msaa_3d = Viewport.MSAA_DISABLED
    if aa == 1:
        vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
    else:
        vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
    if shadow_q <= 0:
        sun.shadow_enabled = false
    else:
        sun.shadow_enabled = true
        if shadow_q == 1:
            sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
            sun.directional_shadow_max_distance = 35.0
            RenderingServer.directional_shadow_atlas_set_size(1024, true)
        elif shadow_q == 2:
            sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
            sun.directional_shadow_max_distance = 60.0
            RenderingServer.directional_shadow_atlas_set_size(2048, true)
        else:
            sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
            sun.directional_shadow_max_distance = 90.0
            RenderingServer.directional_shadow_atlas_set_size(4096, true)
        sun.directional_shadow_blend_splits = shadow_q >= 2
    env.glow_enabled = effects_q >= 3
    env.glow_intensity = 0.6
    env.glow_bloom = 0.03
    env.fog_density = [0.014, 0.012, 0.010, 0.0085][clampi(view_q, 0, 3)]
    env.adjustment_enabled = effects_q >= 1
    env.adjustment_contrast = 1.08
    env.adjustment_saturation = 0.94
