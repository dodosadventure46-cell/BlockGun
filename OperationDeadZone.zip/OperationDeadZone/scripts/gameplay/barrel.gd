extends StaticBody3D
## Tong merah yang meledak saat ditembak: damage area ke musuh, pemain, dan tong di dekatnya.

const Fx := preload("res://scripts/gameplay/fx.gd")

var health: float = 40.0
var exploded: bool = false


func _ready() -> void:
    add_to_group("barrels")


func take_damage(amount: float, headshot: bool = false, from: Vector3 = Vector3.ZERO) -> void:
    if exploded:
        return
    health -= amount
    if health <= 0.0:
        _explode()


func _explode() -> void:
    exploded = true
    var pos: Vector3 = global_position + Vector3(0, 0.6, 0)
    var radius: float = 6.0
    Fx.explosion(get_parent(), pos)
    SFX.play_at("explosion", pos, 3.0)
    for e in get_tree().get_nodes_in_group("enemies"):
        var en = e
        var d: float = en.global_position.distance_to(global_position)
        if d < radius:
            en.take_damage(140.0 * (1.0 - d / radius), false, global_position)
    var pl = get_tree().get_first_node_in_group("player")
    if pl != null and pl.alive:
        var dp: float = pl.global_position.distance_to(global_position)
        if dp < radius:
            pl.take_damage(55.0 * (1.0 - dp / radius), global_position)
    for b in get_tree().get_nodes_in_group("barrels"):
        var bb = b
        if bb != self and not bb.exploded and bb.global_position.distance_to(global_position) < 4.0:
            bb.call_deferred("take_damage", 60.0)
    # tempel noda hangus di tanah
    var dec := Decal.new()
    dec.size = Vector3(4.0, 2.0, 4.0)
    dec.texture_albedo = preload("res://scripts/gameplay/texlib.gd").decal_texture("scorch")
    get_parent().add_child(dec)
    dec.global_position = Vector3(global_position.x, 1.0, global_position.z)
    queue_free()
