extends Node
## Audio prosedural: semua suara dibuat lewat kode (tanpa file eksternal).

const RATE := 22050
const LOW_RATE := 11025

var sounds: Dictionary = {}
var pool2d: Array = []
var pool3d: Array = []
var i2d: int = 0
var i3d: int = 0
var music_player: AudioStreamPlayer
var amb_player: AudioStreamPlayer
var music_stream: AudioStreamWAV = null
var amb_stream: AudioStreamWAV = null


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    randomize()
    if AudioServer.get_bus_index("Music") == -1:
        AudioServer.add_bus()
        var idx: int = AudioServer.bus_count - 1
        AudioServer.set_bus_name(idx, "Music")
        AudioServer.set_bus_send(idx, "Master")
    for i in 10:
        var p := AudioStreamPlayer.new()
        add_child(p)
        pool2d.append(p)
    for i in 16:
        var p3 := AudioStreamPlayer3D.new()
        p3.unit_size = 10.0
        p3.max_distance = 140.0
        add_child(p3)
        pool3d.append(p3)
    music_player = AudioStreamPlayer.new()
    music_player.bus = "Music"
    add_child(music_player)
    amb_player = AudioStreamPlayer.new()
    amb_player.volume_db = -9.0
    add_child(amb_player)
    _build_sounds()
    Settings.apply_audio()


func _to_wav(d: PackedFloat32Array, loop: bool = false, rate: int = RATE) -> AudioStreamWAV:
    var bytes := PackedByteArray()
    bytes.resize(d.size() * 2)
    for i in d.size():
        bytes.encode_s16(i * 2, int(clampf(d[i], -1.0, 1.0) * 32767.0))
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = bytes
    if loop:
        w.loop_mode = AudioStreamWAV.LOOP_FORWARD
        w.loop_begin = 0
        w.loop_end = d.size()
    return w


func _burst(dur: float, decay: float, lp: float, hz: float, hz_amp: float, hz_decay: float, amp: float) -> AudioStreamWAV:
    var n: int = int(dur * RATE)
    var d := PackedFloat32Array()
    d.resize(n)
    var y: float = 0.0
    for i in n:
        var t: float = float(i) / float(RATE)
        y += ((randf() * 2.0 - 1.0) - y) * lp
        d[i] = (y * exp(-t * decay) + sin(TAU * hz * t) * exp(-t * hz_decay) * hz_amp) * amp
    return _to_wav(d)


func _tone(dur: float, f0: float, f1: float, decay: float, amp: float) -> AudioStreamWAV:
    var n: int = int(dur * RATE)
    var d := PackedFloat32Array()
    d.resize(n)
    var ph: float = 0.0
    for i in n:
        var t: float = float(i) / float(RATE)
        ph += TAU * lerpf(f0, f1, t / dur) / float(RATE)
        d[i] = sin(ph) * exp(-t * decay) * amp
    return _to_wav(d)


func _clicks(events: Array, dur: float) -> AudioStreamWAV:
    var n: int = int(dur * RATE)
    var d := PackedFloat32Array()
    d.resize(n)
    for e in events:
        var s0: int = int(float(e[0]) * RATE)
        var f: float = float(e[1])
        for i in range(int(0.07 * RATE)):
            if s0 + i >= n:
                break
            var t: float = float(i) / float(RATE)
            d[s0 + i] += ((randf() * 2.0 - 1.0) * 0.5 + sin(TAU * f * t) * 0.5) * exp(-t * 60.0) * 0.8
    return _to_wav(d)


func _build_sounds() -> void:
    sounds["shot_rifle"] = _burst(0.30, 20.0, 0.5, 85.0, 0.9, 25.0, 0.95)
    sounds["shot_pistol"] = _burst(0.22, 28.0, 0.62, 130.0, 0.7, 35.0, 0.9)
    sounds["shot_shotgun"] = _burst(0.5, 11.0, 0.35, 60.0, 1.0, 14.0, 1.0)
    sounds["shot_enemy"] = _burst(0.26, 22.0, 0.42, 100.0, 0.8, 28.0, 0.8)
    sounds["step"] = _burst(0.16, 28.0, 0.18, 70.0, 0.5, 30.0, 0.7)
    sounds["impact"] = _burst(0.14, 34.0, 0.8, 300.0, 0.2, 40.0, 0.55)
    sounds["death"] = _burst(0.45, 9.0, 0.12, 62.0, 0.9, 7.0, 0.9)
    sounds["explosion"] = _burst(1.0, 5.0, 0.12, 48.0, 1.0, 5.0, 1.0)
    sounds["hurt"] = _tone(0.28, 220.0, 120.0, 14.0, 0.7)
    sounds["hit"] = _tone(0.07, 1700.0, 1700.0, 45.0, 0.5)
    sounds["empty"] = _tone(0.05, 1200.0, 900.0, 60.0, 0.4)
    sounds["pickup"] = _tone(0.3, 600.0, 1200.0, 7.0, 0.5)
    sounds["ui_click"] = _tone(0.06, 900.0, 700.0, 50.0, 0.4)
    sounds["reload"] = _clicks([[0.12, 900.0], [0.85, 600.0], [1.35, 1300.0]], 1.8)
    sounds["switch"] = _clicks([[0.05, 700.0], [0.3, 1100.0]], 0.5)
    # sirene alarm (2,4 detik)
    var n: int = int(2.4 * RATE)
    var d := PackedFloat32Array()
    d.resize(n)
    var ph: float = 0.0
    for i in n:
        var t: float = float(i) / float(RATE)
        var f: float = 620.0 if int(t / 0.6) % 2 == 0 else 830.0
        ph += TAU * f / float(RATE)
        d[i] = sin(ph) * 0.3 * clampf(2.4 - t, 0.0, 1.0)
    sounds["alarm"] = _to_wav(d)


func _make_music() -> AudioStreamWAV:
    var seg: float = 3.0
    var chords: Array = [
        [110.0, 164.81, 220.0, 261.63],
        [87.31, 130.81, 174.61, 220.0],
        [98.0, 146.83, 196.0, 246.94],
        [82.41, 123.47, 164.81, 196.0]
    ]
    var n: int = int(seg * 4.0 * LOW_RATE)
    var d := PackedFloat32Array()
    d.resize(n)
    for i in n:
        var t: float = float(i) / float(LOW_RATE)
        var ci: int = int(t / seg) % 4
        var local: float = fmod(t, seg)
        var env: float = pow(sin(PI * local / seg), 2.0)
        var v: float = 0.0
        for f in chords[ci]:
            v += sin(TAU * float(f) * t)
        v *= 0.07 * env * (0.8 + 0.2 * sin(TAU * 0.25 * t))
        var bp: float = fmod(t, 1.5)
        v += sin(TAU * 55.0 * t) * exp(-bp * 4.0) * 0.22
        d[i] = v
    return _to_wav(d, true, LOW_RATE)


func _make_ambience() -> AudioStreamWAV:
    var n: int = int(3.0 * LOW_RATE)
    var d := PackedFloat32Array()
    d.resize(n)
    var y: float = 0.0
    for i in n:
        var t: float = float(i) / float(LOW_RATE)
        y += ((randf() * 2.0 - 1.0) - y) * 0.06
        var gust: float = 0.55 + 0.45 * sin(TAU * t / 3.0)
        d[i] = y * 0.9 * gust + sin(TAU * 55.0 * t) * 0.05
    return _to_wav(d, true, LOW_RATE)


func play_music() -> void:
    if music_stream == null:
        music_stream = _make_music()
    music_player.stream = music_stream
    music_player.volume_db = -4.0
    music_player.play()


func stop_music() -> void:
    music_player.stop()


func play_ambience() -> void:
    if amb_stream == null:
        amb_stream = _make_ambience()
    amb_player.stream = amb_stream
    amb_player.play()


func stop_ambience() -> void:
    amb_player.stop()


func play(sound: String, vol_db: float = 0.0, pitch: float = 1.0) -> void:
    if not sounds.has(sound):
        return
    var p: AudioStreamPlayer = pool2d[i2d]
    i2d = (i2d + 1) % pool2d.size()
    p.stream = sounds[sound]
    p.volume_db = vol_db
    p.pitch_scale = pitch
    p.play()


func play_at(sound: String, pos: Vector3, vol_db: float = 0.0, pitch: float = 1.0) -> void:
    if not sounds.has(sound):
        return
    var p: AudioStreamPlayer3D = pool3d[i3d]
    i3d = (i3d + 1) % pool3d.size()
    p.stream = sounds[sound]
    p.global_position = pos
    p.volume_db = vol_db
    p.pitch_scale = pitch
    p.play()
