extends Node
## Alur permainan global: pindah scene, checkpoint, uji asap CI.

const LEVEL_PATH := "res://scenes/levels/vesper.tscn"
const MENU_PATH := "res://scenes/main/main_menu.tscn"

var checkpoint: int = 0
var cp_data: Dictionary = {}
var smoke: bool = false


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    if "--smoke" in OS.get_cmdline_user_args():
        smoke = true
        _smoke_test()


func new_mission() -> void:
    checkpoint = 0
    cp_data = {}
    Settings.checkpoint = 0
    Settings.save_settings()
    _load(LEVEL_PATH)


func continue_mission() -> void:
    checkpoint = Settings.checkpoint
    cp_data = {}
    _load(LEVEL_PATH)


func retry_checkpoint() -> void:
    _load(LEVEL_PATH)


func go_menu() -> void:
    _load(MENU_PATH)


func _load(path: String) -> void:
    get_tree().paused = false
    get_tree().change_scene_to_file(path)


func _smoke_test() -> void:
    print("SMOKE: start")
    await get_tree().create_timer(1.5).timeout
    checkpoint = 0
    _load(LEVEL_PATH)
    await get_tree().create_timer(10.0).timeout
    print("SMOKE: ok")
    get_tree().quit(0)
