extends Node
## Mesin objektif misi: bersihkan alun-alun -> aktifkan generator -> ekstraksi helikopter.

signal objective_changed(text: String, pos: Vector3)
signal checkpoint_reached(index: int)
signal mission_complete
signal reinforcements_requested

const OBJ_POS := [Vector3(0, 0, -30), Vector3(-44, 0, -84), Vector3(50, 0, -88)]
const GEN_TIME := 6.0
const GEN_RADIUS := 5.5
const EXTRACT_RADIUS := 6.5

var player = null
var hud = null
var obj: int = 0
var alive_count: Dictionary = {0: 0, 1: 0, 2: 0}
var gen_progress: float = 0.0
var done: bool = false


func start(p: Node3D, h: Node, index: int) -> void:
    player = p
    hud = h
    obj = index
    _announce(true)


func register_enemy(phase: int) -> void:
    alive_count[phase] = int(alive_count[phase]) + 1


func enemy_killed(phase: int) -> void:
    alive_count[phase] = maxi(0, int(alive_count[phase]) - 1)
    if obj == 0 and phase == 0:
        _announce(false)


func _announce(move_marker: bool) -> void:
    var t: String = ""
    var idx: int = mini(obj, 2)
    if obj == 0:
        t = "Habisi semua musuh di Alun-alun Vesper (%d tersisa)" % int(alive_count[0])
    elif obj == 1:
        t = "Masuki gudang pabrik dan aktifkan generator (berdiri di dekatnya)"
    else:
        t = "Menuju titik ekstraksi helikopter"
    objective_changed.emit(t, OBJ_POS[idx])


func _advance() -> void:
    obj += 1
    if obj == 1:
        checkpoint_reached.emit(1)
    elif obj == 2:
        checkpoint_reached.emit(2)
        reinforcements_requested.emit()
    _announce(true)


func debug_complete() -> void:
    done = true
    mission_complete.emit()


func _process(delta: float) -> void:
    if done or player == null or not player.alive:
        return
    var pp: Vector3 = player.global_position
    if obj == 0:
        if int(alive_count[0]) <= 0:
            _advance()
    elif obj == 1:
        var g: Vector3 = OBJ_POS[1]
        var d: float = Vector2(pp.x - g.x, pp.z - g.z).length()
        if d < GEN_RADIUS:
            gen_progress += delta
            hud.set_progress(gen_progress / GEN_TIME)
            if gen_progress >= GEN_TIME:
                hud.set_progress(-1.0)
                _advance()
        else:
            gen_progress = maxf(0.0, gen_progress - delta * 0.5)
            if gen_progress > 0.0:
                hud.set_progress(gen_progress / GEN_TIME)
            else:
                hud.set_progress(-1.0)
    elif obj == 2:
        var e: Vector3 = OBJ_POS[2]
        if Vector2(pp.x - e.x, pp.z - e.z).length() < EXTRACT_RADIUS:
            done = true
            mission_complete.emit()
    var tgt: Vector3 = OBJ_POS[mini(obj, 2)]
    hud.set_distance(Vector2(pp.x - tgt.x, pp.z - tgt.z).length())
