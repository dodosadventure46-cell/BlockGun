extends Node
## Resolusi adaptif: menurunkan render scale bila FPS di bawah target, menaikkannya lagi saat stabil.

var vp: Viewport = null
var scale_now: float = 1.0
var acc: float = 0.0
var frames: int = 0
var warmup: float = 4.0


func setup(viewport: Viewport) -> void:
    vp = viewport
    reset()


func reset() -> void:
    scale_now = Settings.render_scale
    acc = 0.0
    frames = 0
    if vp != null:
        vp.scaling_3d_scale = scale_now


func _process(delta: float) -> void:
    if vp == null:
        return
    if not Settings.adaptive:
        if absf(vp.scaling_3d_scale - Settings.render_scale) > 0.001:
            vp.scaling_3d_scale = Settings.render_scale
        return
    if warmup > 0.0:
        warmup -= delta
        return
    acc += delta
    frames += 1
    if acc < 1.5:
        return
    var fps: float = float(frames) / acc
    acc = 0.0
    frames = 0
    var target: float = float(Settings.target_fps)
    var floor_scale: float = maxf(0.5, Settings.render_scale * 0.7)
    if fps < target * 0.85 and scale_now > floor_scale:
        scale_now = maxf(floor_scale, scale_now - 0.05)
    elif fps > target * 0.97 and scale_now < Settings.render_scale:
        scale_now = minf(Settings.render_scale, scale_now + 0.025)
    vp.scaling_3d_scale = scale_now
