extends Node3D
## Level Vesper: membangun dunia, memunculkan pemain/musuh/pickup, mengatur alur misi.

const MapBuilder := preload("res://scripts/gameplay/map_builder.gd")
const MissionScript := preload("res://scripts/gameplay/mission.gd")
const PlayerScene := preload("res://scenes/player/player.tscn")
const EnemyScene := preload("res://scenes/enemies/enemy.tscn")
const HudScene := preload("res://scenes/ui/hud.tscn")
const PauseScene := preload("res://scenes/ui/pause_menu.tscn")
const TexLib := preload("res://scripts/gameplay/texlib.gd")
const PerfScript := preload("res://scripts/gameplay/perf.gd")
const MotionBlurScript := preload("res://scripts/ui/motion_blur.gd")

const SPAWN_POINTS := [Vector3(0, 0.1, 58), Vector3(0, 0.1, -46), Vector3(-20, 0.1, -70)]
const SPAWN_YAW := [0.0, 0.0, -90.0]

const ENEMIES := [
    {"phase": 0, "kind": 0, "pos": Vector3(-6, 0.1, -4), "patrol": [Vector3(-6, 0, -4), Vector3(6, 0, -4)]},
    {"phase": 0, "kind": 0, "pos": Vector3(8, 0.1, 6), "patrol": [Vector3(8, 0, 6), Vector3(8, 0, -2)]},
    {"phase": 0, "kind": 0, "pos": Vector3(-18, 0.1, -28), "patrol": [Vector3(-18, 0, -28), Vector3(-8, 0, -20), Vector3(-26, 0, -20)]},
    {"phase": 0, "kind": 0, "pos": Vector3(16, 0.1, -28), "patrol": [Vector3(16, 0, -28), Vector3(24, 0, -22), Vector3(10, 0, -24)]},
    {"phase": 0, "kind": 0, "pos": Vector3(0, 0.1, -42), "patrol": [Vector3(0, 0, -42), Vector3(-12, 0, -44), Vector3(12, 0, -44)]},
    {"phase": 0, "kind": 0, "pos": Vector3(-30, 0.1, -38), "patrol": [Vector3(-30, 0, -38), Vector3(-30, 0, -24)]},
    {"phase": 0, "kind": 0, "pos": Vector3(28, 0.1, -40), "patrol": [Vector3(28, 0, -40), Vector3(28, 0, -26)]},
    {"phase": 0, "kind": 1, "pos": Vector3(4, 0.1, -22), "patrol": [Vector3(4, 0, -22), Vector3(-4, 0, -22)]},
    {"phase": 1, "kind": 0, "pos": Vector3(-30, 0.1, -64), "patrol": [Vector3(-30, 0, -64), Vector3(-30, 0, -71)]},
    {"phase": 1, "kind": 0, "pos": Vector3(-20, 0.1, -72), "patrol": [Vector3(-20, 0, -72), Vector3(-38, 0, -72)]},
    {"phase": 1, "kind": 0, "pos": Vector3(-38, 0.1, -79), "patrol": [Vector3(-38, 0, -79), Vector3(-36, 0, -89)]},
    {"phase": 1, "kind": 0, "pos": Vector3(-15, 2.6, -85), "patrol": []},
    {"phase": 1, "kind": 1, "pos": Vector3(-30, 0.1, -88), "patrol": [Vector3(-30, 0, -88), Vector3(-24, 0, -82)]},
    {"phase": 2, "kind": 0, "pos": Vector3(20, 0.1, -70), "patrol": [Vector3(20, 0, -70), Vector3(34, 0, -70)]},
    {"phase": 2, "kind": 0, "pos": Vector3(34, 0.1, -80), "patrol": [Vector3(34, 0, -80), Vector3(22, 0, -80)]},
    {"phase": 2, "kind": 0, "pos": Vector3(46, 0.1, -70), "patrol": [Vector3(46, 0, -70), Vector3(56, 0, -72)]},
    {"phase": 2, "kind": 1, "pos": Vector3(54, 0.1, -82), "patrol": []},
    {"phase": 2, "kind": 0, "pos": Vector3(46, 0.1, -94), "patrol": [Vector3(46, 0, -94), Vector3(58, 0, -95)]}
]

const PICKUPS := [
    ["health", Vector3(0, 0, 30)], ["ammo", Vector3(10, 0, 38)], ["health", Vector3(-2, 0, 6)],
    ["ammo", Vector3(4, 0, -6)], ["ammo", Vector3(-26, 0, -18)], ["health", Vector3(-30, 0, -50)],
    ["health", Vector3(-28, 0, -62)], ["ammo", Vector3(-36, 0, -70)], ["health", Vector3(-18, 0, -70)],
    ["ammo", Vector3(8, 0, -62)], ["health", Vector3(26, 0, -79)], ["ammo", Vector3(44, 0, -76)]
]

var player = null
var hud = null
var pause = null
var mission = null
var sun: DirectionalLight3D
var env: Environment
var builder
var loading: CanvasLayer
var marker: MeshInstance3D
var pickups: Array = []
var kills: int = 0
var elapsed: float = 0.0
var ended: bool = false
var drop_toggle: bool = false
var perf = null
var motion = null


func _ready() -> void:
    get_tree().paused = false
    SFX.stop_music()
    _show_loading()
    await get_tree().process_frame
    await get_tree().process_frame
    _setup_environment()
    builder = MapBuilder.new(self, Settings.texture_size(), Settings.view_distance())
    builder.build_all()
    _spawn_player()
    _setup_ui()
    _setup_marker()
    mission = MissionScript.new()
    add_child(mission)
    mission.objective_changed.connect(_on_objective)
    mission.checkpoint_reached.connect(_on_checkpoint)
    mission.mission_complete.connect(_on_complete)
    mission.reinforcements_requested.connect(_on_reinforcements)
    var cp: int = Game.checkpoint
    if cp == 0:
        _spawn_phase(0, false)
        _spawn_phase(1, false)
    elif cp == 1:
        _spawn_phase(1, false)
    else:
        _spawn_phase(2, false)
        builder.activate_generator()
    for p in PICKUPS:
        _spawn_pickup(p[0], p[1])
    mission.start(player, hud, cp)
    perf = PerfScript.new()
    add_child(perf)
    perf.setup(get_viewport())
    _on_gfx_changed()
    SFX.play_ambience()
    loading.queue_free()
    hud.show_message("OPERASI DEAD ZONE - KOTA VESPER", 3.5)
    if Game.smoke:
        _run_smoke()


func _show_loading() -> void:
    loading = CanvasLayer.new()
    loading.layer = 50
    var bg := ColorRect.new()
    bg.color = Color(0.03, 0.03, 0.04)
    bg.anchor_right = 1.0
    bg.anchor_bottom = 1.0
    loading.add_child(bg)
    var l := Label.new()
    l.text = "MEMUAT KOTA VESPER..."
    l.add_theme_font_size_override("font_size", 40)
    l.anchor_left = 0.5
    l.anchor_right = 0.5
    l.anchor_top = 0.5
    l.anchor_bottom = 0.5
    l.offset_left = -300
    l.offset_right = 300
    l.offset_top = -30
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    loading.add_child(l)
    add_child(loading)


func _setup_environment() -> void:
    env = Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.16, 0.2, 0.3)
    sm.sky_horizon_color = Color(0.85, 0.55, 0.35)
    sm.ground_horizon_color = Color(0.6, 0.4, 0.3)
    sm.ground_bottom_color = Color(0.1, 0.1, 0.12)
    sky.sky_material = sm
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.85
    env.fog_sun_scatter = 0.2
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color(0.55, 0.48, 0.42)
    env.fog_density = 0.011
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-28, -35, 0)
    sun.light_color = Color(1.0, 0.78, 0.55)
    sun.light_energy = 1.35
    sun.shadow_normal_bias = 1.5
    sun.directional_shadow_fade_start = 0.8
    add_child(sun)


func _spawn_player() -> void:
    player = PlayerScene.instantiate()
    add_child(player)
    var cp: int = clampi(Game.checkpoint, 0, 2)
    player.global_position = SPAWN_POINTS[cp]
    player.rotation_degrees.y = SPAWN_YAW[cp]
    if cp > 0 and Game.cp_data.has("health"):
        player.health = maxf(50.0, float(Game.cp_data["health"]))
        player.weapons.restore(Game.cp_data["weapons"])
    player.died.connect(_on_player_died)
    player.damaged.connect(func(a): hud.flash_damage())
    player.weapons.hit_confirmed.connect(func(head, kill):
        hud.hitmarker(head, kill))


func _setup_ui() -> void:
    hud = HudScene.instantiate()
    add_child(hud)
    hud.bind(player)
    player.controls = hud.controls
    hud.pause_requested.connect(_open_pause)
    pause = PauseScene.instantiate()
    add_child(pause)
    pause.resume_pressed.connect(_resume)
    pause.checkpoint_pressed.connect(func(): Game.retry_checkpoint())
    pause.restart_pressed.connect(_restart_mission)
    pause.menu_pressed.connect(func(): Game.go_menu())
    pause.settings_changed.connect(_on_gfx_changed)
    motion = MotionBlurScript.new()
    add_child(motion)


## Menerapkan seluruh pengaturan grafis/efek secara langsung (tekstur berlaku saat misi dimulai ulang).
func _on_gfx_changed() -> void:
    if sun == null or env == null:
        return
    Settings.apply_graphics(get_viewport(), sun, env)
    if perf != null:
        perf.reset()
    if player != null:
        player.camera.far = Settings.view_distance() + 25.0
        player.apply_effects()
    if builder != null:
        builder.apply_view_distance(Settings.view_distance())
        builder.apply_quality()


func _setup_marker() -> void:
    marker = MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.8
    cm.bottom_radius = 0.8
    cm.height = 60.0
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    mat.albedo_color = Color(1.0, 0.55, 0.1, 0.25)
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    cm.material = mat
    marker.mesh = cm
    marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(marker)


func _spawn_phase(phase: int, alerted: bool) -> void:
    for def in ENEMIES:
        if int(def["phase"]) != phase:
            continue
        var e = EnemyScene.instantiate()
        e.setup(phase, int(def["kind"]), def["patrol"])
        add_child(e)
        e.global_position = def["pos"]
        e.killed.connect(_on_enemy_killed)
        mission.register_enemy(phase)
        if alerted:
            e.alert_to(player.global_position)


func _spawn_pickup(kind: String, pos: Vector3) -> void:
    var a := Area3D.new()
    a.collision_layer = 0
    a.collision_mask = 2
    a.position = Vector3(pos.x, 0.0, pos.z)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(1.5, 1.8, 1.5)
    cs.shape = bs
    cs.position = Vector3(0, 0.9, 0)
    a.add_child(cs)
    var vis := Node3D.new()
    vis.name = "Vis"
    vis.position = Vector3(0, 0.7, 0)
    a.add_child(vis)
    var body := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.7, 0.45, 0.5)
    body.mesh = bm
    var col: Color = Color(0.9, 0.9, 0.9) if kind == "health" else Color(0.25, 0.3, 0.18)
    body.material_override = TexLib.flat(col, 0.6, 0.4)
    vis.add_child(body)
    var mark := MeshInstance3D.new()
    var mm := BoxMesh.new()
    mm.size = Vector3(0.5, 0.05, 0.14) if kind == "health" else Vector3(0.5, 0.05, 0.1)
    mark.mesh = mm
    mark.position = Vector3(0, 0.24, 0)
    mark.material_override = TexLib.flat(Color(0.9, 0.1, 0.1) if kind == "health" else Color(0.95, 0.75, 0.1), 0.5, 1.5)
    vis.add_child(mark)
    if kind == "health":
        var mark2 := MeshInstance3D.new()
        var mm2 := BoxMesh.new()
        mm2.size = Vector3(0.14, 0.05, 0.4)
        mark2.mesh = mm2
        mark2.position = Vector3(0, 0.24, 0)
        mark2.material_override = TexLib.flat(Color(0.9, 0.1, 0.1), 0.5, 1.5)
        vis.add_child(mark2)
    a.body_entered.connect(_on_pickup.bind(a, kind))
    add_child.call_deferred(a)
    pickups.append(a)


func _on_pickup(body: Node, area: Area3D, kind: String) -> void:
    if body != player or not player.alive:
        return
    if kind == "health":
        if player.health >= player.max_health:
            return
        player.heal(45.0)
        hud.show_message("+45 HP", 1.5)
    else:
        player.weapons.add_ammo()
        hud.show_message("+AMUNISI", 1.5)
    SFX.play("pickup", -3.0)
    pickups.erase(area)
    area.queue_free()


func _on_enemy_killed(e) -> void:
    kills += 1
    mission.enemy_killed(e.phase)
    if randf() < 0.28:
        drop_toggle = not drop_toggle
        _spawn_pickup("ammo" if drop_toggle else "health", e.global_position)


func _on_reinforcements() -> void:
    builder.activate_generator()
    SFX.play("alarm", -3.0)
    hud.show_message("GENERATOR AKTIF! BALA BANTUAN MUSUH TIBA - MENUJU EKSTRAKSI", 4.0)
    _spawn_phase(2, true)


func _on_objective(text: String, pos: Vector3) -> void:
    hud.set_objective(text)
    marker.global_position = pos + Vector3(0, 30, 0)


func _on_checkpoint(index: int) -> void:
    Game.checkpoint = index
    Game.cp_data = {"health": player.health, "weapons": player.weapons.snapshot()}
    Settings.checkpoint = index
    Settings.save_settings()
    hud.show_message("CHECKPOINT TERSIMPAN", 2.5)
    SFX.play("pickup", -2.0)


func _on_player_died() -> void:
    hud.show_message("KAMU GUGUR", 2.0)
    await get_tree().create_timer(1.6).timeout
    if ended:
        return
    ended = true
    get_tree().paused = true
    pause.show_end(false, "Musuh dihabisi: %d" % kills)


func _on_complete() -> void:
    if ended:
        return
    ended = true
    Settings.missions_completed += 1
    if Settings.best_time <= 0.0 or elapsed < Settings.best_time:
        Settings.best_time = elapsed
    Settings.checkpoint = 0
    Settings.save_settings()
    Game.checkpoint = 0
    Game.cp_data = {}
    SFX.play("pickup", 0.0)
    get_tree().paused = true
    var t: int = int(elapsed)
    pause.show_end(true, "Waktu: %d:%02d   Musuh dihabisi: %d" % [t / 60, t % 60, kills])


func _open_pause() -> void:
    if ended or not player.alive:
        return
    get_tree().paused = true
    pause.show_pause()


func _resume() -> void:
    pause.hide_all()
    get_tree().paused = false
    hud.controls.reset()


func _restart_mission() -> void:
    Game.checkpoint = 0
    Game.cp_data = {}
    Settings.checkpoint = 0
    Settings.save_settings()
    Game.retry_checkpoint()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        if player != null and hud != null and pause != null and not get_tree().paused:
            _open_pause()


func _process(delta: float) -> void:
    if player == null:
        return
    if not ended:
        elapsed += delta
    if builder != null and builder.heli_rotor != null:
        builder.heli_rotor.rotate_y(delta * 14.0)
    for a in pickups:
        if is_instance_valid(a) and a.is_inside_tree():
            var v: Node3D = a.get_node_or_null("Vis")
            if v != null:
                v.rotation.y += delta * 1.6
                v.position.y = 0.7 + sin(elapsed * 2.5) * 0.08
    if marker != null:
        marker.visible = not ended
    if motion != null:
        motion.update_blur(player.look_delta, delta)


func _run_smoke() -> void:
    await get_tree().create_timer(1.0).timeout
    print("SMOKE: senjata + animasi")
    player.weapons.smoke_test()
    await get_tree().create_timer(0.5).timeout
    print("SMOKE: preset grafis")
    var saved: Array = [Settings.preset, Settings.render_scale, Settings.shadow_q, Settings.texture_q, Settings.effects_q, Settings.view_q, Settings.aa, Settings.adaptive]
    for pi in 4:
        Settings.apply_preset(pi)
        _on_gfx_changed()
        await get_tree().process_frame
    Settings.motion_blur = true
    await get_tree().create_timer(0.3).timeout
    Settings.motion_blur = false
    Settings.preset = saved[0]
    Settings.render_scale = saved[1]
    Settings.shadow_q = saved[2]
    Settings.texture_q = saved[3]
    Settings.effects_q = saved[4]
    Settings.view_q = saved[5]
    Settings.aa = saved[6]
    Settings.adaptive = saved[7]
    Settings.save_settings()
    _on_gfx_changed()
    print("SMOKE: ledakan tong")
    var bs: Array = get_tree().get_nodes_in_group("barrels")
    if bs.size() > 0:
        var bb = bs[0]
        bb.take_damage(999.0)
    await get_tree().create_timer(0.5).timeout
    print("SMOKE: musuh")
    for e in get_tree().get_nodes_in_group("enemies"):
        var en = e
        if en.phase == 0:
            en.take_damage(999.0, true, player.global_position)
    await get_tree().create_timer(1.5).timeout
    print("SMOKE: misi")
    mission.debug_complete()
