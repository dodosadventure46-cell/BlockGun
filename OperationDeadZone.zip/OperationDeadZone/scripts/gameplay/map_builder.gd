extends RefCounted
## Pembangun peta kota Vesper (prosedural): jalan, bangunan, alun-alun, gudang, halaman kontainer, helipad.

const TexLib := preload("res://scripts/gameplay/texlib.gd")
const Fx := preload("res://scripts/gameplay/fx.gd")
const BarrelScript := preload("res://scripts/gameplay/barrel.gd")

var root: Node3D
var tex: int = 128
var view_dist: float = 100.0
var m: Dictionary = {}
var heli_rotor: Node3D = null
var gen_mat: StandardMaterial3D = null
var rng := RandomNumberGenerator.new()
var vis_meshes: Array = []     # mesh besar: jarak render penuh
var small_meshes: Array = []   # mesh kecil (LOD): hilang lebih awal
var decals: Array = []
var smoke_cols: Array = []
var smoke_built: bool = false


func _init(r: Node3D, tex_size: int, vdist: float) -> void:
    root = r
    tex = tex_size
    view_dist = vdist
    rng.seed = 20261020


# ---------------------------------------------------------------- material
func _materials() -> void:
    m["concrete"] = TexLib.material("concrete", tex, Color(1, 1, 1), 0.3)
    m["concrete_dark"] = TexLib.material("concrete", tex, Color(0.62, 0.62, 0.65), 0.3)
    m["brick"] = TexLib.material("brick", tex, Color(1, 1, 1), 0.5)
    m["plaster"] = TexLib.material("plaster", tex, Color(0.95, 0.9, 0.8), 0.3)
    m["asphalt"] = TexLib.material("asphalt", tex, Color(1, 1, 1), 0.25)
    m["metal"] = TexLib.material("metal", tex, Color(1, 1, 1), 0.35, 0.2, 0.6)
    m["metal_wall"] = TexLib.material("metal", tex, Color(0.8, 0.85, 0.85), 0.3, 0.2, 0.6)
    m["rust"] = TexLib.material("rust", tex, Color(1, 1, 1), 0.4)
    m["wood"] = TexLib.material("wood", tex, Color(1, 1, 1), 0.7)
    m["roof"] = TexLib.material("concrete", tex, Color(0.4, 0.4, 0.42), 0.3)
    m["c_red"] = TexLib.material("metal", tex, Color(0.75, 0.25, 0.18), 0.35, 0.2, 0.6)
    m["c_blue"] = TexLib.material("metal", tex, Color(0.2, 0.35, 0.62), 0.35, 0.2, 0.6)
    m["c_green"] = TexLib.material("metal", tex, Color(0.2, 0.5, 0.3), 0.35, 0.2, 0.6)
    m["c_yellow"] = TexLib.material("metal", tex, Color(0.8, 0.65, 0.15), 0.35, 0.2, 0.6)
    m["c_gray"] = TexLib.material("metal", tex, Color(0.5, 0.52, 0.55), 0.35, 0.2, 0.6)
    m["dark"] = TexLib.flat(Color(0.05, 0.05, 0.06), 0.9)
    m["steel_hub"] = TexLib.flat(Color(0.35, 0.36, 0.38), 0.4, 0.0, 0.9)
    m["glass"] = TexLib.flat(Color(0.08, 0.12, 0.17), 0.2, 0.0, 0.3)
    m["white"] = TexLib.flat(Color(0.85, 0.85, 0.8), 0.9)
    m["yellow"] = TexLib.flat(Color(0.9, 0.7, 0.1), 0.8)
    m["barrel"] = TexLib.flat(Color(0.65, 0.12, 0.08), 0.5, 0.0, 0.4)
    m["lamp"] = TexLib.flat(Color(1.0, 0.8, 0.5), 0.5, 3.0)
    m["heli"] = TexLib.flat(Color(0.2, 0.24, 0.18), 0.6, 0.0, 0.3)
    gen_mat = TexLib.flat(Color(0.95, 0.12, 0.05), 0.5, 3.0)
    gen_mat = gen_mat.duplicate() as StandardMaterial3D
    m["gen"] = TexLib.flat(Color(0.75, 0.6, 0.12), 0.6, 0.0, 0.3)


# ---------------------------------------------------------------- primitif
func _mesh_box(size: Vector3, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO, shadow: bool = true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat
    mi.position = pos
    mi.rotation_degrees = rot
    if not shadow:
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _register(mi, size.x * size.y * size.z < 4.0)
    return mi


## LOD sederhana: objek kecil hilang di setengah jarak pandang, objek besar di jarak penuh.
func _register(mi: MeshInstance3D, small: bool) -> void:
    if small:
        small_meshes.append(mi)
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        mi.visibility_range_end = view_dist * 0.5
    else:
        vis_meshes.append(mi)
        mi.visibility_range_end = view_dist


func apply_view_distance(vd: float) -> void:
    view_dist = vd
    for mi in vis_meshes:
        if is_instance_valid(mi):
            mi.visibility_range_end = vd
    for mj in small_meshes:
        if is_instance_valid(mj):
            mj.visibility_range_end = vd * 0.5


func _mesh_cyl(radius: float, height: float, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = height
    cm.radial_segments = 14
    mi.mesh = cm
    mi.material_override = mat
    mi.position = pos
    mi.rotation_degrees = rot
    _register(mi, radius * radius * height < 1.5)
    return mi


func _col_box(size: Vector3, pos: Vector3) -> CollisionShape3D:
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = size
    cs.shape = bs
    cs.position = pos
    return cs


func box(pos: Vector3, size: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO, collide: bool = true) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.position = pos
    body.rotation_degrees = rot
    body.collision_layer = 1
    body.collision_mask = 0
    body.add_child(_mesh_box(size, Vector3.ZERO, mat))
    if collide:
        body.add_child(_col_box(size, Vector3.ZERO))
    root.add_child(body)
    return body


func deco(pos: Vector3, size: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> void:
    var mi: MeshInstance3D = _mesh_box(size, pos, mat, rot, false)
    root.add_child(mi)


func cyl(pos: Vector3, radius: float, height: float, mat: Material, collide: bool = true) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.collision_layer = 1
    body.collision_mask = 0
    body.add_child(_mesh_cyl(radius, height, Vector3.ZERO, mat))
    if collide:
        var cs := CollisionShape3D.new()
        var sh := CylinderShape3D.new()
        sh.radius = radius
        sh.height = height
        cs.shape = sh
        body.add_child(cs)
    root.add_child(body)


func add_light(pos: Vector3, color: Color, energy: float, rng_m: float) -> void:
    var l := OmniLight3D.new()
    l.position = pos
    l.light_color = color
    l.light_energy = energy
    l.omni_range = rng_m
    l.shadow_enabled = false
    root.add_child(l)


func add_cover(pos: Vector3) -> void:
    var n := Node3D.new()
    n.position = Vector3(pos.x, 0.0, pos.z)
    root.add_child(n)
    n.add_to_group("cover")


func prop_cover(x: float, z: float, sx: float, sz: float, rot_deg: float = 0.0) -> void:
    for off in [Vector3(sx * 0.5 + 1.0, 0, 0), Vector3(-sx * 0.5 - 1.0, 0, 0), Vector3(0, 0, sz * 0.5 + 1.0), Vector3(0, 0, -sz * 0.5 - 1.0)]:
        var o: Vector3 = off.rotated(Vector3.UP, deg_to_rad(rot_deg))
        add_cover(Vector3(x + o.x, 0.0, z + o.z))


# ---------------------------------------------------------------- dinding
func _seg(axis_x: bool, a0: float, a1: float, fixed: float, y0: float, y1: float, th: float, mat: Material) -> void:
    var seg_len: float = a1 - a0
    var mid: float = (a0 + a1) * 0.5
    var hh: float = y1 - y0
    if hh <= 0.01 or seg_len <= 0.01:
        return
    if axis_x:
        box(Vector3(mid, y0 + hh * 0.5, fixed), Vector3(seg_len, hh, th), mat)
    else:
        box(Vector3(fixed, y0 + hh * 0.5, mid), Vector3(th, hh, seg_len), mat)


func _wall(axis_x: bool, a0: float, a1: float, fixed: float, h: float, th: float, openings: Array, mat: Material, y_base: float = 0.0) -> void:
    var ops: Array = openings.duplicate()
    ops.sort_custom(func(p, q): return p.x < q.x)
    var cur: float = a0
    for o in ops:
        var o0: float = o.x - o.y * 0.5
        var o1: float = o.x + o.y * 0.5
        if o0 > cur + 0.01:
            _seg(axis_x, cur, o0, fixed, y_base, y_base + h, th, mat)
        if o.z > 0.0:
            _seg(axis_x, o0, o1, fixed, y_base, y_base + o.z, th, mat)
        if o.w < h:
            _seg(axis_x, o0, o1, fixed, y_base + o.w, y_base + h, th, mat)
        cur = o1
    if a1 > cur + 0.01:
        _seg(axis_x, cur, a1, fixed, y_base, y_base + h, th, mat)


func building(cx: float, cz: float, w: float, d: float, h: float, doors: Array, wall_mat: Material, inner: bool = true) -> void:
    var x0: float = cx - w * 0.5
    var x1: float = cx + w * 0.5
    var z0: float = cz - d * 0.5
    var z1: float = cz + d * 0.5
    var t: float = 0.5
    var ops: Dictionary = {"n": [], "s": [], "e": [], "w": []}
    var door_pts: Array = []
    for dr in doors:
        var side: String = dr[0]
        var off: float = dr[1]
        var along: bool = (side == "n" or side == "s")
        var c: float = (cx if along else cz) + off
        ops[side].append(Vector4(c, 3.6, 0.0, 2.8))
        if side == "n":
            door_pts.append(Vector2(c, z0))
        elif side == "s":
            door_pts.append(Vector2(c, z1))
        elif side == "w":
            door_pts.append(Vector2(x0, c))
        else:
            door_pts.append(Vector2(x1, c))
    # jendela pada sisi yang punya pintu
    for dr in doors:
        var side2: String = dr[0]
        var along2: bool = (side2 == "n" or side2 == "s")
        var a0: float = (x0 if along2 else z0) + 4.0
        var a1: float = (x1 if along2 else z1) - 4.0
        var c2: float = a0
        while c2 <= a1:
            var ok: bool = true
            for o in ops[side2]:
                if absf(o.x - c2) < 4.6:
                    ok = false
            if ok:
                ops[side2].append(Vector4(c2, 1.8, 1.1, 2.5))
                if h >= 9.0:
                    var dpos: Vector3
                    var dsz: Vector3
                    if side2 == "n":
                        dpos = Vector3(c2, h - 3.0, z0 - t * 0.5 - 0.05)
                        dsz = Vector3(1.8, 1.5, 0.1)
                    elif side2 == "s":
                        dpos = Vector3(c2, h - 3.0, z1 + t * 0.5 + 0.05)
                        dsz = Vector3(1.8, 1.5, 0.1)
                    elif side2 == "w":
                        dpos = Vector3(x0 - t * 0.5 - 0.05, h - 3.0, c2)
                        dsz = Vector3(0.1, 1.5, 1.8)
                    else:
                        dpos = Vector3(x1 + t * 0.5 + 0.05, h - 3.0, c2)
                        dsz = Vector3(0.1, 1.5, 1.8)
                    deco(dpos, dsz, m["glass"])
            c2 += 7.0
    _wall(true, x0, x1, z0, h, t, ops["n"], wall_mat)
    _wall(true, x0, x1, z1, h, t, ops["s"], wall_mat)
    _wall(false, z0, z1, x0, h, t, ops["w"], wall_mat)
    _wall(false, z0, z1, x1, h, t, ops["e"], wall_mat)
    box(Vector3(cx, h + 0.25, cz), Vector3(w + 0.6, 0.5, d + 0.6), m["roof"])
    deco(Vector3(cx, 0.02, cz), Vector3(w - 0.6, 0.04, d - 0.6), m["concrete_dark"])
    if not inner:
        return
    var px: float = cx
    var pz: float = cz
    if w >= d:
        px = cx + w * 0.18
        _wall(false, z0 + 0.25, z1 - 0.25, px, h, 0.35, [Vector4(cz + d * 0.2, 3.4, 0.0, 2.7)], wall_mat)
    else:
        pz = cz + d * 0.18
        _wall(true, x0 + 0.25, x1 - 0.25, pz, h, 0.35, [Vector4(cx + w * 0.2, 3.4, 0.0, 2.7)], wall_mat)
    var placed: int = 0
    var tries: int = 0
    while placed < 3 and tries < 30:
        tries += 1
        var cxp: float = rng.randf_range(x0 + 3.0, x1 - 3.0)
        var czp: float = rng.randf_range(z0 + 3.0, z1 - 3.0)
        var good: bool = true
        for dp in door_pts:
            if Vector2(cxp, czp).distance_to(dp) < 6.5:
                good = false
        if w >= d and absf(cxp - px) < 2.5:
            good = false
        if w < d and absf(czp - pz) < 2.5:
            good = false
        if good:
            crate(cxp, czp, 1.3, rng.randf_range(0.0, 90.0), 1 + (placed % 2))
            placed += 1


# ---------------------------------------------------------------- properti
func crate(x: float, z: float, s: float = 1.2, rot: float = 0.0, stack: int = 1) -> void:
    for i in stack:
        box(Vector3(x, s * 0.5 + i * s, z), Vector3(s, s, s), m["wood"], Vector3(0, rot + i * 7.0, 0))
    prop_cover(x, z, s, s, rot)


func barrel(x: float, z: float) -> void:
    var body := StaticBody3D.new()
    body.set_script(BarrelScript)
    body.position = Vector3(x, 0.45, z)
    body.collision_layer = 1
    body.collision_mask = 0
    body.add_child(_mesh_cyl(0.32, 0.9, Vector3.ZERO, m["barrel"]))
    body.add_child(_mesh_cyl(0.325, 0.06, Vector3(0, 0.25, 0), m["dark"]))
    body.add_child(_mesh_cyl(0.325, 0.06, Vector3(0, -0.25, 0), m["dark"]))
    var cs := CollisionShape3D.new()
    var sh := CylinderShape3D.new()
    sh.radius = 0.32
    sh.height = 0.9
    cs.shape = sh
    body.add_child(cs)
    root.add_child(body)
    prop_cover(x, z, 0.6, 0.6)


func barrier(x: float, z: float, rot: float) -> void:
    box(Vector3(x, 0.5, z), Vector3(3.0, 1.0, 0.7), m["concrete"], Vector3(0, rot, 0))
    prop_cover(x, z, 3.0, 0.7, rot)


func wall_chunk(x: float, z: float, w: float, rot: float) -> void:
    box(Vector3(x, 1.2, z), Vector3(w, 2.4, 0.6), m["concrete"], Vector3(0, rot, 0))
    prop_cover(x, z, w, 0.6, rot)


func car(x: float, z: float, rot: float, col: Color) -> void:
    var body := StaticBody3D.new()
    body.position = Vector3(x, 0, z)
    body.rotation_degrees = Vector3(0, rot, 0)
    body.collision_layer = 1
    body.collision_mask = 0
    body.add_child(_mesh_box(Vector3(4.4, 0.8, 1.9), Vector3(0, 0.75, 0), TexLib.flat(col, 0.7)))
    body.add_child(_mesh_box(Vector3(2.3, 0.7, 1.7), Vector3(-0.3, 1.5, 0), m["glass"]))
    for sx in [-1.4, 1.4]:
        for sz in [-0.95, 0.95]:
            body.add_child(_mesh_cyl(0.38, 0.3, Vector3(sx, 0.38, sz), m["dark"], Vector3(90, 0, 0)))
    for sx2 in [-1.4, 1.4]:
        for sz2 in [-0.95, 0.95]:
            body.add_child(_mesh_cyl(0.2, 0.32, Vector3(sx2, 0.38, sz2), m["steel_hub"], Vector3(90, 0, 0)))
    body.add_child(_mesh_box(Vector3(0.12, 0.22, 1.9), Vector3(2.2, 0.45, 0), m["dark"]))
    body.add_child(_mesh_box(Vector3(0.12, 0.22, 1.9), Vector3(-2.2, 0.45, 0), m["dark"]))
    body.add_child(_mesh_box(Vector3(0.06, 0.12, 0.3), Vector3(2.2, 0.8, -0.65), m["lamp"]))
    body.add_child(_mesh_box(Vector3(0.06, 0.12, 0.3), Vector3(2.2, 0.8, 0.65), m["lamp"]))
    body.add_child(_col_box(Vector3(4.4, 1.2, 1.9), Vector3(0, 0.7, 0)))
    body.add_child(_col_box(Vector3(2.3, 0.8, 1.7), Vector3(-0.3, 1.55, 0)))
    root.add_child(body)
    prop_cover(x, z, 4.4, 1.9, rot)


func container(x: float, z: float, rot: float, key: String, stack: int = 1) -> void:
    for i in stack:
        box(Vector3(x, 1.3 + i * 2.6, z), Vector3(10.0, 2.6, 2.6), m[key], Vector3(0, rot, 0))
    prop_cover(x, z, 10.0, 2.6, rot)


func lamp(x: float, z: float) -> void:
    deco(Vector3(x, 3.3, z), Vector3(0.18, 6.6, 0.18), m["dark"])
    deco(Vector3(x + (0.7 if x < 0.0 else -0.7), 6.6, z), Vector3(1.5, 0.12, 0.12), m["dark"])
    deco(Vector3(x + (1.3 if x < 0.0 else -1.3), 6.5, z), Vector3(0.5, 0.15, 0.3), m["lamp"])


# ---------------------------------------------------------------- bangun semua
func build_all() -> void:
    _materials()
    _ground()
    _start_area()
    _avenue()
    _plaza()
    _warehouse()
    _yard()
    _helipad()
    _lights()
    _decals()
    apply_quality()


func _ground() -> void:
    box(Vector3(0, -0.5, -17.5), Vector3(150, 1, 165), m["asphalt"])
    box(Vector3(0, 5, -100.75), Vector3(152, 10, 1.5), m["brick"])
    box(Vector3(0, 5, 65.75), Vector3(152, 10, 1.5), m["brick"])
    box(Vector3(-75.75, 5, -17.5), Vector3(1.5, 10, 167), m["brick"])
    box(Vector3(75.75, 5, -17.5), Vector3(1.5, 10, 167), m["brick"])
    for i in 24:
        deco(Vector3(0, 0.03, 58.0 - i * 3.2), Vector3(0.25, 0.02, 1.6), m["white"])
    deco(Vector3(0, 0.02, -31.5), Vector3(74, 0.04, 37), m["concrete"])
    deco(Vector3(35, 0.02, -78), Vector3(80, 0.04, 45), m["concrete_dark"])
    deco(Vector3(-16.5, 0.02, 18), Vector3(3, 0.04, 90), m["concrete"])
    deco(Vector3(16.5, 0.02, 18), Vector3(3, 0.04, 90), m["concrete"])


func _start_area() -> void:
    barrier(-12, 46, 0)
    barrier(-8.5, 46, 0)
    barrier(8.5, 46, 0)
    barrier(12, 46, 0)
    car(-10, 54, 20, Color(0.3, 0.12, 0.1))
    car(12, 60, -10, Color(0.15, 0.2, 0.28))
    crate(-18, 56, 1.4, 0, 2)
    crate(18, 50, 1.3, 20, 1)
    container(-24, 62, 0, "c_gray", 1)
    lamp(-14, 50)
    lamp(14, 50)


func _avenue() -> void:
    building(-30, 30, 30, 20, 9, [["e", -2.0]], m["brick"])
    building(-30, 2, 30, 24, 12, [["e", 3.0], ["s", -5.0]], m["plaster"])
    building(30, 30, 30, 20, 9, [["w", 2.0]], m["plaster"])
    building(30, 2, 30, 24, 10, [["w", -3.0]], m["brick"])
    building(-50, -30, 26, 40, 11, [["e", 5.0]], m["brick"])
    building(50, -30, 26, 40, 11, [["w", -5.0]], m["plaster"])
    building(-64, -72, 22, 48, 8, [["e", 0.0]], m["concrete"], false)
    car(9, 38, -15, Color(0.25, 0.1, 0.08))
    car(-7, 22, 80, Color(0.2, 0.25, 0.2))
    car(9, 8, 5, Color(0.3, 0.3, 0.32))
    car(-9, -2, 100, Color(0.35, 0.28, 0.1))
    barrier(-3, 30, 20)
    barrier(4, 16, -30)
    crate(-12, 12, 1.3, 15, 2)
    crate(12, -4, 1.3, 0, 1)
    barrel(-12, 36)
    barrel(-11.2, 36.8)
    barrel(13, 24)
    for z in [40, 26, 10, -4]:
        lamp(-13, z)
        lamp(13, z)
    for i in 30:
        var rx: float = rng.randf_range(-14.0, 14.0)
        var rz: float = rng.randf_range(-12.0, 48.0)
        deco(Vector3(rx, 0.12, rz), Vector3(rng.randf_range(0.3, 0.9), 0.24, rng.randf_range(0.3, 0.9)), m["concrete_dark"], Vector3(0, rng.randf_range(0, 90), 0))


func _plaza() -> void:
    cyl(Vector3(0, 0.5, -30), 4.2, 1.0, m["concrete"])
    cyl(Vector3(0, 1.5, -30), 0.9, 3.0, m["concrete_dark"])
    prop_cover(0, -30, 8.4, 8.4)
    car(-24, -33, 30, Color(0.35, 0.1, 0.08))
    car(22, -36, -20, Color(0.2, 0.25, 0.3))
    car(0, -17, 90, Color(0.3, 0.3, 0.25))
    car(-30, -46, 10, Color(0.25, 0.22, 0.12))
    crate(-18, -24, 1.4, 10, 2)
    crate(18, -24, 1.4, -8, 2)
    crate(-10, -41, 1.4, 0, 3)
    crate(10, -41, 1.4, 15, 2)
    crate(-30, -18, 1.2, 0, 1)
    crate(30, -20, 1.2, 40, 1)
    barrier(-8, -15, 0)
    barrier(-4.5, -15, 0)
    barrier(4.5, -15, 0)
    barrier(8, -15, 0)
    barrier(-14, -34, 90)
    barrier(14, -30, 90)
    barrier(-20, -47, 0)
    barrier(20, -47, 0)
    wall_chunk(-6, -26, 5.0, 15)
    wall_chunk(7, -36, 4.0, -20)
    wall_chunk(26, -44, 4.5, 80)
    barrel(-34, -30)
    barrel(-33.3, -29.2)
    barrel(33, -33)
    barrel(0, -46)
    lamp(-20, -20)
    lamp(20, -20)
    lamp(-20, -44)
    lamp(20, -44)
    for i in 26:
        var rx: float = rng.randf_range(-34.0, 34.0)
        var rz: float = rng.randf_range(-48.0, -14.0)
        deco(Vector3(rx, 0.12, rz), Vector3(rng.randf_range(0.3, 1.0), 0.24, rng.randf_range(0.3, 1.0)), m["concrete_dark"], Vector3(0, rng.randf_range(0, 90), 0))


func _warehouse() -> void:
    building(-30, -75, 44, 34, 10, [["s", 0.0], ["e", 9.0]], m["metal_wall"], false)
    crate(-40, -64, 1.5, 0, 2)
    crate(-22, -64, 1.5, 12, 1)
    crate(-26, -68, 1.5, 30, 1)
    box(Vector3(-34, 1.0, -78), Vector3(8, 2.0, 1.2), m["metal"])
    prop_cover(-34, -78, 8, 1.2)
    box(Vector3(-24, 1.0, -78), Vector3(8, 2.0, 1.2), m["metal"])
    prop_cover(-24, -78, 8, 1.2)
    crate(-48, -70, 1.5, 0, 2)
    crate(-46, -76, 1.5, 20, 1)
    crate(-34, -88, 1.5, 0, 2)
    crate(-26, -90, 1.5, 15, 1)
    barrel(-48, -64)
    barrel(-47, -64.8)
    # generator
    box(Vector3(-44, 1.6, -84), Vector3(7, 3.2, 4), m["gen"])
    cyl(Vector3(-46.5, 2.2, -84), 1.1, 4.4, m["metal"])
    cyl(Vector3(-41.8, 2.0, -84), 0.9, 4.0, m["metal"])
    prop_cover(-44, -84, 7, 4)
    deco(Vector3(-44, 1.8, -81.95), Vector3(1.6, 0.8, 0.1), gen_mat)
    # platform + ramp
    box(Vector3(-15, 2.2, -85), Vector3(10, 0.4, 10), m["metal"])
    for px in [-19.5, -10.5]:
        for pz in [-89.5, -80.5]:
            box(Vector3(px, 1.1, pz), Vector3(0.5, 2.2, 0.5), m["dark"])
    box(Vector3(-15, 1.2, -77.5), Vector3(2.6, 0.3, 7.4), m["metal"], Vector3(19, 0, 0))
    # rak platform atas
    deco(Vector3(-15, 2.6, -89.6), Vector3(10, 0.8, 0.1), m["dark"])


func _yard() -> void:
    building(30, -62, 24, 10, 8, [["s", -6.0], ["n", 6.0]], m["concrete"], false)
    container(4, -74, 0, "c_red", 1)
    container(20, -74, 0, "c_blue", 2)
    container(36, -74, 0, "c_green", 1)
    container(12, -84, 0, "c_yellow", 1)
    container(28, -84, 0, "c_gray", 2)
    container(6, -96, 0, "c_blue", 1)
    container(22, -96, 0, "c_red", 1)
    container(34, -96, 0, "c_green", 1)
    container(64, -62, 90, "c_red", 1)
    container(66, -80, 90, "c_yellow", 1)
    crate(0, -60, 1.4, 0, 2)
    crate(14, -62, 1.4, 20, 1)
    barrier(44, -62, 90)
    barrier(46, -76, 0)
    barrel(56, -64)
    barrel(56.8, -64.6)
    barrel(-2, -88)
    wall_chunk(40, -90, 4.0, 30)
    lamp(8, -58)
    lamp(44, -58)
    lamp(40, -82)
    for i in 30:
        var rx: float = rng.randf_range(-2.0, 70.0)
        var rz: float = rng.randf_range(-98.0, -56.0)
        deco(Vector3(rx, 0.12, rz), Vector3(rng.randf_range(0.3, 1.0), 0.24, rng.randf_range(0.3, 1.0)), m["concrete"], Vector3(0, rng.randf_range(0, 90), 0))


func _helipad() -> void:
    var c := Vector3(50, 0, -88)
    var ring := _mesh_cyl(9.0, 0.04, c + Vector3(0, 0.03, 0), m["yellow"])
    root.add_child(ring)
    var inner := _mesh_cyl(8.5, 0.05, c + Vector3(0, 0.04, 0), m["dark"])
    root.add_child(inner)
    deco(c + Vector3(-1.6, 0.07, 0), Vector3(0.7, 0.02, 6.0), m["white"])
    deco(c + Vector3(1.6, 0.07, 0), Vector3(0.7, 0.02, 6.0), m["white"])
    deco(c + Vector3(0, 0.07, 0), Vector3(3.0, 0.02, 0.7), m["white"])
    # helikopter
    var h := StaticBody3D.new()
    h.position = c
    h.collision_layer = 1
    h.collision_mask = 0
    var fus := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 1.5
    sm.height = 3.0
    fus.mesh = sm
    fus.material_override = m["heli"]
    fus.position = Vector3(0, 1.8, 0)
    fus.scale = Vector3(1.0, 0.9, 1.9)
    h.add_child(fus)
    h.add_child(_mesh_box(Vector3(0.4, 0.4, 4.5), Vector3(0, 2.2, 4.5), m["heli"]))
    h.add_child(_mesh_box(Vector3(0.1, 1.2, 0.5), Vector3(0, 2.7, 6.6), m["heli"]))
    h.add_child(_mesh_box(Vector3(0.12, 0.12, 4.2), Vector3(-1.2, 0.3, 0), m["dark"]))
    h.add_child(_mesh_box(Vector3(0.12, 0.12, 4.2), Vector3(1.2, 0.3, 0), m["dark"]))
    h.add_child(_mesh_box(Vector3(0.1, 1.2, 0.1), Vector3(-1.2, 0.9, 0.8), m["dark"]))
    h.add_child(_mesh_box(Vector3(0.1, 1.2, 0.1), Vector3(1.2, 0.9, 0.8), m["dark"]))
    h.add_child(_col_box(Vector3(3.0, 2.8, 5.8), Vector3(0, 1.6, 0.4)))
    heli_rotor = Node3D.new()
    heli_rotor.position = Vector3(0, 3.5, 0)
    heli_rotor.add_child(_mesh_box(Vector3(11.0, 0.05, 0.4), Vector3.ZERO, m["dark"], Vector3.ZERO, false))
    heli_rotor.add_child(_mesh_box(Vector3(0.4, 0.05, 11.0), Vector3.ZERO, m["dark"], Vector3.ZERO, false))
    h.add_child(heli_rotor)
    root.add_child(h)
    prop_cover(50, -88, 3.0, 5.8)


func activate_generator() -> void:
    if gen_mat != null:
        gen_mat.albedo_color = Color(0.1, 1.0, 0.2)
        gen_mat.emission = Color(0.1, 1.0, 0.2)


func _lights() -> void:
    add_light(Vector3(0, 7, 10), Color(1.0, 0.75, 0.5), 1.2, 32.0)
    add_light(Vector3(0, 6, -30), Color(1.0, 0.8, 0.6), 1.2, 34.0)
    add_light(Vector3(-30, 7.5, -70), Color(1.0, 0.9, 0.7), 1.6, 28.0)
    add_light(Vector3(-40, 6, -84), Color(1.0, 0.8, 0.6), 1.4, 22.0)
    add_light(Vector3(30, 6, -80), Color(1.0, 0.8, 0.6), 1.2, 34.0)
    add_light(Vector3(50, 3, -88), Color(0.4, 1.0, 0.5), 1.8, 20.0)


# ---------------------------------------------------------------- dekal & asap
func _decals() -> void:
    var kinds := ["crack", "stain", "scorch", "crack", "stain"]
    var spots: Array = []
    for i in 60:
        var zone: int = i % 3
        var px: float = 0.0
        var pz: float = 0.0
        if zone == 0:
            px = rng.randf_range(-13.0, 13.0)
            pz = rng.randf_range(-10.0, 50.0)
        elif zone == 1:
            px = rng.randf_range(-33.0, 33.0)
            pz = rng.randf_range(-48.0, -14.0)
        else:
            px = rng.randf_range(0.0, 62.0)
            pz = rng.randf_range(-97.0, -58.0)
        spots.append(Vector3(px, 0.0, pz))
    for i2 in spots.size():
        var d := Decal.new()
        var sz: float = rng.randf_range(2.0, 4.5)
        d.size = Vector3(sz, 2.0, sz)
        d.texture_albedo = TexLib.decal_texture(kinds[i2 % kinds.size()])
        d.rotation_degrees = Vector3(0, rng.randf_range(0.0, 360.0), 0)
        d.cull_mask = 1
        d.distance_fade_enabled = true
        d.distance_fade_begin = 28.0
        d.distance_fade_length = 14.0
        d.position = Vector3(spots[i2].x, 1.0, spots[i2].z)
        root.add_child(d)
        decals.append(d)


func _build_smoke() -> void:
    if smoke_built:
        return
    smoke_built = true
    for pos in [Vector3(-9, 0.8, -2), Vector3(-24, 1.2, -33), Vector3(22, 1.2, -36), Vector3(-34, 0.9, -30), Vector3(36, 1.0, -88)]:
        var p: CPUParticles3D = Fx.smoke_column(root, pos)
        p.visibility_range_end = 70.0
        smoke_cols.append(p)


## Menerapkan kualitas efek (jumlah dekal, asap) sesuai Settings. Aman dipanggil berulang.
func apply_quality() -> void:
    var n: int = Settings.decal_count()
    for i in decals.size():
        if is_instance_valid(decals[i]):
            decals[i].visible = i < n
    if Settings.smoke_enabled():
        _build_smoke()
    for sc in smoke_cols:
        if is_instance_valid(sc):
            sc.visible = Settings.smoke_enabled()
            sc.emitting = Settings.smoke_enabled()
