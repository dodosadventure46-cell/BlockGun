extends RefCounted
## Efek visual dengan pooling: impact, tracer, muzzle flash, bekas peluru, darah, ledakan, asap.

static var _holes: Array = []
static var _pools: Dictionary = {}
static var _mats: Dictionary = {}
static var _flash_mat: StandardMaterial3D = null
static var _hole_mat: StandardMaterial3D = null
static var _smoke_mat: StandardMaterial3D = null


static func _unshaded(c: Color) -> StandardMaterial3D:
    var key: String = "u_" + c.to_html()
    if _mats.has(key):
        return _mats[key]
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.albedo_color = c
    _mats[key] = m
    return m


static func _radial(c0: Color, c1: Color, mid: float) -> GradientTexture2D:
    var g := Gradient.new()
    g.colors = PackedColorArray([c0, c0, c1])
    g.offsets = PackedFloat32Array([0.0, mid, 1.0])
    var t := GradientTexture2D.new()
    t.gradient = g
    t.fill = GradientTexture2D.FILL_RADIAL
    t.fill_from = Vector2(0.5, 0.5)
    t.fill_to = Vector2(1.0, 0.5)
    t.width = 64
    t.height = 64
    return t


static func _free_later(node: Node, t: float) -> void:
    node.get_tree().create_timer(t).timeout.connect(node.queue_free)


static func _hide_later(node: Node3D, t: float) -> void:
    node.get_tree().create_timer(t).timeout.connect(node.set_visible.bind(false))


# ---------------------------------------------------------------- pool partikel
static func _get_pool_node(parent: Node, key: String, cap: int) -> Array:
    ## mengembalikan [node, baru?]
    var arr: Array = _pools.get(key, [])
    for q in arr:
        if is_instance_valid(q) and q.is_inside_tree() and not q.emitting:
            return [q, false]
    arr = arr.filter(func(x): return is_instance_valid(x) and x.is_inside_tree())
    _pools[key] = arr
    if arr.size() >= cap:
        return [arr[0], false]
    var p := CPUParticles3D.new()
    parent.add_child(p)
    arr.append(p)
    return [p, true]


static func _particles(parent: Node, key: String, pos: Vector3, dir: Vector3, amount: int, color: Color, life: float, vmin: float, vmax: float, spread: float, psize: float = 0.025) -> void:
    var res: Array = _get_pool_node(parent, "p_" + key, 10)
    var p: CPUParticles3D = res[0]
    if res[1]:
        var mesh := SphereMesh.new()
        mesh.radius = psize
        mesh.height = psize * 2.0
        mesh.radial_segments = 4
        mesh.rings = 2
        mesh.material = _unshaded(color)
        p.mesh = mesh
        p.lifetime = life
        p.one_shot = true
        p.explosiveness = 1.0
        p.gravity = Vector3(0, -9.0, 0)
        p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    p.amount = maxi(1, int(float(amount) * Settings.particle_scale()))
    p.direction = dir
    p.spread = spread
    p.initial_velocity_min = vmin
    p.initial_velocity_max = vmax
    p.global_position = pos
    p.restart()
    p.emitting = true


static func _make_smoke_material() -> StandardMaterial3D:
    if _smoke_mat == null:
        _smoke_mat = StandardMaterial3D.new()
        _smoke_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _smoke_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _smoke_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
        _smoke_mat.vertex_color_use_as_albedo = true
        _smoke_mat.albedo_texture = _radial(Color(1, 1, 1, 0.6), Color(1, 1, 1, 0.0), 0.0)
        _smoke_mat.no_depth_test = false
    return _smoke_mat


static func _smoke_setup(p: CPUParticles3D, size: float, life: float, rise: float, tint: Color) -> void:
    var qm := QuadMesh.new()
    qm.size = Vector2(size, size)
    qm.material = _make_smoke_material()
    p.mesh = qm
    p.lifetime = life
    p.gravity = Vector3(0, rise, 0)
    p.direction = Vector3.UP
    p.spread = 25.0
    p.initial_velocity_min = 0.4
    p.initial_velocity_max = 1.2
    var curve := Curve.new()
    curve.add_point(Vector2(0.0, 0.35))
    curve.add_point(Vector2(1.0, 1.7))
    p.scale_amount_curve = curve
    var g := Gradient.new()
    g.colors = PackedColorArray([Color(tint.r, tint.g, tint.b, 0.0), Color(tint.r, tint.g, tint.b, 0.55), Color(tint.r, tint.g, tint.b, 0.0)])
    g.offsets = PackedFloat32Array([0.0, 0.2, 1.0])
    p.color_ramp = g
    p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


## Kolom asap permanen (objek terbakar). Hanya dipanggil bila efek >= Sedang.
static func smoke_column(parent: Node, pos: Vector3) -> CPUParticles3D:
    var p := CPUParticles3D.new()
    _smoke_setup(p, 2.2, 5.0, 1.0, Color(0.25, 0.24, 0.23))
    p.amount = 9
    p.preprocess = 5.0
    p.emitting = true
    p.visibility_aabb = AABB(Vector3(-6, 0, -6), Vector3(12, 14, 12))
    parent.add_child(p)
    p.global_position = pos
    return p


# ---------------------------------------------------------------- efek pertempuran
static func impact(parent: Node, pos: Vector3, normal: Vector3) -> void:
    _particles(parent, "spark", pos, normal, 8, Color(1.0, 0.8, 0.4), 0.35, 1.5, 4.0, 55.0)
    if Settings.effects_q >= 1:
        _particles(parent, "dust", pos, normal, 4, Color(0.55, 0.52, 0.48), 0.7, 0.4, 1.2, 70.0, 0.04)
    if Settings.effects_q <= 0:
        return
    if _hole_mat == null:
        _hole_mat = StandardMaterial3D.new()
        _hole_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _hole_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _hole_mat.albedo_texture = _radial(Color(0, 0, 0, 0.85), Color(0, 0, 0, 0), 0.35)
    var q: MeshInstance3D = null
    _holes = _holes.filter(func(x): return is_instance_valid(x) and x.is_inside_tree())
    if _holes.size() >= 40:
        q = _holes.pop_front()
    else:
        q = MeshInstance3D.new()
        var qm := QuadMesh.new()
        qm.size = Vector2(0.14, 0.14)
        qm.material = _hole_mat
        q.mesh = qm
        q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        parent.add_child(q)
    q.global_position = pos + normal * 0.012
    var up: Vector3 = Vector3.UP
    if absf(normal.y) > 0.99:
        up = Vector3.RIGHT
    q.look_at(q.global_position - normal, up)
    _holes.append(q)


static func blood(parent: Node, pos: Vector3) -> void:
    _particles(parent, "blood", pos, Vector3.UP, 10, Color(0.6, 0.02, 0.02), 0.5, 1.0, 3.0, 80.0)


static func tracer(parent: Node, a: Vector3, b: Vector3, color: Color, w: float = 0.02, life: float = 0.07) -> void:
    var d: Vector3 = b - a
    var l: float = d.length()
    if l < 0.3:
        return
    var m: MeshInstance3D = _get_tracer(parent)
    var bm: BoxMesh = m.mesh
    bm.size = Vector3(w, w, l)
    bm.material = _unshaded(color)
    m.visible = true
    m.global_position = a + d * 0.5
    var up: Vector3 = Vector3.UP
    if absf(d.normalized().y) > 0.99:
        up = Vector3.RIGHT
    m.look_at(b, up)
    _hide_later(m, life)


static func _get_tracer(parent: Node) -> MeshInstance3D:
    var arr: Array = _pools.get("tracer", [])
    for q in arr:
        if is_instance_valid(q) and q.is_inside_tree() and not q.visible:
            return q
    arr = arr.filter(func(x): return is_instance_valid(x) and x.is_inside_tree())
    _pools["tracer"] = arr
    if arr.size() >= 14:
        return arr[0]
    var m := MeshInstance3D.new()
    m.mesh = BoxMesh.new()
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    m.visible = false
    parent.add_child(m)
    arr.append(m)
    return m


static func flash_mesh(size: float) -> MeshInstance3D:
    if _flash_mat == null:
        _flash_mat = StandardMaterial3D.new()
        _flash_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _flash_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _flash_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
        _flash_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
        _flash_mat.albedo_texture = _radial(Color(1.0, 0.8, 0.4, 1.0), Color(0, 0, 0, 1.0), 0.1)
    var q := MeshInstance3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2(size, size)
    qm.material = _flash_mat
    q.mesh = qm
    q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    return q


static func flash(parent: Node, pos: Vector3, size: float = 0.6) -> void:
    var arr: Array = _pools.get("flash", [])
    var q: MeshInstance3D = null
    for x in arr:
        if is_instance_valid(x) and x.is_inside_tree() and not x.visible:
            q = x
            break
    if q == null:
        arr = arr.filter(func(x): return is_instance_valid(x) and x.is_inside_tree())
        _pools["flash"] = arr
        if arr.size() >= 8:
            q = arr[0]
        else:
            q = flash_mesh(size)
            parent.add_child(q)
            arr.append(q)
    q.visible = true
    q.global_position = pos
    _hide_later(q, 0.05)


## Ledakan: bola api, percikan, asap, cahaya singkat, guncangan kamera.
static func explosion(parent: Node, pos: Vector3) -> void:
    _particles(parent, "fire", pos, Vector3.UP, 26, Color(1.0, 0.55, 0.15), 0.7, 2.0, 7.0, 180.0, 0.07)
    _particles(parent, "spark", pos, Vector3.UP, 14, Color(1.0, 0.85, 0.4), 0.5, 4.0, 9.0, 120.0)
    if Settings.effects_q >= 1:
        var res: Array = _get_pool_node(parent, "p_boom_smoke", 4)
        var p: CPUParticles3D = res[0]
        if res[1]:
            _smoke_setup(p, 2.6, 2.2, 0.8, Color(0.18, 0.17, 0.16))
            p.one_shot = true
            p.explosiveness = 0.9
        p.amount = 10
        p.global_position = pos
        p.restart()
        p.emitting = true
    if Settings.muzzle_light_enabled():
        var l := OmniLight3D.new()
        l.light_color = Color(1.0, 0.6, 0.25)
        l.light_energy = 6.0
        l.omni_range = 11.0
        l.shadow_enabled = false
        parent.add_child(l)
        l.global_position = pos
        var tw: Tween = l.create_tween()
        tw.tween_property(l, "light_energy", 0.0, 0.4)
        tw.tween_callback(l.queue_free)
    parent.get_tree().call_group("player", "add_shake", 1.0, pos)
