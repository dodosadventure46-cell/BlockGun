extends CanvasLayer
## HUD: HP, amunisi, crosshair, objektif, pesan, progres, vignette damage, kontrol sentuh.

signal pause_requested

const TouchControls := preload("res://scripts/ui/touch_controls.gd")
const CrosshairScript := preload("res://scripts/ui/crosshair.gd")
const UiKit := preload("res://scripts/ui/ui_kit.gd")
const HP_W := 294.0

var player = null
var controls = null
var crosshair = null
var hp_fill: ColorRect
var hp_label: Label
var ammo_label: Label
var weapon_label: Label
var obj_label: Label
var dist_label: Label
var msg_label: Label
var vignette: TextureRect
var prog_back: ColorRect
var prog_fill: ColorRect
var prog_label: Label
var msg_t: float = 0.0
var msg_dur: float = 0.0
var vig: float = 0.0


func _ready() -> void:
    layer = 5
    var root := Control.new()
    root.anchor_right = 1.0
    root.anchor_bottom = 1.0
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    # vignette damage
    var g := Gradient.new()
    g.colors = PackedColorArray([Color(0.8, 0, 0, 0), Color(0.8, 0, 0, 0), Color(0.8, 0, 0, 0.85)])
    g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
    var gt := GradientTexture2D.new()
    gt.gradient = g
    gt.fill = GradientTexture2D.FILL_RADIAL
    gt.fill_from = Vector2(0.5, 0.5)
    gt.fill_to = Vector2(1.0, 1.0)
    gt.width = 128
    gt.height = 128
    vignette = TextureRect.new()
    vignette.texture = gt
    vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    vignette.stretch_mode = TextureRect.STRETCH_SCALE
    vignette.anchor_right = 1.0
    vignette.anchor_bottom = 1.0
    vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
    vignette.modulate.a = 0.0
    root.add_child(vignette)
    # crosshair
    crosshair = Control.new()
    crosshair.set_script(CrosshairScript)
    root.add_child(crosshair)
    # health
    var hb := ColorRect.new()
    hb.color = Color(0, 0, 0, 0.55)
    hb.position = Vector2(24, 22)
    hb.size = Vector2(300, 28)
    hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hb)
    hp_fill = ColorRect.new()
    hp_fill.color = Color(0.25, 0.85, 0.3)
    hp_fill.position = Vector2(27, 25)
    hp_fill.size = Vector2(HP_W, 22)
    hp_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hp_fill)
    hp_label = UiKit.label("HP 100", 20)
    hp_label.position = Vector2(34, 20)
    root.add_child(hp_label)
    # ammo (kanan atas)
    weapon_label = UiKit.label("", 22, Color(1, 0.75, 0.4))
    weapon_label.anchor_left = 1.0
    weapon_label.anchor_right = 1.0
    weapon_label.offset_left = -340
    weapon_label.offset_right = -30
    weapon_label.offset_top = 96
    weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    root.add_child(weapon_label)
    ammo_label = UiKit.label("", 44)
    ammo_label.anchor_left = 1.0
    ammo_label.anchor_right = 1.0
    ammo_label.offset_left = -340
    ammo_label.offset_right = -30
    ammo_label.offset_top = 124
    ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    root.add_child(ammo_label)
    # objektif (tengah atas)
    obj_label = UiKit.label("", 22, Color(1, 0.9, 0.6))
    obj_label.anchor_left = 0.5
    obj_label.anchor_right = 0.5
    obj_label.offset_left = -400
    obj_label.offset_right = 400
    obj_label.offset_top = 16
    obj_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    obj_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    root.add_child(obj_label)
    dist_label = UiKit.label("", 20, Color(0.8, 0.9, 1.0))
    dist_label.anchor_left = 0.5
    dist_label.anchor_right = 0.5
    dist_label.offset_left = -200
    dist_label.offset_right = 200
    dist_label.offset_top = 82
    dist_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    root.add_child(dist_label)
    msg_label = UiKit.label("", 34, Color(1, 1, 1))
    msg_label.anchor_left = 0.5
    msg_label.anchor_right = 0.5
    msg_label.offset_left = -450
    msg_label.offset_right = 450
    msg_label.offset_top = 150
    msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    msg_label.modulate.a = 0.0
    root.add_child(msg_label)
    # progres generator (tengah bawah)
    prog_back = ColorRect.new()
    prog_back.color = Color(0, 0, 0, 0.6)
    prog_back.anchor_left = 0.5
    prog_back.anchor_right = 0.5
    prog_back.offset_left = -200
    prog_back.offset_right = 200
    prog_back.offset_top = 520
    prog_back.offset_bottom = 548
    prog_back.visible = false
    prog_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(prog_back)
    prog_fill = ColorRect.new()
    prog_fill.color = Color(0.3, 0.9, 0.4)
    prog_fill.position = Vector2(3, 3)
    prog_fill.size = Vector2(0, 22)
    prog_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    prog_back.add_child(prog_fill)
    prog_label = UiKit.label("MENGAKTIFKAN GENERATOR...", 20, Color(0.7, 1.0, 0.8))
    prog_label.anchor_left = 0.5
    prog_label.anchor_right = 0.5
    prog_label.offset_left = -250
    prog_label.offset_right = 250
    prog_label.offset_top = 486
    prog_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    prog_label.visible = false
    root.add_child(prog_label)
    # kontrol sentuh
    controls = Control.new()
    controls.set_script(TouchControls)
    root.add_child(controls)


func bind(p: Node) -> void:
    player = p


func set_objective(text: String) -> void:
    obj_label.text = "OBJEKTIF: " + text


func set_distance(m: float) -> void:
    dist_label.text = "Jarak: %d m" % int(m)


func set_progress(v: float) -> void:
    var vis: bool = v >= 0.0
    prog_back.visible = vis
    prog_label.visible = vis
    if vis:
        prog_fill.size.x = 394.0 * clampf(v, 0.0, 1.0)


func show_message(text: String, secs: float = 3.0) -> void:
    msg_label.text = text
    msg_t = secs
    msg_dur = secs
    msg_label.modulate.a = 1.0


func flash_damage() -> void:
    vig = 1.0


func hitmarker(head: bool, killed: bool) -> void:
    crosshair.hit_t = 0.3
    crosshair.hit_head = head or killed


func _process(delta: float) -> void:
    if player == null or not is_instance_valid(player):
        return
    if controls.consume("pause"):
        pause_requested.emit()
    var ratio: float = clampf(player.health / player.max_health, 0.0, 1.0)
    hp_fill.size.x = HP_W * ratio
    hp_fill.color = Color(0.85, 0.15, 0.1).lerp(Color(0.25, 0.85, 0.3), ratio)
    hp_label.text = "HP  %d" % int(ceil(player.health))
    var wp = player.weapons
    weapon_label.text = wp.weapon_title()
    if wp.is_reloading():
        ammo_label.text = "ISI ULANG..."
    else:
        ammo_label.text = "%d / %d" % [wp.mag_ammo(), wp.reserve_ammo()]
    crosshair.aiming = wp.aiming
    crosshair.gap = lerpf(crosshair.gap, 8.0 + wp.spread_amount() * 500.0, minf(1.0, 12.0 * delta))
    if msg_t > 0.0:
        msg_t -= delta
        msg_label.modulate.a = clampf(msg_t / 0.6, 0.0, 1.0)
    if vig > 0.0:
        vig = maxf(0.0, vig - delta * 1.6)
    var low: float = 0.35 if ratio < 0.3 else 0.0
    vignette.modulate.a = maxf(vig, low)
