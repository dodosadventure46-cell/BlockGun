extends Control
## Kontrol sentuh: joystick melayang (kiri), kamera (kanan), tombol aksi.

const JOY_RADIUS := 100.0

var move_vec: Vector2 = Vector2.ZERO
var fire_held: bool = false
var aim_on: bool = false
var look_accum: Vector2 = Vector2.ZERO
var edges: Dictionary = {}
var touches: Dictionary = {}
var buttons: Dictionary = {}
var down: Dictionary = {}
var joy_center: Vector2 = Vector2.ZERO
var joy_off: Vector2 = Vector2.ZERO
var joy_active: bool = false
var slot_req: int = -1
var slot_rects: Array = []
var slot_info: Array = []
var slot_sig: String = ""
var slot_active: int = 0


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    anchor_right = 1.0
    anchor_bottom = 1.0
    _layout()
    get_viewport().size_changed.connect(_layout)


func _layout() -> void:
    var s: Vector2 = get_viewport_rect().size
    buttons = {
        "fire": {"pos": Vector2(s.x - 170, s.y - 170), "r": 85.0, "label": "TEMBAK"},
        "aim": {"pos": Vector2(s.x - 330, s.y - 110), "r": 55.0, "label": "BIDIK"},
        "reload": {"pos": Vector2(s.x - 350, s.y - 250), "r": 50.0, "label": "ISI"},
        "jump": {"pos": Vector2(s.x - 150, s.y - 330), "r": 55.0, "label": "LOMPAT"},
        "pause": {"pos": Vector2(s.x - 70, 60), "r": 36.0, "label": "II"}
    }
    if not joy_active:
        joy_center = Vector2(190, s.y - 190)
    slot_rects.clear()
    for i in 4:
        slot_rects.append(Rect2(s.x - 85.0, 112.0 + i * 78.0, 70.0, 66.0))
    queue_redraw()


func reset() -> void:
    touches.clear()
    down.clear()
    move_vec = Vector2.ZERO
    fire_held = false
    aim_on = false
    joy_active = false
    joy_off = Vector2.ZERO
    look_accum = Vector2.ZERO
    slot_req = -1
    edges.clear()
    _layout()


func consume(nm: String) -> bool:
    if edges.get(nm, false):
        edges[nm] = false
        return true
    return false


func consume_slot() -> int:
    var r: int = slot_req
    slot_req = -1
    return r


## Dipanggil HUD: info tiap slot [{short, ammo}] dan slot aktif. Menggambar ulang hanya bila berubah.
func set_slot_info(info: Array, active: int) -> void:
    var sig: String = str(active)
    for it in info:
        sig += "|" + str(it["short"]) + ":" + str(it["ammo"])
    if sig == slot_sig:
        return
    slot_sig = sig
    slot_info = info
    slot_active = active
    queue_redraw()


func consume_look() -> Vector2:
    var l: Vector2 = look_accum
    look_accum = Vector2.ZERO
    return l


func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _press(event.index, event.position)
        else:
            _release(event.index)
    elif event is InputEventScreenDrag:
        _drag(event.index, event.position, event.relative)


func _press(idx: int, pos: Vector2) -> void:
    var s: Vector2 = get_viewport_rect().size
    for si in slot_rects.size():
        var rc: Rect2 = slot_rects[si]
        if rc.grow(6.0).has_point(pos):
            var sn: String = "slot%d" % si
            touches[idx] = {"role": "btn", "btn": sn}
            down[sn] = int(down.get(sn, 0)) + 1
            slot_req = si
            queue_redraw()
            return
    for n in buttons:
        var b: Dictionary = buttons[n]
        if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.2:
            touches[idx] = {"role": "btn", "btn": n}
            down[n] = int(down.get(n, 0)) + 1
            match n:
                "fire":
                    fire_held = true
                    edges["fire_edge"] = true
                "aim":
                    aim_on = not aim_on
                "jump":
                    edges["jump"] = true
                "reload":
                    edges["reload"] = true
                "pause":
                    edges["pause"] = true
            queue_redraw()
            return
    if pos.x < s.x * 0.42 and not joy_active:
        joy_active = true
        joy_center = Vector2(clampf(pos.x, JOY_RADIUS + 10.0, s.x * 0.42), clampf(pos.y, JOY_RADIUS + 10.0, s.y - JOY_RADIUS - 10.0))
        joy_off = pos - joy_center
        touches[idx] = {"role": "joy"}
        _update_joy()
    else:
        touches[idx] = {"role": "look"}
    queue_redraw()


func _release(idx: int) -> void:
    if not touches.has(idx):
        return
    var t: Dictionary = touches[idx]
    touches.erase(idx)
    if t["role"] == "joy":
        joy_active = false
        joy_off = Vector2.ZERO
        move_vec = Vector2.ZERO
        _layout()
    elif t["role"] == "btn":
        var n: String = t["btn"]
        down[n] = maxi(0, int(down.get(n, 1)) - 1)
        if n == "fire" and int(down[n]) == 0:
            fire_held = false
    queue_redraw()


func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
    if not touches.has(idx):
        return
    var t: Dictionary = touches[idx]
    if t["role"] == "joy":
        joy_off = pos - joy_center
        _update_joy()
    elif t["role"] == "look":
        look_accum += rel
    elif t["role"] == "btn" and t["btn"] == "fire":
        look_accum += rel
    queue_redraw()


func _update_joy() -> void:
    var v: Vector2 = joy_off / JOY_RADIUS
    if v.length() > 1.0:
        v = v.normalized()
        joy_off = v * JOY_RADIUS
    if v.length() < 0.12:
        v = Vector2.ZERO
    move_vec = v


func _draw() -> void:
    var font: Font = ThemeDB.fallback_font
    draw_circle(joy_center, JOY_RADIUS, Color(1, 1, 1, 0.08))
    draw_arc(joy_center, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.4), 3.0)
    draw_circle(joy_center + joy_off, 44.0, Color(1, 1, 1, 0.28))
    for n in buttons:
        var b: Dictionary = buttons[n]
        var pressed: bool = int(down.get(n, 0)) > 0 or (n == "aim" and aim_on)
        var fill: Color = Color(0.95, 0.3, 0.1, 0.4) if pressed else Color(1, 1, 1, 0.13)
        draw_circle(b["pos"], b["r"], fill)
        draw_arc(b["pos"], b["r"], 0.0, TAU, 40, Color(1, 1, 1, 0.5), 3.0)
        var fs: int = 20 if float(b["r"]) > 50.0 else 16
        draw_string(font, b["pos"] + Vector2(-float(b["r"]), 6), str(b["label"]), HORIZONTAL_ALIGNMENT_CENTER, float(b["r"]) * 2.0, fs, Color(1, 1, 1, 0.9))
    # slot senjata (ketuk untuk langsung memilih)
    for i in slot_rects.size():
        var rc2: Rect2 = slot_rects[i]
        var active: bool = (i == slot_active)
        var pressed2: bool = int(down.get("slot%d" % i, 0)) > 0
        var bg: Color = Color(0.9, 0.4, 0.1, 0.55) if (active or pressed2) else Color(0.05, 0.06, 0.08, 0.5)
        draw_rect(rc2, bg, true)
        draw_rect(rc2, Color(1, 0.7, 0.3, 0.95) if active else Color(1, 1, 1, 0.4), false, 3.0 if active else 2.0)
        draw_string(font, rc2.position + Vector2(5, 17), str(i + 1), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1, 1, 1, 0.8))
        if i < slot_info.size():
            draw_string(font, rc2.position + Vector2(0, 38), str(slot_info[i]["short"]), HORIZONTAL_ALIGNMENT_CENTER, rc2.size.x, 17, Color(1, 1, 1, 0.95))
            draw_string(font, rc2.position + Vector2(0, 58), str(slot_info[i]["ammo"]), HORIZONTAL_ALIGNMENT_CENTER, rc2.size.x, 16, Color(1, 0.85, 0.5, 0.95))
