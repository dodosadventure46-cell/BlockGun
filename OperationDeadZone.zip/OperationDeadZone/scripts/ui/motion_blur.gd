extends CanvasLayer
## Motion blur arah kamera (post-process layar, bisa dimatikan di Pengaturan).
## Berbasis shader canvas_item + hint_screen_texture; hanya aktif saat kamera berputar cepat.

const SHADER_CODE := """
shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, filter_linear, repeat_disable;
uniform vec2 blur_dir = vec2(0.0);
void fragment() {
    vec3 c = vec3(0.0);
    for (int i = -3; i <= 3; i++) {
        c += texture(screen_tex, SCREEN_UV + blur_dir * float(i) / 3.0).rgb;
    }
    COLOR = vec4(c / 7.0, 1.0);
}
"""

var rect: ColorRect
var mat: ShaderMaterial
var smooth: Vector2 = Vector2.ZERO


func _ready() -> void:
    layer = 1
    var sh := Shader.new()
    sh.code = SHADER_CODE
    mat = ShaderMaterial.new()
    mat.shader = sh
    rect = ColorRect.new()
    rect.anchor_right = 1.0
    rect.anchor_bottom = 1.0
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    rect.material = mat
    rect.visible = false
    add_child(rect)


## look = gerakan kamera (piksel) pada frame ini.
func update_blur(look: Vector2, delta: float) -> void:
    if not Settings.motion_blur:
        rect.visible = false
        return
    var target: Vector2 = Vector2(look.x * 0.0009, look.y * 0.0016)
    target = target.limit_length(0.012)
    smooth = smooth.lerp(target, 1.0 - exp(-14.0 * delta))
    if smooth.length() < 0.0012:
        rect.visible = false
        return
    rect.visible = true
    mat.set_shader_parameter("blur_dir", Vector2(-smooth.x, -smooth.y))
