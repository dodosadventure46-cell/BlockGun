extends Control
## Menu utama: Main / Lanjutkan, Pengaturan, Keluar.

const UiKit := preload("res://scripts/ui/ui_kit.gd")

var main_box: Control
var settings_box: Control


func _ready() -> void:
    theme = UiKit.make_theme()
    _build_bg()
    _build_main()
    settings_box = CenterContainer.new()
    settings_box.anchor_right = 1.0
    settings_box.anchor_bottom = 1.0
    var panel := PanelContainer.new()
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.07, 0.08, 0.1, 0.96)
    sb.border_color = Color(0.88, 0.45, 0.16)
    sb.set_border_width_all(2)
    sb.set_corner_radius_all(12)
    sb.content_margin_left = 40
    sb.content_margin_right = 40
    sb.content_margin_top = 28
    sb.content_margin_bottom = 28
    panel.add_theme_stylebox_override("panel", sb)
    panel.add_child(UiKit.settings_panel(func(): pass, _back))
    settings_box.add_child(panel)
    add_child(settings_box)
    settings_box.visible = false
    SFX.play_music()


func _build_bg() -> void:
    var g := Gradient.new()
    g.colors = PackedColorArray([Color(0.04, 0.06, 0.1), Color(0.3, 0.16, 0.1)])
    g.offsets = PackedFloat32Array([0.0, 1.0])
    var gt := GradientTexture2D.new()
    gt.gradient = g
    gt.fill_from = Vector2(0, 0)
    gt.fill_to = Vector2(0, 1)
    gt.width = 8
    gt.height = 256
    var bg := TextureRect.new()
    bg.texture = gt
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_SCALE
    bg.anchor_right = 1.0
    bg.anchor_bottom = 1.0
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(bg)
    var rng := RandomNumberGenerator.new()
    rng.seed = 7
    for layer_i in 2:
        for i in 22:
            var r := ColorRect.new()
            var h: float = rng.randf_range(0.1, 0.32) + (0.08 if layer_i == 0 else 0.0)
            var shade: float = 0.07 if layer_i == 0 else 0.03
            r.color = Color(shade, shade, shade + 0.01)
            r.anchor_left = float(i) / 22.0
            r.anchor_right = float(i + 1) / 22.0 + 0.004
            r.anchor_top = 1.0 - h
            r.anchor_bottom = 1.0
            r.mouse_filter = Control.MOUSE_FILTER_IGNORE
            add_child(r)


func _build_main() -> void:
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    box.anchor_top = 0.5
    box.anchor_bottom = 0.5
    box.offset_left = 80
    box.offset_top = -270
    box.offset_right = 620
    box.offset_bottom = 270
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    box.add_child(UiKit.label("OPERATION", 40, Color(0.95, 0.5, 0.15)))
    box.add_child(UiKit.label("DEAD ZONE", 92))
    box.add_child(UiKit.label("Kampanye Satu Pemain - Kota Vesper", 22, Color(0.75, 0.75, 0.8)))
    var spacer := Control.new()
    spacer.custom_minimum_size = Vector2(0, 18)
    box.add_child(spacer)
    if Settings.checkpoint > 0:
        box.add_child(UiKit.button("LANJUTKAN (CHECKPOINT %d)" % Settings.checkpoint, func(): Game.continue_mission(), 26))
        box.add_child(UiKit.button("MISI BARU", func(): Game.new_mission()))
    else:
        box.add_child(UiKit.button("MAIN", func(): Game.new_mission()))
    box.add_child(UiKit.button("PENGATURAN", _open_settings))
    box.add_child(UiKit.button("KELUAR", func(): get_tree().quit()))
    var info: String = "Misi selesai: %d" % Settings.missions_completed
    if Settings.best_time > 0.0:
        info += "   Waktu terbaik: %d:%02d" % [int(Settings.best_time) / 60, int(Settings.best_time) % 60]
    box.add_child(UiKit.label(info, 20, Color(0.7, 0.7, 0.75)))
    main_box = box
    add_child(box)


func _open_settings() -> void:
    main_box.visible = false
    settings_box.visible = true


func _back() -> void:
    settings_box.visible = false
    main_box.visible = true
    SFX.stop_music()
    SFX.play_music()
