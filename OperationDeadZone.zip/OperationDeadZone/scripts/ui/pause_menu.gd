extends CanvasLayer
## Menu pause, pengaturan, dan layar akhir (menang/kalah).

signal resume_pressed
signal checkpoint_pressed
signal restart_pressed
signal menu_pressed
signal settings_changed

const UiKit := preload("res://scripts/ui/ui_kit.gd")

var dim: ColorRect
var pause_box: Control
var settings_box: Control
var end_box: Control
var end_title: Label
var end_text: Label
var end_buttons: VBoxContainer
var theme_res: Theme


func _ready() -> void:
    layer = 20
    process_mode = Node.PROCESS_MODE_ALWAYS
    theme_res = UiKit.make_theme()
    dim = ColorRect.new()
    dim.color = Color(0, 0, 0, 0.65)
    dim.anchor_right = 1.0
    dim.anchor_bottom = 1.0
    dim.mouse_filter = Control.MOUSE_FILTER_STOP
    dim.theme = theme_res
    add_child(dim)
    pause_box = _centered(_build_pause())
    settings_box = _centered(UiKit.settings_panel(func(): settings_changed.emit(), _show_pause_again))
    var ev := VBoxContainer.new()
    ev.add_theme_constant_override("separation", 14)
    end_title = UiKit.label("", 56, Color(1, 0.65, 0.3))
    end_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    end_text = UiKit.label("", 26)
    end_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    end_buttons = VBoxContainer.new()
    end_buttons.add_theme_constant_override("separation", 12)
    ev.add_child(end_title)
    ev.add_child(end_text)
    ev.add_child(end_buttons)
    end_box = _centered(ev)
    hide_all()


func _centered(content: Control) -> Control:
    var cc := CenterContainer.new()
    cc.anchor_right = 1.0
    cc.anchor_bottom = 1.0
    cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var panel := PanelContainer.new()
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.07, 0.08, 0.1, 0.96)
    sb.border_color = Color(0.88, 0.45, 0.16)
    sb.set_border_width_all(2)
    sb.set_corner_radius_all(12)
    sb.content_margin_left = 40
    sb.content_margin_right = 40
    sb.content_margin_top = 28
    sb.content_margin_bottom = 28
    panel.add_theme_stylebox_override("panel", sb)
    panel.add_child(content)
    cc.add_child(panel)
    cc.theme = theme_res
    add_child(cc)
    return cc


func _build_pause() -> Control:
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    var t := UiKit.label("JEDA", 56, Color(1, 0.65, 0.3))
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(t)
    box.add_child(UiKit.button("LANJUTKAN", func(): resume_pressed.emit()))
    box.add_child(UiKit.button("PENGATURAN", _show_settings))
    box.add_child(UiKit.button("ULANGI DARI CHECKPOINT", func(): checkpoint_pressed.emit(), 26))
    box.add_child(UiKit.button("MULAI ULANG MISI", func(): restart_pressed.emit()))
    box.add_child(UiKit.button("MENU UTAMA", func(): menu_pressed.emit()))
    return box


func hide_all() -> void:
    dim.visible = false
    pause_box.visible = false
    settings_box.visible = false
    end_box.visible = false


func show_pause() -> void:
    hide_all()
    dim.visible = true
    pause_box.visible = true


func _show_settings() -> void:
    pause_box.visible = false
    settings_box.visible = true


func _show_pause_again() -> void:
    settings_box.visible = false
    pause_box.visible = true


func show_end(victory: bool, summary: String) -> void:
    hide_all()
    dim.visible = true
    end_box.visible = true
    for c in end_buttons.get_children():
        c.queue_free()
    if victory:
        end_title.text = "MISI SELESAI"
        end_title.add_theme_color_override("font_color", Color(0.4, 1.0, 0.5))
        end_buttons.add_child(UiKit.button("MAIN LAGI", func(): restart_pressed.emit()))
    else:
        end_title.text = "GUGUR"
        end_title.add_theme_color_override("font_color", Color(1.0, 0.3, 0.2))
        end_buttons.add_child(UiKit.button("ULANGI DARI CHECKPOINT", func(): checkpoint_pressed.emit(), 26))
        end_buttons.add_child(UiKit.button("MULAI ULANG MISI", func(): restart_pressed.emit()))
    end_buttons.add_child(UiKit.button("MENU UTAMA", func(): menu_pressed.emit()))
    end_text.text = summary
