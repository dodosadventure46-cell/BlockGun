extends Control
## Crosshair dinamis + hit marker.

var gap: float = 10.0
var hit_t: float = 0.0
var hit_head: bool = false
var aiming: bool = false


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    anchor_right = 1.0
    anchor_bottom = 1.0


func _process(delta: float) -> void:
    if hit_t > 0.0:
        hit_t -= delta
    queue_redraw()


func _draw() -> void:
    var c: Vector2 = get_viewport_rect().size * 0.5
    var col := Color(1, 1, 1, 0.9)
    var sh := Color(0, 0, 0, 0.6)
    if aiming:
        draw_circle(c, 3.5, sh)
        draw_circle(c, 2.5, Color(1.0, 0.4, 0.2, 1.0))
    else:
        for d in [Vector2(-1, 0), Vector2(1, 0), Vector2(0, -1), Vector2(0, 1)]:
            var a: Vector2 = c + d * gap
            var b: Vector2 = c + d * (gap + 14.0)
            draw_line(a, b, sh, 5.0)
            draw_line(a, b, col, 3.0)
        draw_circle(c, 2.0, col)
    if hit_t > 0.0:
        var hc: Color = Color(1, 0.2, 0.2, hit_t * 4.0) if hit_head else Color(1, 1, 1, hit_t * 4.0)
        for d2 in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
            draw_line(c + d2 * 10.0, c + d2 * 20.0, hc, 3.0)
