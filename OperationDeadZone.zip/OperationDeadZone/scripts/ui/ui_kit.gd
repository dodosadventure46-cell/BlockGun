extends RefCounted
## Pembantu UI: tombol, label, slider, panel pengaturan (dipakai menu utama & menu pause).


static func _sb(bg: Color, border: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(2)
    s.set_corner_radius_all(8)
    s.content_margin_left = 16
    s.content_margin_right = 16
    s.content_margin_top = 8
    s.content_margin_bottom = 8
    return s


static func make_theme() -> Theme:
    var t := Theme.new()
    t.default_font_size = 26
    return t


static func button(text: String, cb: Callable, font_size: int = 30, width: float = 420.0) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(width, 72)
    b.add_theme_font_size_override("font_size", font_size)
    var orange := Color(0.88, 0.45, 0.16)
    b.add_theme_stylebox_override("normal", _sb(Color(0.12, 0.13, 0.15, 0.95), orange))
    b.add_theme_stylebox_override("hover", _sb(Color(0.2, 0.21, 0.24, 0.95), orange))
    b.add_theme_stylebox_override("pressed", _sb(Color(0.55, 0.25, 0.08, 0.98), Color(1, 0.7, 0.3)))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.pressed.connect(cb)
    b.pressed.connect(func(): SFX.play("ui_click"))
    return b


static func label(text: String, size: int = 26, color: Color = Color(1, 1, 1)) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    l.add_theme_constant_override("outline_size", 4)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return l


static func knob_texture() -> GradientTexture2D:
    var g := Gradient.new()
    var c := Color(1.0, 0.6, 0.2, 1.0)
    g.colors = PackedColorArray([c, c, Color(c.r, c.g, c.b, 0.0)])
    g.offsets = PackedFloat32Array([0.0, 0.85, 1.0])
    var t := GradientTexture2D.new()
    t.gradient = g
    t.fill = GradientTexture2D.FILL_RADIAL
    t.fill_from = Vector2(0.5, 0.5)
    t.fill_to = Vector2(1.0, 0.5)
    t.width = 40
    t.height = 40
    return t


static func slider_row(title: String, minv: float, maxv: float, step: float, value: float, on_change: Callable) -> Control:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 16)
    var l := label(title, 26)
    l.custom_minimum_size = Vector2(250, 0)
    row.add_child(l)
    var s := HSlider.new()
    s.min_value = minv
    s.max_value = maxv
    s.step = step
    s.value = value
    s.custom_minimum_size = Vector2(380, 48)
    s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    var kt: GradientTexture2D = knob_texture()
    s.add_theme_icon_override("grabber", kt)
    s.add_theme_icon_override("grabber_highlight", kt)
    row.add_child(s)
    var vl := label("%.2f" % value, 24, Color(1, 0.8, 0.5))
    vl.custom_minimum_size = Vector2(70, 0)
    row.add_child(vl)
    s.value_changed.connect(func(v):
        vl.text = "%.2f" % v
        on_change.call(v))
    return row


static func _small_button(width: float, fs: int = 24, h: float = 56.0) -> Button:
    var b := Button.new()
    b.custom_minimum_size = Vector2(width, h)
    b.add_theme_font_size_override("font_size", fs)
    b.add_theme_stylebox_override("normal", _sb(Color(0.12, 0.13, 0.15, 0.95), Color(0.5, 0.5, 0.5)))
    b.add_theme_stylebox_override("hover", _sb(Color(0.2, 0.21, 0.24, 0.95), Color(0.9, 0.5, 0.2)))
    b.add_theme_stylebox_override("pressed", _sb(Color(0.55, 0.25, 0.08, 0.98), Color(1, 0.7, 0.3)))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    return b


## Baris pilihan: tekan untuk berganti ke opsi berikutnya. Nilai dibaca/ditulis lewat properti Settings[key].
static func cycle_row(title: String, names: Array, key: String, custom: bool, after: Callable, refresh_fns: Array) -> Control:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 16)
    var l := label(title, 24)
    l.custom_minimum_size = Vector2(250, 0)
    row.add_child(l)
    var b: Button = _small_button(430.0)
    b.text = str(names[clampi(int(Settings.get(key)), 0, names.size() - 1)])
    b.pressed.connect(func():
        var i: int = (int(Settings.get(key)) + 1) % names.size()
        Settings.set(key, i)
        b.text = str(names[i])
        SFX.play("ui_click")
        after.call(custom))
    refresh_fns.append(func(): b.text = str(names[clampi(int(Settings.get(key)), 0, names.size() - 1)]))
    row.add_child(b)
    return row


static func toggle_row(title: String, key: String, custom: bool, after: Callable, refresh_fns: Array) -> Control:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 16)
    var l := label(title, 24)
    l.custom_minimum_size = Vector2(250, 0)
    row.add_child(l)
    var b: Button = _small_button(430.0)
    b.text = "HIDUP" if bool(Settings.get(key)) else "MATI"
    b.pressed.connect(func():
        var v: bool = not bool(Settings.get(key))
        Settings.set(key, v)
        b.text = "HIDUP" if v else "MATI"
        SFX.play("ui_click")
        after.call(custom))
    refresh_fns.append(func(): b.text = "HIDUP" if bool(Settings.get(key)) else "MATI")
    row.add_child(b)
    return row


static func key_slider(title: String, minv: float, maxv: float, step: float, key: String, custom: bool, after: Callable, refresh_fns: Array) -> Control:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 16)
    var l := label(title, 24)
    l.custom_minimum_size = Vector2(250, 0)
    row.add_child(l)
    var s := HSlider.new()
    s.min_value = minv
    s.max_value = maxv
    s.step = step
    s.value = float(Settings.get(key))
    s.custom_minimum_size = Vector2(340, 48)
    s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    var kt: GradientTexture2D = knob_texture()
    s.add_theme_icon_override("grabber", kt)
    s.add_theme_icon_override("grabber_highlight", kt)
    row.add_child(s)
    var vl := label("%.2f" % s.value, 22, Color(1, 0.8, 0.5))
    vl.custom_minimum_size = Vector2(70, 0)
    row.add_child(vl)
    s.value_changed.connect(func(v):
        Settings.set(key, v)
        vl.text = "%.2f" % v
        after.call(custom))
    refresh_fns.append(func():
        s.set_value_no_signal(float(Settings.get(key)))
        vl.text = "%.2f" % s.value)
    return row


static func settings_panel(on_change: Callable, on_back: Callable) -> Control:
    var refresh_fns: Array = []
    var after: Callable = func(custom: bool):
        if custom:
            Settings.preset = -1
        Settings.save_settings()
        for f in refresh_fns:
            f.call()
        on_change.call()

    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    box.add_child(label("PENGATURAN", 44, Color(1, 0.65, 0.3)))
    var sc := ScrollContainer.new()
    sc.custom_minimum_size = Vector2(900, 390)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    var inner := VBoxContainer.new()
    inner.add_theme_constant_override("separation", 12)
    inner.custom_minimum_size = Vector2(860, 0)
    sc.add_child(inner)
    box.add_child(sc)

    inner.add_child(label("Kontrol dan Audio", 28, Color(1, 0.8, 0.5)))
    inner.add_child(key_slider("Sensitivitas", 0.3, 2.5, 0.05, "sensitivity", false, after, refresh_fns))
    inner.add_child(key_slider("Volume", 0.0, 1.0, 0.05, "master_volume", false, after, refresh_fns))
    inner.add_child(toggle_row("Musik Menu", "music_on", false, after, refresh_fns))

    inner.add_child(label("Grafis", 28, Color(1, 0.8, 0.5)))
    var preset_row := HBoxContainer.new()
    preset_row.add_theme_constant_override("separation", 10)
    var group := ButtonGroup.new()
    group.allow_unpress = true
    var preset_btns: Array = []
    for i in 4:
        var pb: Button = _small_button(200.0, 24, 60.0)
        pb.text = Settings.PRESET_NAMES[i]
        pb.toggle_mode = true
        pb.button_group = group
        pb.button_pressed = (Settings.preset == i)
        pb.pressed.connect(func():
            Settings.apply_preset(i)
            SFX.play("ui_click")
            for f in refresh_fns:
                f.call()
            on_change.call())
        preset_row.add_child(pb)
        preset_btns.append(pb)
    inner.add_child(preset_row)
    var desc := label("", 20, Color(0.8, 0.8, 0.8))
    desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    desc.custom_minimum_size = Vector2(840, 0)
    var sync_preset: Callable = func():
        for j in preset_btns.size():
            preset_btns[j].button_pressed = (Settings.preset == j)
        if Settings.preset >= 0:
            desc.text = Settings.PRESET_DESC[Settings.preset]
        else:
            desc.text = "Kustom: kombinasi pengaturan manual di bawah."

    refresh_fns.append(sync_preset)
    sync_preset.call()
    inner.add_child(desc)

    inner.add_child(cycle_row("Target FPS", Settings.FPS_NAMES, "fps_idx", false, after, refresh_fns))
    inner.add_child(key_slider("Render Scale", 0.5, 1.0, 0.05, "render_scale", true, after, refresh_fns))
    inner.add_child(cycle_row("Kualitas Bayangan", Settings.SHADOW_NAMES, "shadow_q", true, after, refresh_fns))
    inner.add_child(cycle_row("Kualitas Tekstur", Settings.TEX_NAMES, "texture_q", true, after, refresh_fns))
    inner.add_child(cycle_row("Kualitas Efek", Settings.FX_NAMES, "effects_q", true, after, refresh_fns))
    inner.add_child(cycle_row("Jarak Pandang", Settings.VIEW_NAMES, "view_q", true, after, refresh_fns))
    inner.add_child(cycle_row("Anti-Aliasing", Settings.AA_NAMES, "aa", true, after, refresh_fns))
    inner.add_child(toggle_row("Motion Blur", "motion_blur", false, after, refresh_fns))
    inner.add_child(toggle_row("V-Sync", "vsync", false, after, refresh_fns))
    inner.add_child(toggle_row("Grafis Adaptif", "adaptive", true, after, refresh_fns))
    var note := label("Catatan: ukuran tekstur berlaku saat misi dimulai/diulang. Ambient occlusion (SSAO) tidak tersedia di renderer Mobile. Geser daftar untuk melihat semua opsi.", 18, Color(0.7, 0.7, 0.75))
    note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    note.custom_minimum_size = Vector2(840, 0)
    inner.add_child(note)

    box.add_child(button("KEMBALI", on_back, 30, 420.0))
    return box
