extends RefCounted
## Pembantu UI: tombol, label, slider, panel pengaturan (dipakai menu utama & menu pause).


static func _sb(bg: Color, border: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(2)
    s.set_corner_radius_all(8)
    s.content_margin_left = 16
    s.content_margin_right = 16
    s.content_margin_top = 8
    s.content_margin_bottom = 8
    return s


static func make_theme() -> Theme:
    var t := Theme.new()
    t.default_font_size = 26
    return t


static func button(text: String, cb: Callable, font_size: int = 30, width: float = 420.0) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(width, 72)
    b.add_theme_font_size_override("font_size", font_size)
    var orange := Color(0.88, 0.45, 0.16)
    b.add_theme_stylebox_override("normal", _sb(Color(0.12, 0.13, 0.15, 0.95), orange))
    b.add_theme_stylebox_override("hover", _sb(Color(0.2, 0.21, 0.24, 0.95), orange))
    b.add_theme_stylebox_override("pressed", _sb(Color(0.55, 0.25, 0.08, 0.98), Color(1, 0.7, 0.3)))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.pressed.connect(cb)
    b.pressed.connect(func(): SFX.play("ui_click"))
    return b


static func label(text: String, size: int = 26, color: Color = Color(1, 1, 1)) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    l.add_theme_constant_override("outline_size", 4)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return l


static func knob_texture() -> GradientTexture2D:
    var g := Gradient.new()
    var c := Color(1.0, 0.6, 0.2, 1.0)
    g.colors = PackedColorArray([c, c, Color(c.r, c.g, c.b, 0.0)])
    g.offsets = PackedFloat32Array([0.0, 0.85, 1.0])
    var t := GradientTexture2D.new()
    t.gradient = g
    t.fill = GradientTexture2D.FILL_RADIAL
    t.fill_from = Vector2(0.5, 0.5)
    t.fill_to = Vector2(1.0, 0.5)
    t.width = 40
    t.height = 40
    return t


static func slider_row(title: String, minv: float, maxv: float, step: float, value: float, on_change: Callable) -> Control:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 16)
    var l := label(title, 26)
    l.custom_minimum_size = Vector2(250, 0)
    row.add_child(l)
    var s := HSlider.new()
    s.min_value = minv
    s.max_value = maxv
    s.step = step
    s.value = value
    s.custom_minimum_size = Vector2(380, 48)
    s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    var kt: GradientTexture2D = knob_texture()
    s.add_theme_icon_override("grabber", kt)
    s.add_theme_icon_override("grabber_highlight", kt)
    row.add_child(s)
    var vl := label("%.2f" % value, 24, Color(1, 0.8, 0.5))
    vl.custom_minimum_size = Vector2(70, 0)
    row.add_child(vl)
    s.value_changed.connect(func(v):
        vl.text = "%.2f" % v
        on_change.call(v))
    return row


static func settings_panel(on_change: Callable, on_back: Callable) -> Control:
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    box.add_child(label("PENGATURAN", 44, Color(1, 0.65, 0.3)))
    box.add_child(slider_row("Sensitivitas", 0.3, 2.5, 0.05, Settings.sensitivity, func(v):
        Settings.sensitivity = v
        Settings.save_settings()
        on_change.call()))
    box.add_child(slider_row("Volume", 0.0, 1.0, 0.05, Settings.master_volume, func(v):
        Settings.master_volume = v
        Settings.save_settings()
        on_change.call()))
    var music_btn: Button = button("Musik Menu: " + ("HIDUP" if Settings.music_on else "MATI"), func(): pass, 26, 420.0)
    music_btn.pressed.connect(func():
        Settings.music_on = not Settings.music_on
        Settings.save_settings()
        music_btn.text = "Musik Menu: " + ("HIDUP" if Settings.music_on else "MATI")
        on_change.call())
    box.add_child(music_btn)
    box.add_child(label("Kualitas Grafis", 26))
    var desc := label(Settings.GRAPHICS_DESC[Settings.graphics], 20, Color(0.8, 0.8, 0.8))
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 10)
    var group := ButtonGroup.new()
    for i in 3:
        var gb := Button.new()
        gb.text = Settings.GRAPHICS_NAMES[i]
        gb.toggle_mode = true
        gb.button_group = group
        gb.custom_minimum_size = Vector2(160, 64)
        gb.add_theme_font_size_override("font_size", 26)
        gb.add_theme_stylebox_override("normal", _sb(Color(0.12, 0.13, 0.15, 0.95), Color(0.4, 0.4, 0.4)))
        gb.add_theme_stylebox_override("pressed", _sb(Color(0.55, 0.25, 0.08, 0.98), Color(1, 0.7, 0.3)))
        gb.add_theme_stylebox_override("hover", _sb(Color(0.2, 0.21, 0.24, 0.95), Color(0.9, 0.5, 0.2)))
        gb.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
        gb.button_pressed = (Settings.graphics == i)
        gb.pressed.connect(func():
            Settings.graphics = i
            Settings.save_settings()
            desc.text = Settings.GRAPHICS_DESC[i]
            SFX.play("ui_click")
            on_change.call())
        row.add_child(gb)
    box.add_child(row)
    box.add_child(desc)
    box.add_child(button("KEMBALI", on_back, 30, 420.0))
    return box
