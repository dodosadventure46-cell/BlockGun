extends CharacterBody3D
## Pemain FPS: gerak, lompat, kamera, kesehatan.

const WeaponHolderScene := preload("res://scenes/weapons/weapon_holder.tscn")

signal died
signal damaged(amount)
signal health_changed(hp, max_hp)

const WALK_SPEED := 5.4
const JUMP_VELOCITY := 5.2
const GRAVITY := 15.0

var controls = null
var max_health: float = 100.0
var health: float = 100.0
var alive: bool = true
var pitch: float = 0.0
var recoil_offset: float = 0.0
var head: Node3D
var camera: Camera3D
var weapons = null
var step_acc: float = 0.0
var bob_t: float = 0.0
var since_damage: float = 99.0


func _ready() -> void:
    add_to_group("player")
    collision_layer = 2
    collision_mask = 1 | 4
    floor_snap_length = 0.3
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.8
    cs.shape = cap
    cs.position = Vector3(0, 0.9, 0)
    add_child(cs)
    head = Node3D.new()
    head.position = Vector3(0, 1.62, 0)
    add_child(head)
    camera = Camera3D.new()
    camera.fov = 75.0
    camera.near = 0.05
    camera.far = 220.0
    head.add_child(camera)
    camera.make_current()
    weapons = WeaponHolderScene.instantiate()
    camera.add_child(weapons)
    weapons.setup(self)
    # partikel debu atmosfer (mengikuti pemain, dunia-lokal)
    var amount: int = Settings.dust_amount()
    if amount > 0:
        var dust := CPUParticles3D.new()
        var qm := QuadMesh.new()
        qm.size = Vector2(0.05, 0.05)
        var mat := StandardMaterial3D.new()
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.albedo_color = Color(0.8, 0.75, 0.65, 0.5)
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
        qm.material = mat
        dust.mesh = qm
        dust.amount = amount
        dust.lifetime = 7.0
        dust.preprocess = 7.0
        dust.local_coords = false
        dust.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
        dust.emission_box_extents = Vector3(14, 4, 14)
        dust.direction = Vector3(1, 0.1, 0.3)
        dust.spread = 40.0
        dust.initial_velocity_min = 0.2
        dust.initial_velocity_max = 0.8
        dust.gravity = Vector3(0, -0.05, 0)
        dust.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        dust.position = Vector3(0, 1.5, 0)
        add_child(dust)


func _process(delta: float) -> void:
    if not alive:
        return
    var look := Vector2.ZERO
    if controls != null:
        look = controls.consume_look()
    var f: float = 0.0042 * Settings.sensitivity
    if weapons.aiming:
        f *= 0.55
    rotate_y(-look.x * f)
    pitch = clampf(pitch - look.y * f, -1.45, 1.45)
    recoil_offset = lerpf(recoil_offset, 0.0, minf(1.0, 9.0 * delta))
    head.rotation.x = pitch + recoil_offset
    var spd: float = Vector2(velocity.x, velocity.z).length()
    if is_on_floor() and spd > 0.5:
        bob_t += delta * spd * 1.9
        head.position.y = 1.62 + sin(bob_t) * 0.035 * minf(spd / 5.0, 1.0)
    else:
        head.position.y = lerpf(head.position.y, 1.62, minf(1.0, 8.0 * delta))


func _physics_process(delta: float) -> void:
    if not alive:
        velocity.x = move_toward(velocity.x, 0.0, 10.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 10.0 * delta)
        if not is_on_floor():
            velocity.y -= GRAVITY * delta
        move_and_slide()
        return
    since_damage += delta
    if since_damage > 6.0 and health < 50.0:
        health = minf(50.0, health + 4.0 * delta)
        health_changed.emit(health, max_health)
    var input := Vector2.ZERO
    var jump: bool = false
    if controls != null:
        input = controls.move_vec
        jump = controls.consume("jump")
    input += Vector2(float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)), float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
    input = input.limit_length(1.0)
    if Input.is_key_pressed(KEY_SPACE):
        jump = true
    var dir: Vector3 = global_transform.basis * Vector3(input.x, 0.0, input.y)
    var speed: float = WALK_SPEED
    if weapons.aiming:
        speed *= 0.62
    var accel: float = 14.0 if is_on_floor() else 4.0
    velocity.x = lerpf(velocity.x, dir.x * speed, minf(1.0, accel * delta))
    velocity.z = lerpf(velocity.z, dir.z * speed, minf(1.0, accel * delta))
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    elif jump:
        velocity.y = JUMP_VELOCITY
    move_and_slide()
    var hs: float = Vector2(velocity.x, velocity.z).length()
    if is_on_floor() and hs > 1.0:
        step_acc += hs * delta
        if step_acc > 2.3:
            step_acc = 0.0
            SFX.play("step", -9.0, randf_range(0.9, 1.1))


func kick(amount: float) -> void:
    pitch += amount * 0.45
    recoil_offset += amount * 0.55
    rotate_y(randf_range(-0.2, 0.2) * amount)


func take_damage(amount: float, from: Vector3 = Vector3.ZERO) -> void:
    if not alive:
        return
    health = maxf(0.0, health - amount)
    since_damage = 0.0
    SFX.play("hurt", -4.0)
    damaged.emit(amount)
    health_changed.emit(health, max_health)
    if health <= 0.0:
        _die()


func heal(amount: float) -> void:
    health = minf(max_health, health + amount)
    health_changed.emit(health, max_health)


func _die() -> void:
    alive = false
    died.emit()
    var tw := create_tween()
    tw.set_parallel(true)
    tw.tween_property(head, "rotation:z", 0.9, 0.7)
    tw.tween_property(head, "position:y", 0.4, 0.7)
