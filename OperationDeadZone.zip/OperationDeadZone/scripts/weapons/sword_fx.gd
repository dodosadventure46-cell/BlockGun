extends Node3D
## Efek Pedang Iris Heart:
##   - lingkaran sihir (2 lapis, berputar berlawanan arah) melingkari bilah, muncul dengan efek "summon"
##   - api + bara menyala di sepanjang bilah, cahaya oranye berkedip di sekitarnya
##   - saat menebas: lonjakan api, percikan, dan busur tebasan api di layar
##   - saat mengenai musuh: ledakan api kecil + segel sihir yang melebar di lantai
## Dipasang oleh weapon_models.gd (anak model pedang). weapon_holder.gd memanggil bind(), on_slash(), on_hit().

const WeaponFx := preload("res://scripts/weapons/weapon_fx.gd")
const Fx := preload("res://scripts/gameplay/fx.gd")

# ---- Pengaturan (mudah diubah) ----
const HALO_SIZE := 0.36          # diameter lingkaran sihir di bilah (meter)
const HALO_SPIN := 0.55          # kecepatan putar lapisan luar (rad/detik); lapisan dalam berlawanan arah
const APPEAR_TIME := 0.5         # lama animasi lingkaran muncul saat pedang dipilih
const ARC_SIZE := 1.3            # ukuran busur tebasan di layar
const ARC_TIME := 0.34
const ARC_DELAY := 0.13          # jeda dari awal ayunan sampai busur muncul (menyesuaikan animasi ayunan)
const SIGIL_TIME := 1.0
const SIGIL_SIZE := 2.4          # diameter segel sihir di lantai
const SIGIL_POOL := 3

var halo: Node3D
var ring_mi: MeshInstance3D
var star_mi: MeshInstance3D
var ring_mat: StandardMaterial3D
var star_mat: StandardMaterial3D
var flames: CPUParticles3D
var embers: CPUParticles3D
var burst: CPUParticles3D
var light: OmniLight3D
var arc: MeshInstance3D = null
var arc_mat: StandardMaterial3D = null
var holder: Node3D = null

var t: float = 0.0
var appear_t: float = 99.0
var was_visible: bool = false
var power: float = 0.0
var arc_t: float = -1.0
var arc_delay: float = 0.0
var arc_pending: bool = false
var arc_dir: float = 1.0
var last_q: int = -1
var sigils: Array = []


## mid/axis_basis/half_len: pusat, orientasi (sumbu Z = arah bilah), dan setengah panjang bilah dalam ruang model pedang.
func build(mid: Vector3, axis_basis: Basis, half_len: float) -> void:
    var axis: Vector3 = axis_basis * Vector3(0.0, 0.0, 1.0)
    _build_halo(mid, axis)
    _build_flames(mid, axis_basis, half_len)
    light = OmniLight3D.new()
    light.name = "BladeLight"
    light.position = mid
    light.light_color = Color(1.0, 0.55, 0.2)
    light.light_energy = 0.9
    light.omni_range = 3.0
    light.shadow_enabled = false
    add_child(light)


func _build_halo(mid: Vector3, axis: Vector3) -> void:
    halo = Node3D.new()
    halo.name = "MagicCircle"
    # bidang lingkaran sedikit dimiringkan ke kamera, bilah menembus tengahnya
    var n: Vector3 = (axis * 0.55 + Vector3(0.0, 0.0, 0.85)).normalized()
    halo.basis = Basis(Quaternion(Vector3(0.0, 0.0, 1.0), n))
    halo.position = mid
    add_child(halo)
    ring_mat = WeaponFx.glow_mat("magic_ring")
    star_mat = WeaponFx.glow_mat("magic_star")
    ring_mi = WeaponFx.quad(HALO_SIZE, ring_mat)
    star_mi = WeaponFx.quad(HALO_SIZE, star_mat)
    star_mi.position = Vector3(0.0, 0.0, 0.004)
    halo.add_child(ring_mi)
    halo.add_child(star_mi)


func _particle_base(nm: String, mid: Vector3, bas: Basis, half: float, amount: int, life: float, size: float) -> CPUParticles3D:
    var p := CPUParticles3D.new()
    p.name = nm
    p.layers = 2
    p.transform = Transform3D(bas, mid)
    p.amount = maxi(4, int(float(amount) * Settings.particle_scale()))
    p.lifetime = life
    p.local_coords = false
    p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    p.emission_box_extents = Vector3(0.012, 0.01, half)
    p.direction = Vector3(0.0, 1.0, 0.0)
    p.spread = 180.0
    p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var qm := QuadMesh.new()
    qm.size = Vector2(size, size)
    qm.material = WeaponFx.glow_mat("fire_blob", Color(1, 1, 1, 1), true)
    p.mesh = qm
    return p


func _ramp(cols: Array, offs: Array) -> Gradient:
    var g := Gradient.new()
    g.colors = PackedColorArray(cols)
    g.offsets = PackedFloat32Array(offs)
    return g


func _build_flames(mid: Vector3, bas: Basis, half: float) -> void:
    # api utama: menyala di sepanjang bilah, naik ke atas (gravitasi dunia), meninggalkan jejak saat ayunan
    flames = _particle_base("Flames", mid, bas, half, 22, 0.5, 0.08)
    flames.initial_velocity_min = 0.03
    flames.initial_velocity_max = 0.16
    flames.gravity = Vector3(0.0, 1.5, 0.0)
    flames.scale_amount_min = 0.7
    flames.scale_amount_max = 1.3
    var c1 := Curve.new()
    c1.add_point(Vector2(0.0, 0.6))
    c1.add_point(Vector2(0.25, 1.0))
    c1.add_point(Vector2(1.0, 0.15))
    flames.scale_amount_curve = c1
    flames.color_ramp = _ramp(
        [Color(1.0, 0.95, 0.6, 0.0), Color(1.0, 0.75, 0.25, 0.6), Color(1.0, 0.35, 0.05, 0.45), Color(0.5, 0.08, 0.02, 0.0)],
        [0.0, 0.12, 0.55, 1.0])
    flames.emitting = true
    add_child(flames)
    # bara kecil yang melayang naik
    embers = _particle_base("Embers", mid, bas, half, 12, 0.9, 0.016)
    embers.initial_velocity_min = 0.05
    embers.initial_velocity_max = 0.3
    embers.gravity = Vector3(0.0, 0.9, 0.0)
    var c2 := Curve.new()
    c2.add_point(Vector2(0.0, 1.0))
    c2.add_point(Vector2(1.0, 0.3))
    embers.scale_amount_curve = c2
    embers.color_ramp = _ramp(
        [Color(1.0, 0.95, 0.6, 1.0), Color(1.0, 0.55, 0.12, 0.9), Color(1.0, 0.3, 0.05, 0.0)],
        [0.0, 0.4, 1.0])
    embers.emitting = true
    add_child(embers)
    # semburan api sekali pakai (saat menebas / saat pedang dipilih)
    burst = _particle_base("Burst", mid, bas, half, 30, 0.55, 0.035)
    burst.one_shot = true
    burst.explosiveness = 0.9
    burst.initial_velocity_min = 0.6
    burst.initial_velocity_max = 1.9
    burst.gravity = Vector3(0.0, 0.4, 0.0)
    burst.color_ramp = _ramp(
        [Color(1.0, 0.98, 0.7, 1.0), Color(1.0, 0.55, 0.12, 0.85), Color(0.8, 0.12, 0.02, 0.0)],
        [0.0, 0.35, 1.0])
    burst.emitting = false
    add_child(burst)


## Dipanggil weapon_holder setelah model masuk pohon: busur tebasan dipasang di ruang kamera (anak holder).
func bind(h: Node3D) -> void:
    holder = h
    arc_mat = WeaponFx.glow_mat("slash_crescent")
    arc = WeaponFx.quad(ARC_SIZE, arc_mat)
    arc.position = Vector3(0.0, -0.05, -0.8)
    arc.visible = false
    h.add_child(arc)


func _fire_burst() -> void:
    if burst == null:
        return
    burst.restart()
    burst.emitting = true


func on_slash(dir: float) -> void:
    power = 1.0
    arc_dir = 1.0 if dir >= 0.0 else -1.0
    arc_delay = ARC_DELAY
    arc_pending = true


func on_hit(pos: Vector3) -> void:
    if not is_inside_tree():
        return
    var scene: Node = get_tree().current_scene
    if scene == null:
        return
    Fx._particles(scene, "sw_fire", pos, Vector3.UP, 16, Color(1.0, 0.5, 0.12), 0.6, 1.5, 4.5, 140.0, 0.06)
    Fx._particles(scene, "sw_spark", pos, Vector3.UP, 12, Color(1.0, 0.85, 0.4), 0.5, 3.0, 8.0, 120.0, 0.015)
    var ground: Vector3 = Vector3(pos.x, pos.y - 1.1, pos.z)
    var space: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
    var q := PhysicsRayQueryParameters3D.create(pos, pos + Vector3(0.0, -3.0, 0.0), 1)
    var hit: Dictionary = space.intersect_ray(q)
    if not hit.is_empty():
        ground = hit["position"]
    _spawn_sigil(scene, ground + Vector3(0.0, 0.05, 0.0))


# ---------------------------------------------------------------- segel sihir di lantai
func _make_sigil(scene: Node) -> Dictionary:
    var root := Node3D.new()
    root.visible = false
    scene.add_child(root)
    var rm: StandardMaterial3D = WeaponFx.glow_mat("magic_ring")
    var sm: StandardMaterial3D = WeaponFx.glow_mat("magic_star")
    var pivot := Node3D.new()
    pivot.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
    root.add_child(pivot)
    var ring: MeshInstance3D = WeaponFx.quad(SIGIL_SIZE, rm, 1)
    var star: MeshInstance3D = WeaponFx.quad(SIGIL_SIZE, sm, 1)
    star.position = Vector3(0.0, 0.0, 0.004)
    pivot.add_child(ring)
    pivot.add_child(star)
    return {"node": root, "ring": ring, "star": star, "rm": rm, "sm": sm, "t": 0.0, "on": false}


func _spawn_sigil(scene: Node, pos: Vector3) -> void:
    var slot: Dictionary = {}
    for it in sigils:
        if not bool(it["on"]):
            slot = it
            break
    if slot.is_empty():
        if sigils.size() >= SIGIL_POOL:
            slot = sigils[0]
        else:
            slot = _make_sigil(scene)
            sigils.append(slot)
    var node: Node3D = slot["node"]
    if not is_instance_valid(node) or not node.is_inside_tree():
        return
    node.global_position = pos
    node.scale = Vector3.ONE * 0.5
    node.visible = true
    slot["t"] = 0.0
    slot["on"] = true


func _update_sigils(dt: float) -> void:
    for it in sigils:
        if not bool(it["on"]):
            continue
        var node: Node3D = it["node"]
        if not is_instance_valid(node):
            it["on"] = false
            continue
        var tt: float = float(it["t"]) + dt
        it["t"] = tt
        var k: float = tt / SIGIL_TIME
        if k >= 1.0:
            node.visible = false
            it["on"] = false
            continue
        var grow: float = 1.0 - pow(1.0 - minf(k * 2.5, 1.0), 3.0)
        node.scale = Vector3.ONE * lerpf(0.5, 1.0, grow)
        var a: float = minf(k * 12.0, 1.0) * (1.0 - smoothstep(0.45, 1.0, k))
        var rm: StandardMaterial3D = it["rm"]
        var sm: StandardMaterial3D = it["sm"]
        rm.albedo_color = Color(1.0, 1.0, 1.0, a)
        sm.albedo_color = Color(1.0, 1.0, 1.0, a)
        var ring: MeshInstance3D = it["ring"]
        var star: MeshInstance3D = it["star"]
        ring.rotation.z += dt * 1.4
        star.rotation.z -= dt * 2.2


# ---------------------------------------------------------------- per frame
func _process(delta: float) -> void:
    var dt: float = minf(delta, 0.05)
    _update_sigils(dt)
    var vis: bool = is_visible_in_tree()
    if not vis:
        was_visible = false
        arc_pending = false
        arc_t = -1.0
        if arc != null:
            arc.visible = false
        return
    if not was_visible:
        was_visible = true
        appear_t = 0.0
        _fire_burst()
    t += dt
    appear_t = minf(appear_t + dt, APPEAR_TIME)
    power = maxf(0.0, power - dt * 2.2)
    # kualitas efek mengikuti pengaturan grafis
    var q: int = Settings.effects_q
    if q != last_q:
        last_q = q
        embers.visible = q >= 1
        light.visible = Settings.muzzle_light_enabled()
    # lingkaran sihir: muncul (membesar dengan sedikit pantulan), berputar, berdenyut
    var k: float = appear_t / APPEAR_TIME
    var kk: float = k - 1.0
    var eb: float = 1.0 + 2.70158 * kk * kk * kk + 1.70158 * kk * kk
    var s: float = lerpf(0.15, 1.0, eb) * (1.0 + 0.16 * power)
    halo.scale = Vector3(s, s, s)
    var spin: float = HALO_SPIN * (1.0 + 2.5 * power) * dt
    ring_mi.rotation.z += spin
    star_mi.rotation.z -= spin * 1.6
    var a: float = clampf(k * 3.0, 0.0, 1.0) * (0.82 + 0.18 * sin(t * 2.6))
    ring_mat.albedo_color = Color(1.0, 1.0, 1.0, a)
    star_mat.albedo_color = Color(1.0, 1.0, 1.0, minf(1.0, a * (1.0 + 0.3 * power)))
    # api lebih ganas saat menebas
    flames.speed_scale = 1.0 + power * 0.8
    light.light_energy = 0.8 + 0.25 * sin(t * 18.0) * sin(t * 7.0) + 0.9 * power
    _update_arc(dt)


func _update_arc(dt: float) -> void:
    if arc == null:
        return
    if arc_pending:
        arc_delay -= dt
        if arc_delay <= 0.0:
            arc_pending = false
            arc_t = 0.0
            _fire_burst()
    if arc_t < 0.0:
        arc.visible = false
        return
    arc_t += dt
    var k: float = arc_t / ARC_TIME
    if k >= 1.0:
        arc_t = -1.0
        arc.visible = false
        return
    arc.visible = true
    var sc: float = lerpf(0.75, 1.2, 1.0 - pow(1.0 - k, 3.0))
    arc.scale = Vector3(sc * arc_dir, sc, 1.0)
    arc.rotation.z = deg_to_rad(24.0) * arc_dir
    arc.position = Vector3(-arc_dir * 0.12 * k, -0.05, -0.8)
    var a: float = (1.0 - k) * (1.0 - k) * minf(1.0, k * 14.0)
    arc_mat.albedo_color = Color(1.0, 1.0, 1.0, a)
