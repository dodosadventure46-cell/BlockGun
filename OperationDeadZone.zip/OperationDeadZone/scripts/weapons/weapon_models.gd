extends RefCounted
## Model senjata 3D prosedural (viewmodel). Laras mengarah ke -Z, node "Muzzle" di ujung laras.
const TexLib := preload("res://scripts/gameplay/texlib.gd")

static func _box(parent: Node3D, nm: String, size: Vector3, pos: Vector3, col: Color, rot: Vector3 = Vector3.ZERO, metal: float = 0.5, rough: float = 0.5, emit: float = 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = TexLib.flat(col, rough, emit, metal)
	mi.position = pos
	mi.rotation_degrees = rot
	mi.name = nm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi

static func _cyl(parent: Node3D, nm: String, radius: float, length: float, pos: Vector3, col: Color, emit: float = 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = length
	cm.radial_segments = 10
	mi.mesh = cm
	mi.material_override = TexLib.flat(col, 0.4, emit, 0.7)
	mi.position = pos
	mi.rotation_degrees = Vector3(90, 0, 0)
	mi.name = nm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi

static func _muzzle(parent: Node3D, pos: Vector3) -> void:
	var mk := Marker3D.new()
	mk.name = "Muzzle"
	mk.position = pos
	parent.add_child(mk)

## Lambang kalajengking (scorpion) menyala, dirakit dari kotak-kotak kecil.
## Terletak pada bidang Y-Z (menghadap sumbu -X), di posisi lokal `pos`.
static func _scorpion(parent: Node3D, pos: Vector3, s: float) -> void:
	var g := Node3D.new()
	g.position = pos
	parent.add_child(g)
	var u: float = 0.006 * s
	var col := Color(1.0, 0.12, 0.16)
	# badan (4 segmen vertikal)
	for i in 4:
		_box(g, "seg", Vector3(u * 0.5, u * 0.9, u * 0.9), Vector3(0, -u * 1.2 + float(i) * u * 0.8, 0), col, Vector3.ZERO, 0.0, 0.4, 3.0)
	# ekor melengkung ke atas
	var ty := [u * 1.6, u * 2.2, u * 2.7, u * 2.4]
	var tz := [0.0, u * 0.7, u * 1.3, u * 1.9]
	for i in 4:
		_box(g, "tail", Vector3(u * 0.5, u * 0.7, u * 0.7), Vector3(0, ty[i], tz[i]), col, Vector3.ZERO, 0.0, 0.4, 3.0)
	# penyengat
	_box(g, "stinger", Vector3(u * 0.65, u * 0.85, u * 0.85), Vector3(0, u * 2.9, u * 2.3), col, Vector3.ZERO, 0.0, 0.4, 4.5)
	# capit kiri & kanan
	for side in [-1.0, 1.0]:
		_box(g, "arm1", Vector3(u * 0.5, u * 0.6, u * 1.0), Vector3(0, u * 0.5, side * u * 1.0), col, Vector3.ZERO, 0.0, 0.4, 3.0)
		_box(g, "arm2", Vector3(u * 0.5, u * 0.6, u * 0.8), Vector3(0, u * 1.1, side * u * 1.7), col, Vector3.ZERO, 0.0, 0.4, 3.0)
		_box(g, "pincer_a", Vector3(u * 0.4, u * 0.5, u * 0.5), Vector3(0, u * 1.45, side * u * 2.1), col, Vector3.ZERO, 0.0, 0.4, 3.0)
		_box(g, "pincer_b", Vector3(u * 0.4, u * 0.5, u * 0.5), Vector3(0, u * 0.75, side * u * 2.1), col, Vector3.ZERO, 0.0, 0.4, 3.0)
	# kaki (3 pasang)
	for side in [-1.0, 1.0]:
		for i in 3:
			_box(g, "leg", Vector3(u * 0.4, u * 0.4, u * 0.6), Vector3(0, -u * 0.6 + float(i) * u * 0.5, side * u * 0.9), col, Vector3.ZERO, 0.0, 0.4, 2.5)

static func build(id: int) -> Node3D:
	var root := Node3D.new()
	root.name = "Weapon%d" % id
	var gun := Color(0.14, 0.15, 0.16)
	var dark := Color(0.06, 0.06, 0.07)
	var olive := Color(0.2, 0.24, 0.15)
	var wood := Color(0.33, 0.2, 0.1)
	var glove := Color(0.05, 0.05, 0.05)
	var accent := Color(0.95, 0.5, 0.1)
	if id == 0:
		# ===== SCAR-H "SCORPION" — skin merah metalik + hitam, aksen merah menyala =====
		var red := Color(0.76, 0.06, 0.09)        # candy red metalik
		var red_dark := Color(0.48, 0.04, 0.06)   # red lebih gelap
		var black := Color(0.05, 0.05, 0.06)      # hitam matte
		var black_g := Color(0.09, 0.09, 0.11)    # hitam gloss
		var glow := Color(1.0, 0.12, 0.16)        # aksen merah menyala
		# receiver atas + bawah (badan utama merah)
		_box(root, "Receiver", Vector3(0.072, 0.09, 0.36), Vector3(0, 0.015, 0.0), red, Vector3.ZERO, 0.85, 0.25)
		_box(root, "Lower", Vector3(0.068, 0.10, 0.30), Vector3(0, -0.045, 0.03), red_dark, Vector3.ZERO, 0.7, 0.35)
		# rail atas penuh (hitam)
		_box(root, "Rail", Vector3(0.045, 0.016, 0.44), Vector3(0, 0.068, -0.02), black_g, Vector3.ZERO, 0.6, 0.35)
		# magwell
		_box(root, "Magwell", Vector3(0.062, 0.05, 0.10), Vector3(0, -0.095, -0.01), black, Vector3.ZERO, 0.3, 0.6)
		# magasin (nama HARUS "Mag" untuk animasi reload)
		var mag: MeshInstance3D = _box(root, "Mag", Vector3(0.046, 0.18, 0.072), Vector3(0, -0.20, -0.02), black, Vector3(12, 0, 0), 0.3, 0.6)
		# lambang scorpion menyala di sisi magasin (menghadap -X, sisi yang terlihat)
		_scorpion(mag, Vector3(-0.026, 0.01, 0.0), 1.0)
		# grip pistol
		_box(root, "Grip", Vector3(0.042, 0.12, 0.055), Vector3(0, -0.13, 0.15), black, Vector3(-16, 0, 0), 0.3, 0.6)
		_box(root, "TriggerGuard", Vector3(0.05, 0.012, 0.06), Vector3(0, -0.095, 0.08), black, Vector3.ZERO, 0.3, 0.6)
		_box(root, "Trigger", Vector3(0.012, 0.04, 0.012), Vector3(0, -0.085, 0.08), black_g, Vector3(-8, 0, 0), 0.6, 0.35)
		# handguard merah dengan slot rail di sisi
		_box(root, "Handguard", Vector3(0.078, 0.085, 0.30), Vector3(0, 0.01, -0.32), red, Vector3.ZERO, 0.85, 0.25)
		for z in [-0.22, -0.32, -0.42]:
			_box(root, "SideRail", Vector3(0.004, 0.05, 0.04), Vector3(-0.041, 0.01, z), black_g, Vector3.ZERO, 0.6, 0.35)
			_box(root, "MLok", Vector3(0.003, 0.012, 0.05), Vector3(-0.040, -0.015, z), Color(0.02, 0.02, 0.03), Vector3.ZERO, 0.0, 0.8)
		# foregrip vertikal (hitam) dengan cincin merah di pangkal
		_box(root, "Foregrip", Vector3(0.042, 0.11, 0.045), Vector3(0, -0.085, -0.33), black, Vector3(6, 0, 0), 0.3, 0.6)
		_box(root, "ForegripRing", Vector3(0.044, 0.006, 0.047), Vector3(0, -0.035, -0.33), glow, Vector3.ZERO, 0.0, 0.4, 3.0)
		# gas block + laras
		_box(root, "GasBlock", Vector3(0.05, 0.04, 0.05), Vector3(0, 0.01, -0.47), black, Vector3.ZERO, 0.3, 0.6)
		_cyl(root, "Barrel", 0.012, 0.20, Vector3(0, 0.01, -0.57), black)
		# muzzle brake + cincin aksen merah menyala
		_cyl(root, "Brake", 0.019, 0.08, Vector3(0, 0.01, -0.71), black_g)
		_box(root, "BrakePort", Vector3(0.006, 0.012, 0.02), Vector3(-0.020, 0.01, -0.71), Color(0.02, 0.02, 0.03), Vector3.ZERO, 0.0, 0.8)
		_cyl(root, "MuzzleRing", 0.0205, 0.008, Vector3(0, 0.01, -0.67), glow, 3.0)
		# red-dot sight di rail atas (badan hitam, lensa merah menyala)
		_box(root, "RDSRiser", Vector3(0.04, 0.018, 0.06), Vector3(0, 0.085, -0.05), black_g, Vector3.ZERO, 0.6, 0.35)
		_box(root, "RDS", Vector3(0.052, 0.05, 0.075), Vector3(0, 0.115, -0.05), black_g, Vector3.ZERO, 0.6, 0.35)
		_box(root, "RDSDot", Vector3(0.007, 0.007, 0.007), Vector3(0, 0.115, -0.082), glow, Vector3.ZERO, 0.0, 0.3, 5.0)
		# sight cadangan
		_box(root, "RearSight", Vector3(0.03, 0.025, 0.02), Vector3(0, 0.088, 0.13), black, Vector3.ZERO, 0.3, 0.6)
		_box(root, "FrontSight", Vector3(0.02, 0.015, 0.02), Vector3(0, 0.078, -0.45), black, Vector3.ZERO, 0.3, 0.6)
		# charging handle di sisi (-X)
		_box(root, "ChargingHandle", Vector3(0.02, 0.035, 0.05), Vector3(-0.048, 0.03, 0.02), black_g, Vector3.ZERO, 0.6, 0.35)
		# lambang scorpion kecil di lower receiver
		_scorpion(root, Vector3(-0.037, -0.045, 0.02), 0.7)
		# stock skeleton khas SCAR (hitam + aksen merah menyala)
		_box(root, "StockTube", Vector3(0.06, 0.07, 0.06), Vector3(0, 0.0, 0.20), black, Vector3.ZERO, 0.3, 0.6)
		_box(root, "StockStrutTop", Vector3(0.05, 0.025, 0.18), Vector3(0, 0.035, 0.30), black, Vector3.ZERO, 0.3, 0.6)
		_box(root, "StockStrutBot", Vector3(0.05, 0.025, 0.18), Vector3(0, -0.03, 0.30), black, Vector3.ZERO, 0.3, 0.6)
		_box(root, "CheekRest", Vector3(0.05, 0.03, 0.10), Vector3(0, 0.06, 0.28), black, Vector3.ZERO, 0.3, 0.6)
		_box(root, "ButtPad", Vector3(0.065, 0.13, 0.045), Vector3(0, 0.0, 0.41), black_g, Vector3(2, 0, 0), 0.6, 0.35)
		_box(root, "StockGlowTop", Vector3(0.004, 0.012, 0.16), Vector3(-0.028, 0.035, 0.30), glow, Vector3.ZERO, 0.0, 0.4, 3.0)
		_box(root, "StockGlowBot", Vector3(0.004, 0.012, 0.16), Vector3(-0.028, -0.03, 0.30), glow, Vector3.ZERO, 0.0, 0.4, 3.0)
		# sarung tangan
		_box(root, "GloveL", Vector3(0.07, 0.07, 0.10), Vector3(0, -0.13, -0.33), glove, Vector3.ZERO, 0.0, 0.9)
		_box(root, "GloveR", Vector3(0.06, 0.08, 0.07), Vector3(0, -0.16, 0.15), glove, Vector3.ZERO, 0.0, 0.9)
		_muzzle(root, Vector3(0, 0.01, -0.76))
	elif id == 1:
		_box(root, "Slide", Vector3(0.036, 0.042, 0.2), Vector3(0, 0.02, -0.05), gun)
		_box(root, "Frame", Vector3(0.033, 0.03, 0.18), Vector3(0, -0.012, -0.04), dark)
		_cyl(root, "Barrel", 0.009, 0.04, Vector3(0, 0.02, -0.16), dark)
		_box(root, "FrontSight", Vector3(0.006, 0.014, 0.008), Vector3(0, 0.048, -0.14), dark)
		_box(root, "SightDot", Vector3(0.005, 0.005, 0.005), Vector3(0, 0.056, -0.14), accent, Vector3.ZERO, 0.0, 0.5)
		_box(root, "RearSight", Vector3(0.02, 0.012, 0.01), Vector3(0, 0.048, 0.04), dark)
		_box(root, "Grip", Vector3(0.034, 0.1, 0.05), Vector3(0, -0.07, 0.04), dark, Vector3(12, 0, 0))
		_box(root, "Mag", Vector3(0.028, 0.08, 0.04), Vector3(0, -0.1, 0.045), gun, Vector3(12, 0, 0))
		_box(root, "GloveR", Vector3(0.06, 0.07, 0.07), Vector3(0, -0.06, 0.05), glove, Vector3.ZERO, 0.0, 0.9)
		_box(root, "GloveL", Vector3(0.06, 0.06, 0.08), Vector3(-0.03, -0.09, 0.05), glove, Vector3.ZERO, 0.0, 0.9)
		_muzzle(root, Vector3(0, 0.02, -0.18))
	else:
		_box(root, "Receiver", Vector3(0.06, 0.09, 0.28), Vector3(0, 0, 0), gun)
		_cyl(root, "Barrel", 0.02, 0.6, Vector3(0, 0.02, -0.45), dark)
		_cyl(root, "Tube", 0.016, 0.45, Vector3(0, -0.025, -0.38), gun)
		_box(root, "Pump", Vector3(0.05, 0.05, 0.16), Vector3(0, -0.025, -0.35), wood, Vector3.ZERO, 0.0, 0.8)
		_box(root, "Stock", Vector3(0.055, 0.1, 0.28), Vector3(0, -0.02, 0.27), wood, Vector3(8, 0, 0), 0.0, 0.8)
		_box(root, "Grip", Vector3(0.04, 0.1, 0.05), Vector3(0, -0.09, 0.1), dark, Vector3(-12, 0, 0))
		_box(root, "Mag", Vector3(0.05, 0.03, 0.08), Vector3(0, -0.06, 0.0), dark)
		_box(root, "FrontSight", Vector3(0.008, 0.02, 0.008), Vector3(0, 0.045, -0.74), dark)
		_box(root, "SightDot", Vector3(0.006, 0.006, 0.006), Vector3(0, 0.057, -0.74), accent, Vector3.ZERO, 0.0, 0.5)
		_box(root, "GloveL", Vector3(0.07, 0.07, 0.1), Vector3(0, -0.04, -0.36), glove, Vector3.ZERO, 0.0, 0.9)
		_box(root, "GloveR", Vector3(0.06, 0.08, 0.07), Vector3(0, -0.095, 0.1), glove, Vector3.ZERO, 0.0, 0.9)
		_muzzle(root, Vector3(0, 0.02, -0.76))
	for nm in ["Mag", "Pump"]:
		var n: Node3D = root.get_node_or_null(nm)
		if n != null:
			n.set_meta("base", n.position)
	return root
