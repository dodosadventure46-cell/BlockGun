extends RefCounted
## Model senjata 3D prosedural (viewmodel). Laras mengarah ke -Z, node "Muzzle" di ujung laras.

const TexLib := preload("res://scripts/gameplay/texlib.gd")


static func _box(parent: Node3D, nm: String, size: Vector3, pos: Vector3, col: Color, rot: Vector3 = Vector3.ZERO, metal: float = 0.5, rough: float = 0.5) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = TexLib.flat(col, rough, 0.0, metal)
    mi.position = pos
    mi.rotation_degrees = rot
    mi.name = nm
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi


static func _cyl(parent: Node3D, nm: String, radius: float, length: float, pos: Vector3, col: Color) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = length
    cm.radial_segments = 10
    mi.mesh = cm
    mi.material_override = TexLib.flat(col, 0.4, 0.0, 0.7)
    mi.position = pos
    mi.rotation_degrees = Vector3(90, 0, 0)
    mi.name = nm
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi


static func _muzzle(parent: Node3D, pos: Vector3) -> void:
    var mk := Marker3D.new()
    mk.name = "Muzzle"
    mk.position = pos
    parent.add_child(mk)


static func build(id: int) -> Node3D:
    var root := Node3D.new()
    root.name = "Weapon%d" % id
    var gun := Color(0.14, 0.15, 0.16)
    var dark := Color(0.06, 0.06, 0.07)
    var olive := Color(0.2, 0.24, 0.15)
    var wood := Color(0.33, 0.2, 0.1)
    var glove := Color(0.05, 0.05, 0.05)
    var accent := Color(0.95, 0.5, 0.1)
    if id == 0:
        _box(root, "Receiver", Vector3(0.06, 0.085, 0.34), Vector3(0, 0, 0), gun)
        _box(root, "Rail", Vector3(0.035, 0.018, 0.28), Vector3(0, 0.05, -0.02), dark)
        _cyl(root, "Barrel", 0.011, 0.34, Vector3(0, 0.012, -0.45), dark)
        _box(root, "Handguard", Vector3(0.064, 0.07, 0.26), Vector3(0, 0, -0.28), olive, Vector3.ZERO, 0.1, 0.8)
        _cyl(root, "Brake", 0.016, 0.06, Vector3(0, 0.012, -0.64), dark)
        _box(root, "FrontSight", Vector3(0.008, 0.04, 0.008), Vector3(0, 0.055, -0.55), dark)
        _box(root, "SightDot", Vector3(0.006, 0.006, 0.006), Vector3(0, 0.076, -0.55), accent, Vector3.ZERO, 0.0, 0.5)
        _box(root, "RearSight", Vector3(0.03, 0.03, 0.02), Vector3(0, 0.058, 0.1), dark)
        _box(root, "Stock", Vector3(0.055, 0.1, 0.22), Vector3(0, -0.01, 0.27), olive, Vector3.ZERO, 0.1, 0.8)
        _box(root, "Grip", Vector3(0.04, 0.11, 0.05), Vector3(0, -0.095, 0.12), dark, Vector3(-15, 0, 0))
        _box(root, "Mag", Vector3(0.04, 0.15, 0.07), Vector3(0, -0.12, -0.04), dark, Vector3(8, 0, 0))
        _box(root, "GloveL", Vector3(0.07, 0.07, 0.11), Vector3(0, -0.05, -0.3), glove, Vector3.ZERO, 0.0, 0.9)
        _box(root, "GloveR", Vector3(0.06, 0.08, 0.07), Vector3(0, -0.1, 0.12), glove, Vector3.ZERO, 0.0, 0.9)
        _muzzle(root, Vector3(0, 0.012, -0.68))
    elif id == 1:
        _box(root, "Slide", Vector3(0.036, 0.042, 0.2), Vector3(0, 0.02, -0.05), gun)
        _box(root, "Frame", Vector3(0.033, 0.03, 0.18), Vector3(0, -0.012, -0.04), dark)
        _cyl(root, "Barrel", 0.009, 0.04, Vector3(0, 0.02, -0.16), dark)
        _box(root, "FrontSight", Vector3(0.006, 0.014, 0.008), Vector3(0, 0.048, -0.14), dark)
        _box(root, "SightDot", Vector3(0.005, 0.005, 0.005), Vector3(0, 0.056, -0.14), accent, Vector3.ZERO, 0.0, 0.5)
        _box(root, "RearSight", Vector3(0.02, 0.012, 0.01), Vector3(0, 0.048, 0.04), dark)
        _box(root, "Grip", Vector3(0.034, 0.1, 0.05), Vector3(0, -0.07, 0.04), dark, Vector3(12, 0, 0))
        _box(root, "Mag", Vector3(0.028, 0.08, 0.04), Vector3(0, -0.1, 0.045), gun, Vector3(12, 0, 0))
        _box(root, "GloveR", Vector3(0.06, 0.07, 0.07), Vector3(0, -0.06, 0.05), glove, Vector3.ZERO, 0.0, 0.9)
        _box(root, "GloveL", Vector3(0.06, 0.06, 0.08), Vector3(-0.03, -0.09, 0.05), glove, Vector3.ZERO, 0.0, 0.9)
        _muzzle(root, Vector3(0, 0.02, -0.18))
    else:
        _box(root, "Receiver", Vector3(0.06, 0.09, 0.28), Vector3(0, 0, 0), gun)
        _cyl(root, "Barrel", 0.02, 0.6, Vector3(0, 0.02, -0.45), dark)
        _cyl(root, "Tube", 0.016, 0.45, Vector3(0, -0.025, -0.38), gun)
        _box(root, "Pump", Vector3(0.05, 0.05, 0.16), Vector3(0, -0.025, -0.35), wood, Vector3.ZERO, 0.0, 0.8)
        _box(root, "Stock", Vector3(0.055, 0.1, 0.28), Vector3(0, -0.02, 0.27), wood, Vector3(8, 0, 0), 0.0, 0.8)
        _box(root, "Grip", Vector3(0.04, 0.1, 0.05), Vector3(0, -0.09, 0.1), dark, Vector3(-12, 0, 0))
        _box(root, "Mag", Vector3(0.05, 0.03, 0.08), Vector3(0, -0.06, 0.0), dark)
        _box(root, "FrontSight", Vector3(0.008, 0.02, 0.008), Vector3(0, 0.045, -0.74), dark)
        _box(root, "SightDot", Vector3(0.006, 0.006, 0.006), Vector3(0, 0.057, -0.74), accent, Vector3.ZERO, 0.0, 0.5)
        _box(root, "GloveL", Vector3(0.07, 0.07, 0.1), Vector3(0, -0.04, -0.36), glove, Vector3.ZERO, 0.0, 0.9)
        _box(root, "GloveR", Vector3(0.06, 0.08, 0.07), Vector3(0, -0.095, 0.1), glove, Vector3.ZERO, 0.0, 0.9)
        _muzzle(root, Vector3(0, 0.02, -0.76))
    for nm in ["Mag", "Pump"]:
        var n: Node3D = root.get_node_or_null(nm)
        if n != null:
            n.set_meta("base", n.position)
    return root
