extends RefCounted
## Model senjata 3D prosedural (viewmodel) dengan material berbeda: baja, polimer, karet, kayu, kuningan.
## Laras mengarah ke -Z. Node "Muzzle" di ujung laras, "Eject" di jendela ejeksi.

const TexLib := preload("res://scripts/gameplay/texlib.gd")
const SwordFx := preload("res://scripts/weapons/sword_fx.gd")
const WeaponFx := preload("res://scripts/weapons/weapon_fx.gd")


static func _mat(kind: String) -> StandardMaterial3D:
    match kind:
        "steel":
            return TexLib.flat(Color(0.16, 0.17, 0.18), 0.32, 0.0, 0.9)
        "dark_steel":
            return TexLib.flat(Color(0.07, 0.07, 0.08), 0.38, 0.0, 0.9)
        "poly":
            return TexLib.flat(Color(0.09, 0.1, 0.1), 0.7, 0.0, 0.05)
        "olive":
            return TexLib.flat(Color(0.2, 0.24, 0.15), 0.72, 0.0, 0.05)
        "rubber":
            return TexLib.flat(Color(0.03, 0.03, 0.03), 0.95, 0.0, 0.0)
        "wood":
            return TexLib.flat(Color(0.33, 0.2, 0.1), 0.55, 0.0, 0.0)
        "brass":
            return TexLib.flat(Color(0.75, 0.55, 0.2), 0.35, 0.0, 1.0)
        "red":
            return TexLib.flat(Color(0.7, 0.1, 0.08), 0.5, 0.0, 0.0)
        "dot":
            return TexLib.flat(Color(0.95, 0.5, 0.1), 0.5, 2.5, 0.0)
        _:
            return TexLib.flat(Color(0.1, 0.1, 0.1), 0.6, 0.0, 0.3)


static func _box(parent: Node3D, nm: String, size: Vector3, pos: Vector3, kind: String, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = _mat(kind)
    mi.position = pos
    mi.rotation_degrees = rot
    mi.name = nm
    mi.layers = 2
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi


static func _cyl(parent: Node3D, nm: String, radius: float, length: float, pos: Vector3, kind: String, axis_z: bool = true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = length
    cm.radial_segments = 12
    mi.mesh = cm
    mi.material_override = _mat(kind)
    mi.position = pos
    if axis_z:
        mi.rotation_degrees = Vector3(90, 0, 0)
    mi.name = nm
    mi.layers = 2
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi


static func _marker(parent: Node3D, nm: String, pos: Vector3) -> void:
    var mk := Marker3D.new()
    mk.name = nm
    mk.position = pos
    parent.add_child(mk)


static func build(id: int) -> Node3D:
    var root := Node3D.new()
    root.name = "Weapon%d" % id
    if id == 0:
        _build_rifle(root)
    elif id == 1:
        _build_pistol(root)
    elif id == 2:
        _build_shotgun(root)
    else:
        _build_sword(root)
    for nm in ["Mag", "Pump"]:
        var n: Node3D = root.get_node_or_null(nm)
        if n != null:
            n.set_meta("base", n.position)
    WeaponFx.setup_heat(root, id)
    return root


static func _build_rifle(r: Node3D) -> void:
    _box(r, "Receiver", Vector3(0.06, 0.085, 0.34), Vector3(0, 0, 0), "steel")
    _box(r, "UpperRec", Vector3(0.056, 0.03, 0.3), Vector3(0, 0.05, -0.02), "dark_steel")
    _box(r, "Rail", Vector3(0.034, 0.014, 0.3), Vector3(0, 0.07, -0.05), "dark_steel")
    for i in 6:
        _box(r, "RailTooth%d" % i, Vector3(0.036, 0.008, 0.012), Vector3(0, 0.08, 0.08 - i * 0.046), "dark_steel")
    _box(r, "EjectPort", Vector3(0.004, 0.03, 0.07), Vector3(0.031, 0.02, -0.03), "dark_steel")
    _box(r, "ChargeHandle", Vector3(0.03, 0.012, 0.03), Vector3(0, 0.062, 0.14), "steel")
    _cyl(r, "Barrel", 0.011, 0.34, Vector3(0, 0.012, -0.45), "dark_steel")
    _box(r, "Handguard", Vector3(0.066, 0.072, 0.26), Vector3(0, 0, -0.28), "olive")
    for i in 4:
        _box(r, "HGVent%d" % i, Vector3(0.068, 0.012, 0.03), Vector3(0, 0.02, -0.2 - i * 0.05), "dark_steel")
    _cyl(r, "Brake", 0.016, 0.06, Vector3(0, 0.012, -0.64), "dark_steel")
    _box(r, "BrakeSlot", Vector3(0.034, 0.006, 0.03), Vector3(0, 0.012, -0.64), "poly")
    _box(r, "FrontSight", Vector3(0.008, 0.04, 0.008), Vector3(0, 0.055, -0.55), "dark_steel")
    _box(r, "SightDot", Vector3(0.006, 0.006, 0.006), Vector3(0, 0.076, -0.55), "dot")
    _box(r, "RearSight", Vector3(0.03, 0.03, 0.02), Vector3(0, 0.07, 0.1), "dark_steel")
    _box(r, "Stock", Vector3(0.055, 0.1, 0.22), Vector3(0, -0.01, 0.27), "olive")
    _box(r, "CheekPad", Vector3(0.05, 0.02, 0.12), Vector3(0, 0.046, 0.28), "rubber")
    _box(r, "ButtPad", Vector3(0.058, 0.11, 0.025), Vector3(0, -0.01, 0.39), "rubber")
    _box(r, "Grip", Vector3(0.04, 0.11, 0.05), Vector3(0, -0.095, 0.12), "rubber", Vector3(-15, 0, 0))
    _box(r, "TriggerGuard", Vector3(0.012, 0.02, 0.07), Vector3(0, -0.05, 0.03), "steel")
    _box(r, "Trigger", Vector3(0.008, 0.03, 0.01), Vector3(0, -0.04, 0.04), "dark_steel", Vector3(15, 0, 0))
    _box(r, "Mag", Vector3(0.04, 0.15, 0.07), Vector3(0, -0.12, -0.04), "poly", Vector3(8, 0, 0))
    _box(r, "MagBase", Vector3(0.042, 0.012, 0.074), Vector3(0, -0.19, -0.025), "dark_steel", Vector3(8, 0, 0))
    _box(r, "GloveL", Vector3(0.07, 0.07, 0.11), Vector3(0, -0.05, -0.3), "rubber")
    _box(r, "GloveR", Vector3(0.06, 0.08, 0.07), Vector3(0, -0.1, 0.12), "rubber")
    _marker(r, "Muzzle", Vector3(0, 0.012, -0.68))
    _marker(r, "Eject", Vector3(0.035, 0.02, -0.03))


static func _build_pistol(r: Node3D) -> void:
    _box(r, "Slide", Vector3(0.036, 0.042, 0.2), Vector3(0, 0.02, -0.05), "steel")
    for i in 5:
        _box(r, "Serration%d" % i, Vector3(0.038, 0.034, 0.006), Vector3(0, 0.022, 0.0 + i * 0.012), "dark_steel")
    _box(r, "EjectPort", Vector3(0.004, 0.02, 0.05), Vector3(0.019, 0.03, -0.07), "dark_steel")
    _box(r, "Frame", Vector3(0.033, 0.03, 0.18), Vector3(0, -0.012, -0.04), "poly")
    _cyl(r, "Barrel", 0.009, 0.04, Vector3(0, 0.02, -0.16), "dark_steel")
    _box(r, "FrontSight", Vector3(0.006, 0.014, 0.008), Vector3(0, 0.048, -0.14), "dark_steel")
    _box(r, "SightDot", Vector3(0.005, 0.005, 0.005), Vector3(0, 0.056, -0.14), "dot")
    _box(r, "RearSight", Vector3(0.02, 0.012, 0.01), Vector3(0, 0.048, 0.04), "dark_steel")
    _box(r, "Hammer", Vector3(0.01, 0.018, 0.016), Vector3(0, 0.036, 0.06), "dark_steel")
    _box(r, "Grip", Vector3(0.034, 0.1, 0.05), Vector3(0, -0.07, 0.04), "poly", Vector3(12, 0, 0))
    _box(r, "GripPanel", Vector3(0.037, 0.07, 0.034), Vector3(0, -0.07, 0.042), "rubber", Vector3(12, 0, 0))
    _box(r, "TriggerGuard", Vector3(0.012, 0.016, 0.06), Vector3(0, -0.035, -0.04), "poly")
    _box(r, "Trigger", Vector3(0.007, 0.022, 0.008), Vector3(0, -0.028, -0.03), "dark_steel", Vector3(12, 0, 0))
    _box(r, "Mag", Vector3(0.028, 0.08, 0.04), Vector3(0, -0.1, 0.045), "steel", Vector3(12, 0, 0))
    _box(r, "MagBase", Vector3(0.032, 0.01, 0.046), Vector3(0, -0.14, 0.055), "poly", Vector3(12, 0, 0))
    _box(r, "GloveR", Vector3(0.06, 0.07, 0.07), Vector3(0, -0.06, 0.05), "rubber")
    _box(r, "GloveL", Vector3(0.06, 0.06, 0.08), Vector3(-0.03, -0.09, 0.05), "rubber")
    _marker(r, "Muzzle", Vector3(0, 0.02, -0.18))
    _marker(r, "Eject", Vector3(0.02, 0.03, -0.06))


static func _build_shotgun(r: Node3D) -> void:
    _box(r, "Receiver", Vector3(0.06, 0.09, 0.28), Vector3(0, 0, 0), "steel")
    _box(r, "LoadPort", Vector3(0.05, 0.012, 0.07), Vector3(0, -0.046, -0.04), "dark_steel")
    _box(r, "EjectPort", Vector3(0.004, 0.035, 0.08), Vector3(0.031, 0.015, -0.03), "dark_steel")
    _cyl(r, "Barrel", 0.02, 0.6, Vector3(0, 0.02, -0.45), "dark_steel")
    _box(r, "HeatShield", Vector3(0.03, 0.012, 0.32), Vector3(0, 0.046, -0.5), "poly")
    _cyl(r, "Tube", 0.016, 0.45, Vector3(0, -0.025, -0.38), "steel")
    _cyl(r, "TubeCap", 0.019, 0.02, Vector3(0, -0.025, -0.6), "dark_steel")
    _box(r, "Pump", Vector3(0.05, 0.05, 0.16), Vector3(0, -0.025, -0.35), "wood")
    for i in 4:
        _box(r, "PumpGroove%d" % i, Vector3(0.052, 0.052, 0.008), Vector3(0, -0.025, -0.31 - i * 0.03), "dark_steel")
    _box(r, "Stock", Vector3(0.055, 0.1, 0.28), Vector3(0, -0.02, 0.27), "wood", Vector3(8, 0, 0))
    _box(r, "ButtPad", Vector3(0.058, 0.11, 0.025), Vector3(0, -0.035, 0.41), "rubber", Vector3(8, 0, 0))
    for i in 3:
        _cyl(r, "Shell%d" % i, 0.009, 0.045, Vector3(0.033, -0.01 + i * 0.0, 0.2 + i * 0.022), "red", false)
    _box(r, "Grip", Vector3(0.04, 0.1, 0.05), Vector3(0, -0.09, 0.1), "rubber", Vector3(-12, 0, 0))
    _box(r, "TriggerGuard", Vector3(0.012, 0.018, 0.07), Vector3(0, -0.05, 0.03), "steel")
    _box(r, "Mag", Vector3(0.05, 0.03, 0.08), Vector3(0, -0.06, 0.0), "dark_steel")
    _box(r, "FrontSight", Vector3(0.008, 0.02, 0.008), Vector3(0, 0.05, -0.74), "dark_steel")
    _box(r, "SightDot", Vector3(0.006, 0.006, 0.006), Vector3(0, 0.062, -0.74), "dot")
    _box(r, "GloveL", Vector3(0.07, 0.07, 0.1), Vector3(0, -0.04, -0.36), "rubber")
    _box(r, "GloveR", Vector3(0.06, 0.08, 0.07), Vector3(0, -0.095, 0.1), "rubber")
    _marker(r, "Muzzle", Vector3(0, 0.02, -0.76))
    _marker(r, "Eject", Vector3(0.035, 0.015, -0.03))


const SWORD_PATH := "res://assets/models/iris_heart_sword.glb"
## Posisi bilah di ruang model .glb (bilah mengarah +Z). Dipakai untuk memasang api dan lingkaran sihir.
## Jika efek terlihat bergeser dari bilah, ubah tiga angka ini.
const BLADE_X := -0.047
const BLADE_Z0 := 0.25
const BLADE_Z1 := 1.2


## Pedang melee dari model pengguna (.glb). Bilah di model mengarah +Z; dibungkus agar mengarah ke atas-depan.
## Jika model gagal dimuat, dipakai pedang prosedural sederhana sebagai cadangan.
static func _build_sword(r: Node3D) -> void:
    var wrap := Node3D.new()
    wrap.name = "SwordWrap"
    wrap.rotation_degrees = Vector3(-108.0, 10.0, 0.0)
    wrap.scale = Vector3(0.4, 0.4, 0.4)
    wrap.position = Vector3(0.0, 0.0, 0.0)
    r.add_child(wrap)
    var packed = load(SWORD_PATH)
    if packed is PackedScene:
        var inst: Node = packed.instantiate()
        wrap.add_child(inst)
        _tune_sword(inst)
    else:
        push_warning("Model pedang tidak dapat dimuat, memakai bentuk cadangan")
        _fallback_blade(wrap)
    # efek: lingkaran sihir + api di bilah (lihat sword_fx.gd)
    var fx = SwordFx.new()
    fx.name = "SwordFx"
    r.add_child(fx)
    var mid: Vector3 = wrap.transform * Vector3(BLADE_X, 0.0, (BLADE_Z0 + BLADE_Z1) * 0.5)
    var bb: Basis = wrap.transform.basis.orthonormalized()
    var half: float = (BLADE_Z1 - BLADE_Z0) * 0.5 * wrap.scale.z
    fx.build(mid, bb, half)


static func _fallback_blade(wrap: Node3D) -> void:
    var blade := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.08, 0.02, 1.0)
    blade.mesh = bm
    blade.material_override = _mat("steel")
    blade.position = Vector3(0, 0, 0.7)
    blade.layers = 2
    wrap.add_child(blade)
    var guard := MeshInstance3D.new()
    var gm := BoxMesh.new()
    gm.size = Vector3(0.28, 0.04, 0.05)
    guard.mesh = gm
    guard.material_override = _mat("brass")
    guard.layers = 2
    wrap.add_child(guard)


static func _tune_sword(n: Node) -> void:
    if n is MeshInstance3D:
        var mi: MeshInstance3D = n
        mi.layers = 2
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        mi.extra_cull_margin = 2.0
        if mi.mesh != null:
            for i in mi.mesh.get_surface_count():
                var mat = mi.mesh.surface_get_material(i)
                if mat is BaseMaterial3D and mat.emission_enabled:
                    # glow bawaan model terlalu terang (strength 10) -> diturunkan agar tidak silau
                    var dup: BaseMaterial3D = mat.duplicate()
                    dup.emission_energy_multiplier = 1.6
                    mi.set_surface_override_material(i, dup)
    for c in n.get_children():
        _tune_sword(c)
