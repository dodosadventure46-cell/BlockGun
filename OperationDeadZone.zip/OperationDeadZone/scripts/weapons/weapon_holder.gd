extends Node3D
## Sistem senjata: magasin, cadangan, hitscan, recoil pegas, reload, ganti senjata,
## selongsong peluru, dan sistem animasi viewmodel berbasis state:
##   IDLE / WALK / SPRINT / ADS / FIRE / RELOAD / SWITCH
## Prioritas pose: SWITCH > RELOAD > ADS > FIRE > SPRINT > WALK > IDLE.

const Fx := preload("res://scripts/gameplay/fx.gd")
const TexLib := preload("res://scripts/gameplay/texlib.gd")
const WeaponModels := preload("res://scripts/weapons/weapon_models.gd")

signal hit_confirmed(headshot: bool, killed: bool)

enum S { IDLE, RELOADING, SWITCHING }

const DEFS := [
    {"title": "AR-7 KARABIN", "is_auto": true, "mag": 30, "reserve": 150, "damage": 24.0, "rate": 0.095, "spread": 0.020, "recoil": 0.010, "reload": 2.1, "dist": 140.0, "sound": "shot_rifle", "pellets": 1, "zoom": 22.0, "noise": 55.0, "kick": 0.035, "hip": Vector3(0.2, -0.2, -0.42), "ads": Vector3(0.0, -0.082, -0.30), "casing": true, "melee": false, "raise": 1.0, "short": "AR-7"},
    {"title": "P9 PISTOL", "is_auto": false, "mag": 12, "reserve": 72, "damage": 40.0, "rate": 0.2, "spread": 0.012, "recoil": 0.016, "reload": 1.5, "dist": 120.0, "sound": "shot_pistol", "pellets": 1, "zoom": 12.0, "noise": 38.0, "kick": 0.05, "hip": Vector3(0.17, -0.17, -0.38), "ads": Vector3(0.0, -0.058, -0.27), "casing": true, "melee": false, "raise": 1.0, "short": "P9"},
    {"title": "S12 SHOTGUN", "is_auto": false, "mag": 6, "reserve": 36, "damage": 13.0, "rate": 0.85, "spread": 0.055, "recoil": 0.045, "reload": 2.6, "dist": 50.0, "sound": "shot_shotgun", "pellets": 9, "zoom": 8.0, "noise": 62.0, "kick": 0.09, "hip": Vector3(0.2, -0.2, -0.4), "ads": Vector3(0.0, -0.066, -0.30), "casing": false, "melee": false, "raise": 1.0, "short": "S12"},
    {"title": "PEDANG IRIS HEART", "is_auto": true, "mag": 0, "reserve": 0, "damage": 70.0, "rate": 0.6, "spread": 0.0, "recoil": 0.0, "reload": 0.0, "dist": 2.6, "sound": "swish", "pellets": 0, "zoom": 0.0, "noise": 12.0, "kick": 0.0, "hip": Vector3(0.3, -0.34, -0.5), "ads": Vector3(0.3, -0.34, -0.5), "casing": false, "melee": true, "raise": 0.35, "short": "PEDANG"}
]

var player = null
var vm: Node3D
var models: Array = []
var ammo: Array = []
var reserve: Array = []
var cur: int = 0
var state: int = S.IDLE
var state_t: float = 0.0
var state_dur: float = 1.0
var cooldown: float = 0.0
var buffer_t: float = 0.0
var aiming: bool = false
var aim_t: float = 0.0
var pump_t: float = 0.0
var flash: Node3D
var flash_light: OmniLight3D
var flash_t: float = 0.0
var switch_to: int = 0
var swapped: bool = false

# --- sistem animasi ---
var walk_w: float = 0.0
var sprint_w: float = 0.0
var act_w: float = 0.0
var lat_w: float = 0.0
var fire_t: float = 0.0
var bob_phase: float = 0.0
var breath: float = 0.0
var sway: Vector2 = Vector2.ZERO
var rec_rot: float = 0.0
var rec_rot_v: float = 0.0
var rec_pos: float = 0.0
var rec_pos_v: float = 0.0
var force_speed: float = -1.0
var anim_state: String = "IDLE"

# --- selongsong peluru (pool, simulasi ringan tanpa fisika engine) ---
var casings: Array = []
var casing_i: int = 0

# --- melee ---
var slash_t: float = 0.0
var slash_dur: float = 0.5
var slash_dir: float = 1.0
var slash_hit_done: bool = true


func setup(p) -> void:
    player = p
    vm = Node3D.new()
    add_child(vm)
    for i in DEFS.size():
        var m: Node3D = WeaponModels.build(i)
        vm.add_child(m)
        m.visible = false
        models.append(m)
        ammo.append(int(DEFS[i]["mag"]))
        reserve.append(int(DEFS[i]["reserve"]))
    flash = Node3D.new()
    flash.visible = false
    add_child(flash)
    flash.add_child(Fx.flash_mesh(0.28))
    flash_light = OmniLight3D.new()
    flash_light.light_color = Color(1.0, 0.75, 0.4)
    flash_light.light_energy = 2.0
    flash_light.omni_range = 7.0
    flash_light.shadow_enabled = false
    flash.add_child(flash_light)
    _show_current()
    vm.position = DEFS[0]["hip"]


func _show_current() -> void:
    for i in models.size():
        models[i].visible = (i == cur)


func weapon_def() -> Dictionary:
    return DEFS[cur]


func weapon_title() -> String:
    return str(DEFS[cur]["title"])


func mag_ammo() -> int:
    return int(ammo[cur])


func reserve_ammo() -> int:
    return int(reserve[cur])


func is_reloading() -> bool:
    return state == S.RELOADING


func spread_amount() -> float:
    var sp: float = float(DEFS[cur]["spread"])
    if aiming:
        sp *= 0.35
    if player != null:
        sp += Vector2(player.velocity.x, player.velocity.z).length() * 0.0015
    return sp


func is_melee() -> bool:
    return bool(DEFS[cur].get("melee", false))


## Slot yang sedang dipilih (target bila sedang berganti senjata).
func selected_slot() -> int:
    if state == S.SWITCHING:
        return switch_to
    return cur


func slot_count() -> int:
    return DEFS.size()


func slot_short(i: int) -> String:
    return str(DEFS[i]["short"])


func slot_ammo_text(i: int) -> String:
    if bool(DEFS[i].get("melee", false)):
        return "-"
    return "%d" % int(ammo[i])


func anim_state_name() -> String:
    return anim_state


func _process(delta: float) -> void:
    if player == null:
        return
    var c = player.controls
    cooldown = maxf(0.0, cooldown - delta)
    buffer_t = maxf(0.0, buffer_t - delta)
    fire_t = maxf(0.0, fire_t - delta)
    _update_slash(delta)
    if flash_t > 0.0:
        flash_t -= delta
        var mz: Node3D = models[cur].get_node_or_null("Muzzle")
        if mz != null:
            flash.global_position = mz.global_position
        if flash_t <= 0.0:
            flash.visible = false
    if player.alive and c != null:
        _handle_input(c)
    else:
        aiming = false
    _update_state(delta)
    var want_aim: float = 0.0
    if aiming and state != S.SWITCHING:
        want_aim = 1.0
    aim_t = move_toward(aim_t, want_aim, delta * 7.0)
    player.camera.fov = lerpf(75.0, 75.0 - float(DEFS[cur]["zoom"]), aim_t)
    _animate(delta)
    _update_casings(delta)


func _handle_input(c) -> void:
    var w: Dictionary = DEFS[cur]
    var req: int = c.consume_slot()
    if req < 0:
        if Input.is_key_pressed(KEY_1):
            req = 0
        elif Input.is_key_pressed(KEY_2):
            req = 1
        elif Input.is_key_pressed(KEY_3):
            req = 2
        elif Input.is_key_pressed(KEY_4):
            req = 3
    if req >= 0:
        select_slot(req)
    if c.consume("reload"):
        start_reload()
    var pressed: bool = c.consume("fire_edge")
    if pressed:
        buffer_t = 0.2
    if bool(w.get("melee", false)):
        c.aim_on = false
        aiming = false
        if state == S.IDLE and cooldown <= 0.0 and slash_t <= 0.0 and (c.fire_held or buffer_t > 0.0):
            _slash()
            buffer_t = 0.0
        return
    aiming = c.aim_on
    if state == S.IDLE and cooldown <= 0.0:
        var wants: bool = (bool(w["is_auto"]) and c.fire_held) or buffer_t > 0.0
        if wants:
            if int(ammo[cur]) > 0:
                _shoot()
                buffer_t = 0.0
            else:
                if buffer_t > 0.0:
                    SFX.play("empty")
                    buffer_t = 0.0
                if int(reserve[cur]) > 0:
                    start_reload()


func _update_state(delta: float) -> void:
    if state == S.IDLE:
        return
    state_t -= delta
    if state == S.SWITCHING and not swapped and state_t <= state_dur * 0.5:
        cur = switch_to
        swapped = true
        _show_current()
    if state_t <= 0.0:
        if state == S.RELOADING:
            _finish_reload()
        state = S.IDLE


func _spread_dir(spread: float) -> Vector3:
    var b: Basis = player.camera.global_transform.basis
    var sp: float = spread
    if aiming:
        sp *= 0.35
    sp += Vector2(player.velocity.x, player.velocity.z).length() * 0.0015
    var dir: Vector3 = -b.z + b.x * randf_range(-sp, sp) + b.y * randf_range(-sp, sp)
    return dir.normalized()


func _shoot() -> void:
    var w: Dictionary = DEFS[cur]
    ammo[cur] = int(ammo[cur]) - 1
    cooldown = float(w["rate"])
    SFX.play(str(w["sound"]), -1.0, randf_range(0.96, 1.04))
    get_tree().call_group("enemies", "hear_noise", player.global_position, float(w["noise"]))
    var cam: Camera3D = player.camera
    var origin: Vector3 = cam.global_position
    var space: PhysicsDirectSpaceState3D = player.get_world_3d().direct_space_state
    var scene: Node = get_tree().current_scene
    var mz: Node3D = models[cur].get_node_or_null("Muzzle")
    var mpos: Vector3 = origin
    if mz != null:
        mpos = mz.global_position
    var rng_d: float = float(w["dist"])
    for i in int(w["pellets"]):
        var dir: Vector3 = _spread_dir(float(w["spread"]))
        var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * rng_d, 5, [player.get_rid()])
        var hit: Dictionary = space.intersect_ray(q)
        var endp: Vector3 = origin + dir * rng_d
        if not hit.is_empty():
            endp = hit["position"]
            var col = hit["collider"]
            if col != null and col.has_method("take_damage"):
                var dist: float = origin.distance_to(endp)
                var dmg: float = float(w["damage"]) * clampf(1.0 - (dist / rng_d) * 0.6, 0.3, 1.0)
                var head: bool = col.has_method("is_head_hit") and col.is_head_hit(endp)
                if head:
                    dmg *= 2.2
                col.take_damage(dmg, head, player.global_position)
                SFX.play("hit", -6.0)
                hit_confirmed.emit(head, col.health <= 0.0)
            else:
                Fx.impact(scene, endp, hit["normal"])
                SFX.play_at("impact", endp, -6.0, randf_range(0.9, 1.2))
        if i < 3:
            Fx.tracer(scene, mpos, endp, Color(1.0, 0.9, 0.55), 0.012, 0.05)
    player.kick(float(w["recoil"]) * (1.0 - 0.35 * aim_t))
    # recoil viewmodel (pegas teredam), lebih kecil saat ADS
    var ads_f: float = 1.0 - 0.45 * aim_t
    rec_rot_v += float(w["kick"]) * 45.0 * ads_f
    rec_pos_v += float(w["kick"]) * 14.0 * ads_f
    fire_t = 0.18
    pump_t = 1.0
    flash.visible = true
    flash_t = 0.05
    flash.scale = Vector3.ONE * randf_range(0.8, 1.3)
    flash_light.visible = Settings.muzzle_light_enabled()
    if bool(w["casing"]) and Settings.casings_enabled():
        _eject_casing(scene)


func start_reload() -> void:
    var w: Dictionary = DEFS[cur]
    if state != S.IDLE or int(ammo[cur]) >= int(w["mag"]) or int(reserve[cur]) <= 0:
        return
    state = S.RELOADING
    state_dur = float(w["reload"])
    state_t = state_dur
    SFX.play("reload", -2.0)


func _finish_reload() -> void:
    var w: Dictionary = DEFS[cur]
    var need: int = int(w["mag"]) - int(ammo[cur])
    var take: int = mini(need, int(reserve[cur]))
    ammo[cur] = int(ammo[cur]) + take
    reserve[cur] = int(reserve[cur]) - take


func select_slot(i: int) -> void:
    if i < 0 or i >= DEFS.size():
        return
    if state == S.SWITCHING and not swapped:
        switch_to = i
        return
    if i == selected_slot():
        return
    switch_to = i
    slash_t = 0.0
    state = S.SWITCHING
    state_dur = 0.5
    state_t = 0.5
    swapped = false
    SFX.play("switch", -3.0)


func switch_next() -> void:
    if state == S.SWITCHING:
        return
    switch_to = (cur + 1) % DEFS.size()
    slash_t = 0.0
    state = S.SWITCHING
    state_dur = 0.5
    state_t = 0.5
    swapped = false
    SFX.play("switch", -3.0)


func add_ammo() -> void:
    for i in DEFS.size():
        reserve[i] = int(reserve[i]) + int(DEFS[i]["mag"]) * 2


func snapshot() -> Dictionary:
    return {"ammo": ammo.duplicate(), "reserve": reserve.duplicate(), "cur": cur}


func restore(snap: Dictionary) -> void:
    if snap.has("ammo"):
        ammo = snap["ammo"].duplicate()
        reserve = snap["reserve"].duplicate()
        cur = int(snap["cur"])
        _show_current()


func smoke_test() -> void:
    ## Uji asap CI: jalankan jalur kode senjata + animasi (jalan, ADS, tembak, reload, ganti).
    force_speed = 5.4
    for k in 20:
        _animate(0.016)
    print("SMOKE: anim=", anim_state, " walk_w=", snappedf(walk_w, 0.01))
    aiming = true
    aim_t = 1.0
    for k2 in 10:
        _animate(0.016)
    print("SMOKE: anim=", anim_state)
    aiming = false
    aim_t = 0.0
    _shoot()
    for k3 in 6:
        _animate(0.016)
    print("SMOKE: anim=", anim_state)
    start_reload()
    for k4 in 10:
        state_t -= 0.1
        _animate(0.016)
    print("SMOKE: anim=", anim_state)
    state_t = 0.0
    _update_state(0.01)
    select_slot(3)
    state_t = 0.0
    _update_state(0.01)
    print("SMOKE: slot=", cur, " melee=", is_melee())
    _slash()
    for k5 in 40:
        _update_slash(0.016)
        _animate(0.016)
    print("SMOKE: anim=", anim_state)
    select_slot(0)
    state_t = 0.0
    _update_state(0.01)
    cooldown = 0.0
    force_speed = -1.0


# ---------------------------------------------------------------- melee
func _slash() -> void:
    var w: Dictionary = DEFS[cur]
    cooldown = float(w["rate"])
    slash_dur = 0.5
    slash_t = slash_dur
    slash_dir = -slash_dir
    slash_hit_done = false
    SFX.play("swish", -2.0, randf_range(0.9, 1.1))
    get_tree().call_group("enemies", "hear_noise", player.global_position, float(w["noise"]))


func _update_slash(delta: float) -> void:
    if slash_t <= 0.0:
        return
    slash_t = maxf(0.0, slash_t - delta)
    var k: float = 1.0 - slash_t / slash_dur
    if not slash_hit_done and k >= 0.42:
        slash_hit_done = true
        _slash_hit()


func _slash_hit() -> void:
    var w: Dictionary = DEFS[cur]
    var cam: Camera3D = player.camera
    var origin: Vector3 = cam.global_position
    var fwd: Vector3 = -cam.global_transform.basis.z
    var reach: float = float(w["dist"])
    var space: PhysicsDirectSpaceState3D = player.get_world_3d().direct_space_state
    var hit_any: bool = false
    for e in get_tree().get_nodes_in_group("enemies"):
        var en = e
        var chest: Vector3 = en.global_position + Vector3(0, 1.1, 0)
        var to: Vector3 = chest - origin
        var d: float = to.length()
        if d > reach + 0.6:
            continue
        if fwd.dot(to / maxf(d, 0.001)) < 0.35:
            continue
        var q := PhysicsRayQueryParameters3D.create(origin, chest, 1, [player.get_rid()])
        if not space.intersect_ray(q).is_empty():
            continue
        var dmg: float = float(w["damage"])
        var efwd: Vector3 = -en.global_transform.basis.z
        if efwd.dot(fwd) > 0.5:
            dmg *= 2.0
        en.take_damage(dmg, false, player.global_position)
        hit_any = true
        hit_confirmed.emit(false, en.health <= 0.0)
    if hit_any:
        SFX.play("impact", -2.0, randf_range(0.6, 0.8))
        player.add_shake(0.25, player.global_position)


# ---------------------------------------------------------------- animasi
func _animate(delta: float) -> void:
    var dt: float = minf(delta, 0.033)
    var w: Dictionary = DEFS[cur]
    var hip: Vector3 = w["hip"]
    var adsp: Vector3 = w["ads"]
    var vel := Vector3(player.velocity.x, 0.0, player.velocity.z)
    var spd: float = vel.length()
    var grounded: bool = player.is_on_floor()
    if force_speed >= 0.0:
        spd = force_speed
        grounded = true
        vel = Vector3(0, 0, -force_speed)
    # --- bobot state (interpolasi halus, tidak berubah mendadak) ---
    var walk_t: float = clampf(spd / 5.4, 0.0, 1.0) if grounded else 0.0
    var rate_w: float = 5.0 if walk_t > walk_w else 3.2
    walk_w = lerpf(walk_w, walk_t, 1.0 - exp(-rate_w * dt))
    var sprint_t: float = 1.0 if (player.sprinting and grounded and spd > 3.0) else 0.0
    sprint_w = lerpf(sprint_w, sprint_t, 1.0 - exp(-6.0 * dt))
    var act_t: float = 1.0 if (state != S.IDLE or slash_t > 0.0) else 0.0
    act_w = lerpf(act_w, act_t, 1.0 - exp(-10.0 * dt))
    var ads: float = aim_t
    var fire_w: float = clampf(fire_t / 0.18, 0.0, 1.0)
    var freew: float = (1.0 - ads) * (1.0 - act_w * 0.85)
    # --- pose dasar (hip -> ADS) ---
    var pos: Vector3 = hip.lerp(adsp, ads)
    var rot := Vector3.ZERO
    # --- pose senjata terangkat saat berjalan/berlari (muzzle ke atas) ---
    var rz: float = float(w.get("raise", 1.0))
    var raise: float = walk_w * freew * rz
    var sprint_extra: float = sprint_w * freew * rz
    pos.y += 0.04 * raise + 0.02 * sprint_extra
    pos.z += 0.012 * raise
    rot.x += 0.17 * raise + 0.12 * sprint_extra
    # --- bobbing berbasis delta time & kecepatan ---
    var amp: float = walk_w * (1.0 - 0.88 * ads) * (1.0 - 0.6 * act_w) * (1.0 - 0.4 * fire_w) * (1.0 + 0.9 * sprint_w)
    bob_phase += dt * spd * 1.45 * (1.0 + 0.35 * sprint_w)
    pos.y += sin(bob_phase * 2.0) * 0.0085 * amp
    pos.x += sin(bob_phase) * 0.011 * amp
    rot.z += sin(bob_phase) * 0.03 * amp
    rot.x += sin(bob_phase * 2.0 + 0.6) * 0.012 * amp
    # --- napas saat diam ---
    breath += dt
    var calm: float = (1.0 - walk_w) * (1.0 - 0.7 * ads)
    pos.y += sin(breath * 1.6) * 0.0015 * calm
    rot.x += sin(breath * 1.6 + 1.0) * 0.003 * calm
    # --- mengikuti arah gerak (strafe) ---
    var right_v: float = 0.0
    if force_speed < 0.0:
        right_v = vel.dot(player.camera.global_transform.basis.x)
    lat_w = lerpf(lat_w, clampf(right_v / 5.4, -1.0, 1.0), 1.0 - exp(-6.0 * dt))
    var lat_f: float = 1.0 - ads * 0.8
    rot.z += -lat_w * 0.045 * lat_f
    pos.x += -lat_w * 0.010 * lat_f
    # --- inersia saat kamera diputar ---
    var look: Vector2 = player.look_delta
    var sway_t: Vector2 = Vector2(-look.x, look.y) * 0.00035
    sway_t = sway_t.limit_length(0.03)
    sway = sway.lerp(sway_t, 1.0 - exp(-10.0 * dt))
    var sf: float = 1.0 - ads * 0.7
    pos.x += sway.x * sf
    rot.y += sway.x * 1.2 * sf
    pos.y += sway.y * sf
    rot.x += -sway.y * sf
    # --- recoil: pegas teredam yang selalu kembali ke pose awal ---
    rec_rot_v += (-220.0 * rec_rot - 20.0 * rec_rot_v) * dt
    rec_rot += rec_rot_v * dt
    rec_pos_v += (-220.0 * rec_pos - 20.0 * rec_pos_v) * dt
    rec_pos += rec_pos_v * dt
    pos.z += rec_pos
    rot.x += rec_rot
    # --- reload / ganti senjata (prioritas tertinggi, menimpa pose jalan) ---
    var model: Node3D = models[cur]
    var mag: Node3D = model.get_node_or_null("Mag")
    var pump: Node3D = model.get_node_or_null("Pump")
    if mag != null:
        mag.position = mag.get_meta("base")
    if state == S.RELOADING:
        var k: float = 1.0 - state_t / state_dur
        var lowered: float = smoothstep(0.0, 0.2, k) * (1.0 - smoothstep(0.8, 1.0, k))
        pos.y -= lowered * 0.07
        rot.x -= lowered * 0.35
        rot.z += lowered * 0.35
        if mag != null:
            var out: float = smoothstep(0.2, 0.4, k) * (1.0 - smoothstep(0.55, 0.7, k))
            mag.position = Vector3(mag.get_meta("base")) + Vector3(0, -out * 0.16, 0)
    elif state == S.SWITCHING:
        var k2: float = 1.0 - state_t / state_dur
        var low: float = 1.0 - absf(k2 * 2.0 - 1.0)
        pos.y -= low * 0.3
        rot.x -= low * 0.9
    if slash_t > 0.0:
        var ks: float = 1.0 - slash_t / slash_dur
        var u: float = 0.0
        if ks < 0.3:
            u = -smoothstep(0.0, 0.3, ks)
        elif ks < 0.55:
            u = lerpf(-1.0, 1.0, smoothstep(0.3, 0.55, ks))
        else:
            u = lerpf(1.0, 0.0, smoothstep(0.55, 1.0, ks))
        pos.x += -slash_dir * u * 0.28
        pos.y += -u * 0.12
        pos.z += -maxf(u, 0.0) * 0.18
        rot.z += slash_dir * u * 1.1
        rot.x += -u * 0.5
        rot.y += slash_dir * u * 0.6
    pump_t = move_toward(pump_t, 0.0, dt * 2.5)
    if pump != null:
        pump.position = Vector3(pump.get_meta("base")) + Vector3(0, 0, 0.12 * sin(pump_t * PI))
    vm.position = pos
    vm.rotation = rot
    # --- nama state (prioritas) ---
    if state == S.SWITCHING:
        anim_state = "SWITCH"
    elif state == S.RELOADING:
        anim_state = "RELOAD"
    elif slash_t > 0.0:
        anim_state = "SLASH"
    elif ads > 0.5:
        anim_state = "ADS"
    elif fire_t > 0.0:
        anim_state = "FIRE"
    elif sprint_w > 0.5:
        anim_state = "SPRINT"
    elif walk_w > 0.2:
        anim_state = "WALK"
    else:
        anim_state = "IDLE"


# ---------------------------------------------------------------- selongsong
func _eject_casing(scene: Node) -> void:
    var ep: Node3D = models[cur].get_node_or_null("Eject")
    if ep == null or scene == null:
        return
    if casings.size() < 10:
        var mi := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(0.012, 0.012, 0.04)
        mi.mesh = bm
        mi.material_override = TexLib.flat(Color(0.75, 0.55, 0.2), 0.35, 0.0, 1.0)
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        mi.visible = false
        scene.add_child(mi)
        casings.append({"n": mi, "v": Vector3.ZERO, "t": 0.0, "rest": false})
    var item: Dictionary = casings[casing_i % casings.size()]
    casing_i += 1
    var n: MeshInstance3D = item["n"]
    if not is_instance_valid(n) or not n.is_inside_tree():
        return
    var b: Basis = player.camera.global_transform.basis
    n.global_position = ep.global_position
    n.global_rotation = Vector3(randf() * TAU, randf() * TAU, randf() * TAU)
    n.visible = true
    item["v"] = b.x * randf_range(1.5, 2.4) + b.y * randf_range(1.2, 2.0) + b.z * randf_range(0.0, 0.5) + player.velocity * 0.4
    item["t"] = 0.0
    item["rest"] = false


func _update_casings(delta: float) -> void:
    for item in casings:
        var n: MeshInstance3D = item["n"]
        if not is_instance_valid(n) or not n.visible:
            continue
        item["t"] = float(item["t"]) + delta
        if bool(item["rest"]):
            if float(item["t"]) > 4.0:
                n.visible = false
            continue
        var v: Vector3 = item["v"]
        v.y -= 9.8 * delta
        n.global_position += v * delta
        n.rotate_x(8.0 * delta)
        n.rotate_z(5.0 * delta)
        item["v"] = v
        if n.global_position.y <= 0.02:
            n.global_position.y = 0.02
            item["rest"] = true
            item["t"] = 0.0
            if Settings.casings_enabled():
                SFX.play_at("step", n.global_position, -22.0, 2.4)
