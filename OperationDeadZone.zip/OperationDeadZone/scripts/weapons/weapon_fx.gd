extends RefCounted
## Efek visual senjata (selain efek pedang yang ada di sword_fx.gd):
##   - kilat moncong berbentuk bintang (berputar acak tiap tembakan, ukuran beda per senjata)
##   - percikan api + kepulan asap di moncong
##   - laras menyala merah saat ditembak terus (panas, mendingin perlahan)
##   - warna tracer berbeda per senjata
## Tekstur memakai PNG di res://assets/textures/fx/ (dibuat sekali, tanpa shader, jadi aman di semua perangkat).

const Fx := preload("res://scripts/gameplay/fx.gd")

const TEX_DIR := "res://assets/textures/fx/"

## Urutan sama dengan DEFS di weapon_holder.gd: 0 AR-7, 1 P9, 2 S12, 3 Pedang.
const GUN := [
    {"flash": 1.0, "sparks": 6, "smoke": 1, "heat": 0.07, "tint": Color(1.0, 0.82, 0.5), "parts": ["Barrel", "Brake"]},
    {"flash": 0.7, "sparks": 4, "smoke": 1, "heat": 0.16, "tint": Color(1.0, 0.92, 0.65), "parts": ["Barrel", "Slide"]},
    {"flash": 1.9, "sparks": 12, "smoke": 2, "heat": 0.42, "tint": Color(1.0, 0.62, 0.28), "parts": ["Barrel"]},
    {"flash": 0.0, "sparks": 0, "smoke": 0, "heat": 0.0, "tint": Color(1.0, 1.0, 1.0), "parts": []}
]

const TRACER_COLORS := [
    Color(1.0, 0.85, 0.45),
    Color(1.0, 0.95, 0.7),
    Color(1.0, 0.55, 0.2),
    Color(1.0, 0.5, 0.15)
]

static var _tex: Dictionary = {}


# ---------------------------------------------------------------- tekstur & material
static func tex(nm: String) -> Texture2D:
    if _tex.has(nm):
        return _tex[nm]
    var t = load(TEX_DIR + nm + ".png")
    if t is Texture2D:
        _tex[nm] = t
        return t
    push_warning("Tekstur efek tidak ditemukan: " + nm)
    var fb: Texture2D = _fallback_tex()
    _tex[nm] = fb
    return fb


static func _fallback_tex() -> Texture2D:
    var g := Gradient.new()
    g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
    g.offsets = PackedFloat32Array([0.0, 1.0])
    var t := GradientTexture2D.new()
    t.gradient = g
    t.fill = GradientTexture2D.FILL_RADIAL
    t.fill_from = Vector2(0.5, 0.5)
    t.fill_to = Vector2(1.0, 0.5)
    t.width = 64
    t.height = 64
    return t


## Material cahaya aditif tanpa bayangan. Untuk partikel pakai particle = true
## (billboard menghadap kamera + warna partikel ikut dipakai).
static func glow_mat(tex_name: String, tint: Color = Color(1, 1, 1, 1), particle: bool = false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
    m.albedo_texture = tex(tex_name)
    m.albedo_color = tint
    if particle:
        m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
        m.billboard_keep_scale = true
        m.vertex_color_use_as_albedo = true
    return m


static func quad(size: float, mat: Material, layer: int = 2) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2(size, size)
    mi.mesh = qm
    mi.material_override = mat
    mi.layers = layer
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    return mi


# ---------------------------------------------------------------- kilat moncong
## Bintang kilat non-billboard: node induknya (flash) anak kamera, jadi otomatis menghadap kamera.
static func muzzle_flash_mesh(size: float) -> MeshInstance3D:
    var m: StandardMaterial3D = glow_mat("muzzle_star")
    var q: MeshInstance3D = quad(size, m, 1)
    q.set_meta("mat", m)
    return q


# ---------------------------------------------------------------- percikan & asap moncong
static func muzzle_burst(scene: Node, pos: Vector3, fwd: Vector3, id: int) -> void:
    if scene == null or id < 0 or id >= GUN.size():
        return
    var g: Dictionary = GUN[id]
    var n: int = int(g["sparks"])
    if n <= 0:
        return
    Fx._particles(scene, "mz_spark", pos, fwd, n, Color(1.0, 0.82, 0.45), 0.22, 2.5, 7.0, 16.0, 0.01)
    if Settings.effects_q >= 1 and id == 2:
        Fx._particles(scene, "mz_fire", pos, fwd, 8, Color(1.0, 0.5, 0.15), 0.18, 1.5, 4.0, 22.0, 0.035)
    if Settings.effects_q >= 2:
        _muzzle_smoke(scene, pos, fwd, int(g["smoke"]))


static func _muzzle_smoke(scene: Node, pos: Vector3, fwd: Vector3, count: int) -> void:
    var res: Array = Fx._get_pool_node(scene, "p_mz_smoke", 5)
    var p: CPUParticles3D = res[0]
    if res[1]:
        Fx._smoke_setup(p, 0.35, 0.9, 0.5, Color(0.55, 0.55, 0.55))
        p.one_shot = true
        p.explosiveness = 0.9
    p.amount = 2 + count * 2
    p.direction = fwd
    p.global_position = pos
    p.restart()
    p.emitting = true


# ---------------------------------------------------------------- panas laras
## Laras/slide diberi material sendiri (salinan) supaya bisa menyala tanpa mengubah senjata lain.
static func setup_heat(model: Node3D, id: int) -> void:
    if id < 0 or id >= GUN.size():
        return
    var dups: Dictionary = {}
    var out: Array = []
    for nm in GUN[id]["parts"]:
        var node: Node = model.get_node_or_null(str(nm))
        var mesh := node as MeshInstance3D
        if mesh == null:
            continue
        var src = mesh.material_override
        if not (src is StandardMaterial3D):
            continue
        var key: int = src.get_instance_id()
        if not dups.has(key):
            var d: StandardMaterial3D = src.duplicate()
            d.emission_enabled = true
            d.emission = Color(1.0, 0.33, 0.05)
            d.emission_energy_multiplier = 0.0
            dups[key] = d
            out.append(d)
        mesh.material_override = dups[key]
    model.set_meta("heat_mats", out)


static func set_heat(model: Node3D, heat: float) -> void:
    var arr: Array = model.get_meta("heat_mats", [])
    var e: float = clampf(heat, 0.0, 1.0) * 3.0
    for m in arr:
        m.emission_energy_multiplier = e
