# Operation: Dead Zone

FPS 3D single-player untuk Android (ARM64), dibuat dengan **Godot 4.3** (GDScript, renderer *Mobile*).
Satu misi lengkap di kota industri terbengkalai **Vesper**. Semua aset (tekstur, model, suara, musik) dibuat
secara prosedural lewat kode, jadi tidak ada file aset eksternal dan tidak ada masalah lisensi.

## Cara mengunggah ke GitHub dan membangun APK

1. Buat repository baru di GitHub (kosong).
2. Ekstrak `OperationDeadZone.zip`. Unggah **isi folder `OperationDeadZone/`** (bukan folder pembungkusnya)
   ke root repository, termasuk folder tersembunyi `.github`.
   - Lewat web: *Add file -> Upload files*, seret semua isi folder. Pastikan `.github/workflows/android-build.yml` ikut.
     (Jika folder tersembunyi tidak terlihat di file manager, aktifkan "tampilkan file tersembunyi".)
   - Lewat git: `git init && git add -A && git commit -m "Operation Dead Zone" && git branch -M main && git remote add origin <URL> && git push -u origin main`.
3. Push ke branch `main`/`master` otomatis menjalankan workflow. Manual: tab **Actions -> Build Android APK -> Run workflow**.
4. Setelah hijau (sekitar 10-20 menit pertama kali), buka run tersebut -> bagian **Artifacts** ->
   unduh **OperationDeadZone-APK** (zip berisi `OperationDeadZone.apk`). Ekstrak, kirim ke HP, install
   (izinkan "pasang dari sumber tidak dikenal").
5. Jika build gagal, unduh artifact **build-logs** (`import.log`, `smoke.log`, `export.log`).

APK yang dihasilkan adalah build *debug* yang ditandatangani debug keystore otomatis (dibuat di CI), jadi langsung bisa dipasang.

### Opsi workflow
- `STRICT_SMOKE: "true"` (di `android-build.yml`): job gagal bila uji asap menemukan error script.
  Ubah ke `"false"` jika hanya ingin APK walau ada peringatan.
- Versi Godot dipatok `4.3-stable` (engine + export template sama). Jangan ubah sebagian saja.

## Cara bermain
- **Joystick kiri**: sentuh di mana saja di sisi kiri layar, geser untuk berjalan.
- **Kamera**: geser jari di sisi kanan (atau geser dari tombol TEMBAK sambil menembak).
- Tombol: TEMBAK, BIDIK (toggle), ISI (reload), LOMPAT, II (pause).
- **Slot senjata** di tepi kanan layar (ketuk untuk langsung memilih, menampilkan sisa amunisi): 1 AR-7 Karabin (otomatis), 2 P9 Pistol, 3 S12 Shotgun, 4 Pedang Iris Heart (melee). Di desktop: tombol 1-4.
- Pedang: tombol TEMBAK menebas (arah kiri-kanan bergantian). Kena musuh di depan dalam jarak ~2,6 m; tebasan dari belakang musuh damage x2. Tidak bisa membidik.
- Misi: (1) habisi musuh di alun-alun -> checkpoint 1, (2) masuk gudang pabrik dan berdiri dekat generator
  6 detik -> checkpoint 2 + bala bantuan, (3) capai helikopter ekstraksi.
- Pickup hijau/putih (HP) dan olive (amunisi) tersebar di peta dan kadang dijatuhkan musuh.
- Tombol Back Android / keluar dari aplikasi membuka menu jeda.

## Grafis (v1.1)
Preset dan pengaturan terpisah di Pengaturan (menu utama dan menu jeda). Semua tersimpan di `user://settings.cfg`
dan dipulihkan saat game dibuka lagi. Mengubah satu opsi manual menandai preset sebagai "Kustom".

| Preset | Render scale | Bayangan | Tekstur | Efek | Jarak | AA | Adaptif |
|---|---|---|---|---|---|---|---|
| Smooth | 70% | mati | 64px | minimal | 45 m | mati | ya |
| Medium | 85% | sederhana (2 split, 35 m) | 128px + roughness | rendah | 70 m | mati | ya |
| High | 100% | baik (2 split, 60 m, atlas 2048) | 256px + roughness + normal map | sedang | 110 m | FXAA | tidak |
| Ultra | 100% | terbaik (4 split, 90 m, atlas 4096) | 512px PBR | tinggi (bloom, asap, dekal 60) | 170 m | MSAA 2x | tidak |

Pengaturan terpisah: Target FPS (30/45/60 via `Engine.max_fps`), Render Scale (0.5-1.0), Bayangan, Tekstur, Efek,
Jarak Pandang, Anti-Aliasing (mati/FXAA/MSAA 2x/MSAA 4x), Motion Blur, V-Sync, Grafis Adaptif.
- **Adaptif**: `perf.gd` menurunkan render scale bila FPS < 85% target dan menaikkannya lagi saat stabil.
- **Motion blur**: shader layar (`scripts/ui/motion_blur.gd`) berbasis kecepatan putar kamera; mati secara default.
- Ukuran tekstur berlaku saat misi dimulai/diulang. Bayangan, AA, render scale, efek, dan jarak pandang berubah langsung.
- Ambient occlusion (SSAO) **tidak tersedia** di renderer Mobile Godot, jadi tidak dipasang.
- Occlusion culling manual tidak dipakai (risiko objek hilang di dalam bangunan); yang dipakai: frustum culling bawaan,
  `visibility_range` per mesh, dan LOD sederhana (objek kecil hilang di separuh jarak pandang).

## Animasi senjata (v1.1)
`scripts/weapons/weapon_holder.gd` memakai sistem state: IDLE, WALK, SPRINT, ADS, FIRE, RELOAD, SWITCH
dengan prioritas SWITCH > RELOAD > ADS > FIRE > SPRINT > WALK > IDLE.
- Saat berjalan senjata terangkat perlahan (laras ke atas ~10 derajat + naik sedikit) dan kembali halus saat berhenti.
- Bobbing naik-turun + goyang kiri-kanan + roll berbasis delta time dan kecepatan; lebih kuat saat sprint,
  hampir hilang saat ADS, dikurangi saat reload.
- Sprint: dorong joystick ke tepi (arah depan) tanpa membidik/menembak; kecepatan x1.35.
- ADS menimpa pose jalan, posisi bidik per senjata. Reload punya fase turun, magasin lepas-masuk, kembali.
- Recoil pegas teredam (selalu kembali ke posisi awal), inersia saat kamera diputar, tilt saat strafe, napas saat diam.
- Selongsong peluru (pool 10) untuk karabin dan pistol, muzzle flash + lampu moncong (efek >= Rendah).

## Pedang melee (v1.2)
Model `assets/models/iris_heart_sword.glb` (dari berkas yang dikirim pengguna) dimuat lewat `weapon_models.gd`.
Material glow bawaan model diturunkan intensitasnya agar tidak silau. Jika model gagal dimuat, dipakai pedang
cadangan sederhana dan peringatan dicetak di log. Skala (0.4), rotasi, dan posisi pegangan mungkin perlu disetel
setelah dicoba di perangkat (`_build_sword` dan `hip` pedang di `weapon_holder.gd`).
Pastikan kamu punya hak untuk memakai dan membagikan model tersebut.

## Efek dan lingkungan (v1.1)
- Material PBR (roughness map + normal map hasil `bump_map_to_normal_map`) pada beton, bata, aspal, logam, kayu.
- Dekal retak/noda/hangus (hingga 60, tergantung kualitas efek), bekas peluru (maksimum 40, didaur ulang).
- Tong merah meledak saat ditembak: api, percikan, asap, cahaya singkat, guncangan kamera, damage area
  ke musuh/pemain/tong lain, noda hangus.
- Kolom asap di beberapa titik (efek >= Sedang). Partikel impact, darah, ledakan memakai pool.
- Model senjata lebih detail (rail, ventilasi, jendela ejeksi, serration, grip karet, material baja/polimer/kayu).

## Struktur
```
project.godot, export_presets.cfg, icon.svg
.github/workflows/android-build.yml
scenes/    main (menu), player, enemies, levels (vesper), weapons, ui
scripts/   player, enemies, gameplay (level, map, misi, audio, tekstur, efek), weapons, ui
assets/    kosong (semua aset dibuat prosedural)
```

## Catatan jujur
- Proyek ini ditulis tanpa bisa menjalankan Godot di lingkungan pembuatnya, jadi belum pernah dijalankan di engine, belum ada build APK yang diuji, dan performa di perangkat Android nyata belum diukur.
  Workflow menyertakan uji asap headless (muat menu, bangun level, tembak, selesaikan misi) untuk menangkap error
  script di CI. Jika ada error, kirim `smoke.log` agar bisa diperbaiki.
- Ragdoll fisika belum ada: musuh mati dengan animasi jatuh (tween).
- Navigasi musuh memakai steering + raycast (tanpa navmesh), jadi tidak sepintar pathfinding penuh.
